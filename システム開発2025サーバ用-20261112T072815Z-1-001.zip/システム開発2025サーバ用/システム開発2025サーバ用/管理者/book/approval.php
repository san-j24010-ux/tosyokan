<?php
// このファイルは admin.php に include されるため、
// 他のページに影響しないように条件付きで実行
$currentPage = $_GET['page'] ?? '';
$searchResults = [];
$searched = false;
$genres = [];
$schools = [];
$approvalMessage = '';
$approvalError = '';
$genreAvailable = false;
$schoolAvailable = false;

// ログインユーザーの学校IDを取得
$userSchoolId = '';
if (isset($_SESSION['school_id'])) {
    $userSchoolId = $_SESSION['school_id'];
} elseif (isset($_SESSION['user_school_id'])) {
    $userSchoolId = $_SESSION['user_school_id'];
} elseif (isset($_SESSION['schoolId'])) {
    $userSchoolId = $_SESSION['schoolId'];
}

// 発送承認ページまたは承認関連のアクションの時のみ実行
if ($currentPage === 'approval' || isset($_POST['approve']) || isset($_POST['approve_all'])) {
    try {
        require_once __DIR__ . '/lend.php';
        require_once __DIR__ . '/Booking.php';
        
        // ジャンル一覧を取得（エラーハンドリング付き）
        try {
            $genres = Book::getAllGenres();
            $genreAvailable = true;
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'genre') !== false) {
                $genreAvailable = false;
            } else {
                $approvalError = "ジャンル取得エラー: " . $e->getMessage();
            }
        }
        
        // 学校一覧を取得
        try {
            $schools = Book::getAllSchools();
            $schoolAvailable = true;
        } catch (PDOException $e) {
            $schoolAvailable = false;
        }

        // 個別承認処理
        if (isset($_POST['approve']) && isset($_POST['approve_user_id']) && isset($_POST['approve_book_id'])) {
            $userId = $_POST['approve_user_id'] ?? '';
            $bookId = $_POST['approve_book_id'] ?? '';
            
            try {
                // ステータスを2から3に更新
                $updateResult = Lend::updateStatus($userId, $bookId, 3);
                
                if ($updateResult) {
                    $approvalMessage = "ユーザーID {$userId}, 書籍ID {$bookId} の発送が承認されました！";
                    
                    // 承認後、検索条件が保持されている場合は再検索
                    if (isset($_POST['search']) && $_POST['search'] == '1') {
                        $isbn = $_POST['isbn'] ?? '';
                        $bookName = $_POST['book_name'] ?? '';
                        $genreId = $_POST['genre_id'] ?? '';
                        $authorId = $_POST['author_id'] ?? '';
                        
                        // ログインユーザーの学校IDで再検索
                        $searchResults = Lend::getPendingApprovals($userSchoolId, $isbn, $bookName, $genreId, $authorId);
                        $searched = true;
                    }
                } else {
                    $approvalError = "承認処理に失敗しました。";
                }
            } catch (PDOException $e) {
                $approvalError = "承認エラー: " . $e->getMessage();
            }
        }

        // 一括承認処理
        if (isset($_POST['approve_all'])) {
            $selectedLends = $_POST['selected_lends'] ?? [];
            
            if (count($selectedLends) > 0) {
                $successCount = 0;
                $failCount = 0;
                
                foreach ($selectedLends as $lendData) {
                    // lendData は "user_id|book_id" の形式
                    list($userId, $bookId) = explode('|', $lendData);
                    
                    try {
                        $result = Lend::updateStatus($userId, $bookId, 3);
                        if ($result) {
                            $successCount++;
                        } else {
                            $failCount++;
                        }
                    } catch (PDOException $e) {
                        $failCount++;
                    }
                }
                
                if ($successCount > 0) {
                    $approvalMessage = "{$successCount}件の書籍の発送が承認されました！";
                    if ($failCount > 0) {
                        $approvalMessage .= "（{$failCount}件は失敗しました）";
                    }
                    
                    // 承認後、検索条件が保持されている場合は再検索
                    if (isset($_POST['search']) && $_POST['search'] == '1') {
                        $isbn = $_POST['isbn'] ?? '';
                        $bookName = $_POST['book_name'] ?? '';
                        $genreId = $_POST['genre_id'] ?? '';
                        $authorId = $_POST['author_id'] ?? '';
                        
                        // ログインユーザーの学校IDで再検索
                        $searchResults = Lend::getPendingApprovals($userSchoolId, $isbn, $bookName, $genreId, $authorId);
                        $searched = true;
                    }
                } else {
                    $approvalError = "承認処理に失敗しました。";
                }
            } else {
                $approvalMessage = "承認する書籍を選択してください";
            }
        }

        // 検索処理（status_id=2の予約のみ、book_id重複なし、予約時間早い順）
        // ログインユーザーの学校IDでフィルタリング
        if (isset($_GET['search']) || isset($_POST['search']) || $currentPage === 'approval') {
            $schoolId = $_REQUEST['school_id'] ?? '';
            $isbn = $_REQUEST['isbn'] ?? '';
            $bookName = $_REQUEST['book_name'] ?? '';
            $genreId = $_REQUEST['genre_id'] ?? '';
            $authorId = $_REQUEST['author_id'] ?? '';
            
            try {
                // ログインユーザーの学校IDで検索
                $searchResults = Lend::getPendingApprovals($userSchoolId, $isbn, $bookName, $genreId, $authorId);
                $searched = true;
            } catch (PDOException $e) {
                $approvalError = "検索エラー: " . $e->getMessage() . "<br><br>";
                $approvalError .= "<strong>考えられる原因:</strong><br>";
                $approvalError .= "- lendテーブルまたはbookテーブルが存在しない<br>";
                $approvalError .= "- 必要なカラムが存在しない<br><br>";
                $approvalError .= "phpMyAdmin で以下のコマンドを実行して、テーブル構造を確認してください:<br>";
                $approvalError .= "<code>DESCRIBE lend;</code><br>";
                $approvalError .= "<code>DESCRIBE book;</code>";
                $searched = true;
            }
        }
    } catch (Exception $e) {
        $approvalError = "エラーが発生しました: " . $e->getMessage();
    }
}
?>
<!-- 発送承認ページのコンテンツ -->
<div class="admin-page" id="page-approval">
    <style>
        #page-approval .approval-message {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
            animation: fadeIn 0.5s;
        }
        
        #page-approval .approval-message.error {
            background-color: #ffcccc;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        #page-approval .approve-btn {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 5px 15px;
            font-size: 13px;
            cursor: pointer;
            min-width: 70px;
            border-radius: 3px;
        }
        
        #page-approval .approve-btn:hover {
            background-color: #7edc7e;
        }
        
        #page-approval .approve-btn:active {
            border-color: #000000 #ffffff #ffffff #000000;
        }
        
        #page-approval .reject-btn {
            background-color: #ffcccc;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 5px 15px;
            font-size: 13px;
            cursor: pointer;
            min-width: 70px;
            margin-left: 5px;
            border-radius: 3px;
        }
        
        #page-approval .reject-btn:hover {
            background-color: #ffb3b3;
        }
        
        #page-approval .reject-btn:active {
            border-color: #000000 #ffffff #ffffff #000000;
        }
        
        #page-approval .bulk-actions {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        
        #page-approval .checkbox-cell {
            text-align: center;
            width: 50px;
        }
        
        #page-approval input[type="checkbox"] {
            cursor: pointer;
            width: 16px;
            height: 16px;
        }
        
        #page-approval .page-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        
        #page-approval .search-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        #page-approval .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 15px;
        }
        
        #page-approval .form-group {
            display: flex;
            flex-direction: column;
        }
        
        #page-approval .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            color: #555;
        }
        
        #page-approval .form-group input,
        #page-approval .form-group select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        #page-approval .search-btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        
        #page-approval .search-btn:hover {
            background: #2980b9;
        }
        
        #page-approval .results-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        #page-approval .results-table th {
            background: #34495e;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        #page-approval .results-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        #page-approval .results-table tr:hover {
            background: #f8f9fa;
        }
        
        #page-approval .no-results {
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 16px;
        }
    </style>

    <div class="page-title">✅ 発送承認</div>
    
    <?php if ($userSchoolId): ?>
        <div style="background: #e3f2fd; padding: 10px; margin-bottom: 15px; border-radius: 4px; border-left: 4px solid #2196f3;">
            <strong>🏫 表示対象:</strong> 学校ID <?php echo htmlspecialchars($userSchoolId); ?> の書籍のみ表示されます
        </div>
    <?php else: ?>
        <div style="background: #fff3cd; padding: 10px; margin-bottom: 15px; border-radius: 4px; border-left: 4px solid #ffc107;">
            <strong>⚠️ 警告:</strong> ログイン情報に学校IDが設定されていません。全ての書籍が表示されます。
        </div>
    <?php endif; ?>
    
    <?php if ($approvalError): ?>
        <div class="approval-message error" style="background-color: #ffcccc; color: #cc0000;">
            <strong>⚠️ エラー:</strong><br>
            <?php echo $approvalError; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($approvalMessage): ?>
        <div class="approval-message <?php echo (strpos($approvalMessage, '選択') !== false) ? 'error' : ''; ?>">
            <?php echo htmlspecialchars($approvalMessage); ?>
        </div>
    <?php endif; ?>
    
    <!-- 検索フォーム -->
    <div class="search-section">
        <form method="GET" action="admin.php" id="approval-search-form">
            <input type="hidden" name="page" value="approval">
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="approval-isbn">書籍番号（ISBN）</label>
                    <input type="text" id="approval-isbn" name="isbn" 
                           placeholder="例: 978-4001"
                           value="<?php echo htmlspecialchars($_REQUEST['isbn'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="approval-book-name">本の名前</label>
                    <input type="text" id="approval-book-name" name="book_name" 
                           placeholder="書名を入力"
                           value="<?php echo htmlspecialchars($_REQUEST['book_name'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="approval-author-id">著者ID</label>
                    <input type="text" id="approval-author-id" name="author_id" 
                           placeholder="例: 101, 102"
                           value="<?php echo htmlspecialchars($_REQUEST['author_id'] ?? ''); ?>">
                </div>
                
                <?php if ($genreAvailable): ?>
                <div class="form-group">
                    <label for="approval-genre-id">ジャンルID</label>
                    <select id="approval-genre-id" name="genre_id">
                        <option value="">すべて</option>
                        <?php foreach ($genres as $g): ?>
                            <option value="<?php echo htmlspecialchars($g['genre_id']); ?>" 
                                <?php echo (isset($_REQUEST['genre_id']) && $_REQUEST['genre_id'] == $g['genre_id']) ? 'selected' : ''; ?>>
                                ジャンル <?php echo htmlspecialchars($g['genre_id']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            
            <div style="background: #e8f4f8; padding: 10px; margin: 15px 0; border-radius: 4px; font-size: 13px;">
                <strong>ℹ️ 表示内容:</strong> 発送待ち（lend.status_id=2）かつ学校ID <?php echo htmlspecialchars($userSchoolId); ?> の予約が表示されています。同じ書籍の場合は予約時間が最も早いもののみ表示されます。
            </div>
            
            <div style="text-align: right;">
                <button type="submit" name="search" value="1" class="search-btn">🔍 検索</button>
            </div>
        </form>
    </div>
    
    <?php if ($searched): ?>
        <div class="results">
            <?php if (count($searchResults) > 0): ?>
                <div style="background: #f8f9fa; padding: 10px; margin-bottom: 15px; border-radius: 4px; font-size: 14px;">
                    <strong>📋 検索結果:</strong> <?php echo count($searchResults); ?> 件の発送待ち予約が見つかりました（学校ID: <?php echo htmlspecialchars($userSchoolId); ?>）
                </div>
                
                <form method="POST" action="" id="approval-form">
                    <!-- 検索条件を保持するための隠しフィールド -->
                    <input type="hidden" name="search" value="1">
                    <input type="hidden" name="isbn" value="<?php echo htmlspecialchars($_REQUEST['isbn'] ?? ''); ?>">
                    <input type="hidden" name="book_name" value="<?php echo htmlspecialchars($_REQUEST['book_name'] ?? ''); ?>">
                    <input type="hidden" name="genre_id" value="<?php echo htmlspecialchars($_REQUEST['genre_id'] ?? ''); ?>">
                    <input type="hidden" name="author_id" value="<?php echo htmlspecialchars($_REQUEST['author_id'] ?? ''); ?>">
                    
                    <div class="bulk-actions">
                        <button type="submit" name="approve_all" value="1" class="approve-btn">
                            ✓ 選択した項目を承認
                        </button>
                        <label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
                            <input type="checkbox" id="select-all-approval" onclick="toggleAllApproval(this)">
                            <span>すべて選択</span>
                        </label>
                    </div>
                    
                    <table class="results-table">
                        <thead>
                            <tr>
                                <th class="checkbox-cell">選択</th>
                                <th>ユーザーID</th>
                                <th>書籍ID</th>
                                <th>ISBN</th>
                                <th>書名</th>
                                <?php if ($genreAvailable): ?>
                                <th>ジャンルID</th>
                                <?php endif; ?>
                                <th>予約日</th>
                                <th>ステータス</th>
                                <th>表紙</th>
                                <th style="width: 180px;">操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($searchResults as $index => $lend): ?>
                                <tr>
                                    <td class="checkbox-cell">
                                        <input type="checkbox" name="selected_lends[]" 
                                               value="<?php echo htmlspecialchars($lend['user_id'] ?? '') . '|' . htmlspecialchars($lend['book_id'] ?? ''); ?>"
                                               class="lend-checkbox-approval">
                                    </td>
                                    <td><?php echo htmlspecialchars($lend['user_id'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($lend['book_id'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($lend['isbn'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($lend['book_name'] ?? ''); ?></td>
                                    <?php if ($genreAvailable): ?>
                                    <td><?php echo htmlspecialchars($lend['genre_id'] ?? ''); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo htmlspecialchars($lend['reservation_date'] ?? ''); ?></td>
                                    <td>
                                        <?php 
                                        $statusText = '';
                                        switch($lend['status_id'] ?? '') {
                                            case '1': $statusText = '予約中'; break;
                                            case '2': $statusText = '発送待ち'; break;
                                            case '3': $statusText = '発送済'; break;
                                            default: $statusText = $lend['status_id'] ?? '';
                                        }
                                        echo htmlspecialchars($statusText);
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($lend['photograph'])): ?>
                                            <img src="covers/<?php echo htmlspecialchars($lend['photograph']); ?>" 
                                                 alt="表紙" 
                                                 style="width: 40px; height: 60px; object-fit: cover;"
                                                 onerror="this.style.display='none'">
                                        <?php else: ?>
                                            <span style="color: #999;">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="submit" name="approve" value="1" class="approve-btn"
                                                onclick="return submitSingleApprovalForm(this, '<?php echo htmlspecialchars($lend['user_id'] ?? ''); ?>', '<?php echo htmlspecialchars($lend['book_id'] ?? ''); ?>')">
                                            ✓ 承認
                                        </button>
                                        <button type="button" class="reject-btn"
                                                onclick="alert('拒否機能は実装予定です')">
                                            ✗ 拒否
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </form>
            <?php else: ?>
                <p class="no-results">発送待ちの予約が見つかりませんでした</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <script>
        function toggleAllApproval(checkbox) {
            const checkboxes = document.querySelectorAll('.lend-checkbox-approval');
            checkboxes.forEach(cb => cb.checked = checkbox.checked);
        }
        
        function submitSingleApprovalForm(button, userId, bookId) {
            const form = button.form;
            
            // 既存の隠しフィールドを削除
            const existingUserId = form.querySelector('input[name="approve_user_id"]');
            const existingBookId = form.querySelector('input[name="approve_book_id"]');
            if (existingUserId) existingUserId.remove();
            if (existingBookId) existingBookId.remove();
            
            // 新しい隠しフィールドを追加
            const userIdInput = document.createElement('input');
            userIdInput.type = 'hidden';
            userIdInput.name = 'approve_user_id';
            userIdInput.value = userId;
            
            const bookIdInput = document.createElement('input');
            bookIdInput.type = 'hidden';
            bookIdInput.name = 'approve_book_id';
            bookIdInput.value = bookId;
            
            form.appendChild(userIdInput);
            form.appendChild(bookIdInput);
            
            return true;
        }
        
        // ページ初回読み込み時に自動的に全件検索を実行
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const currentPage = urlParams.get('page');
            const hasSearch = urlParams.get('search');
            
            // 発送承認ページで、かつ検索パラメータがない場合
            if (currentPage === 'approval' && !hasSearch) {
                // 自動的に検索パラメータを追加してリダイレクト
                urlParams.set('search', '1');
                window.location.href = 'admin.php?' + urlParams.toString();
            }
        });
    </script>
</div>