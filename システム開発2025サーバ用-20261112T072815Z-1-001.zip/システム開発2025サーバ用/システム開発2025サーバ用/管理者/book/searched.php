<?php
require_once 'Booking.php';

$searchResults = [];
$searched = false;
$genres = Book::getAllGenres();
$approvalMessage = '';

// 承認処理
if (isset($_GET['approve'])) {
    $isbn = $_GET['approve_isbn'] ?? '';
    $studentNumber = $_GET['approve_student'] ?? '';
    $approvalMessage = "承認されました!";
}

if (isset($_GET['search'])) {
    $studentNumber = $_GET['student_number'] ?? '';
    $isbn = $_GET['isbn'] ?? '';
    $title = $_GET['title'] ?? '';
    $genre = $_GET['genre'] ?? '';
    $author = $_GET['author'] ?? '';
    $loanDate = $_GET['loan_date'] ?? '';
    
    $searchResults = Book::search($studentNumber, $isbn, $title, $genre, $author, $loanDate);
    $searched = true;
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>書籍検索</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .approval-message {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
            animation: fadeIn 0.5s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .approve-btn {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 3px 15px;
            font-size: 12px;
            cursor: pointer;
            min-width: 60px;
        }
        
        .approve-btn:active {
            border-color: #000000 #ffffff #ffffff #000000;
        }
    </style>
</head>
<body>
    <div class="window">
        <div class="window-body">
            <?php if ($approvalMessage): ?>
                <div class="approval-message">
                    <?php echo htmlspecialchars($approvalMessage); ?>
                </div>
            <?php endif; ?>
            
            <form method="GET" action="">
                <div class="search-box">
                    <div class="search-header">
                        <input type="text" name="student_number" placeholder="学籍番号" value="<?php echo htmlspecialchars($_GET['student_number'] ?? ''); ?>">
                        <span class="search-icon">🔍</span>
                    </div>
                    
                    <div class="form-row">
                        <label for="isbn">書籍番号</label>
                        <input type="text" id="isbn" name="isbn" value="<?php echo htmlspecialchars($_GET['isbn'] ?? ''); ?>">
                        
                        <label for="title">書名</label>
                        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($_GET['title'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-row">
                        <label for="genre">ジャンル</label>
                        <select id="genre" name="genre">
                            <option value=""></option>
                            <?php foreach ($genres as $g): ?>
                                <option value="<?php echo htmlspecialchars($g['genre']); ?>" 
                                    <?php echo (isset($_GET['genre']) && $_GET['genre'] == $g['genre']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($g['genre']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <label for="author">著者</label>
                        <input type="text" id="author" name="author" value="<?php echo htmlspecialchars($_GET['author'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-row-full">
                        <label for="loan_date">貸出日</label>
                        <input type="text" id="loan_date" name="loan_date" value="<?php echo htmlspecialchars($_GET['loan_date'] ?? ''); ?>">
                    </div>
                </div>
                
                <div class="button-container">
                    <button type="submit" name="search" value="1">検索</button>
                </div>
            </form>
            
            <?php if ($searched): ?>
                <div class="results">
                    <?php if (count($searchResults) > 0): ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>学籍番号</th>
                                    <th>書籍番号</th>
                                    <th>書名</th>
                                    <th>ジャンル</th>
                                    <th>著者</th>
                                    <th>貸出日</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($searchResults as $book): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($book['student_number'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($book['isbn'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($book['title'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($book['genre'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($book['author'] ?? ''); ?></td>
                                        <td><?php echo htmlspecialchars($book['publisher'] ?? ''); ?></td>
                                        <td>
                                            <form method="GET" action="" style="margin: 0;">
                                                <input type="hidden" name="approve" value="1">
                                                <input type="hidden" name="approve_isbn" value="<?php echo htmlspecialchars($book['isbn'] ?? ''); ?>">
                                                <input type="hidden" name="approve_student" value="<?php echo htmlspecialchars($book['student_number'] ?? ''); ?>">
                                                <input type="hidden" name="search" value="1">
                                                <input type="hidden" name="student_number" value="<?php echo htmlspecialchars($_GET['student_number'] ?? ''); ?>">
                                                <input type="hidden" name="isbn" value="<?php echo htmlspecialchars($_GET['isbn'] ?? ''); ?>">
                                                <input type="hidden" name="title" value="<?php echo htmlspecialchars($_GET['title'] ?? ''); ?>">
                                                <input type="hidden" name="genre" value="<?php echo htmlspecialchars($_GET['genre'] ?? ''); ?>">
                                                <input type="hidden" name="author" value="<?php echo htmlspecialchars($_GET['author'] ?? ''); ?>">
                                                <input type="hidden" name="loan_date" value="<?php echo htmlspecialchars($_GET['loan_date'] ?? ''); ?>">
                                                <button type="submit" class="approve-btn">承認</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="no-results">検索結果が見つかりませんでした</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>