<?php
class Book {
    private $bookId;
    private $isbn;
    private $schoolId;
    private $bookName;
    private $authorId;
    private $genreId;
    private $statusId;
    private $photograph;
    
    // データベース接続情報
    private static $host = 'localhost';
    private static $dbname = 'Library';  // データベース名
    private static $username = 'user01';
    private static $password = 'user01';
    
    public function __construct($bookId = '', $isbn = '', $schoolId = '', $bookName = '', $authorId = '', $genreId = '', $statusId = '', $photograph = '') {
        $this->bookId = $bookId;
        $this->isbn = $isbn;
        $this->schoolId = $schoolId;
        $this->bookName = $bookName;
        $this->authorId = $authorId;
        $this->genreId = $genreId;
        $this->statusId = $statusId;
        $this->photograph = $photograph;
    }
    
    // データベース接続を取得
    private static function getConnection() {
        try {
            $pdo = new PDO(
                "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4",
                self::$username,
                self::$password,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            return $pdo;
        } catch (PDOException $e) {
            die("データベース接続エラー: " . $e->getMessage());
        }
    }
    
    public function getBookId() {
        return $this->bookId;
    }
    
    public function getIsbn() {
        return $this->isbn;
    }
    
    public function getSchoolId() {
        return $this->schoolId;
    }
    
    public function getBookName() {
        return $this->bookName;
    }
    
    public function getAuthorId() {
        return $this->authorId;
    }
    
    public function getGenreId() {
        return $this->genreId;
    }
    
    public function getStatusId() {
        return $this->statusId;
    }
    
    public function getPhotograph() {
        return $this->photograph;
    }
    
    // 全書籍を取得
    public static function getAll() {
        $pdo = self::getConnection();
        $stmt = $pdo->query("SELECT * FROM book");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // ジャンル一覧を取得（genre_id から取得）
    public static function getAllGenres() {
        $pdo = self::getConnection();
        // genre_id の一覧を取得（重複なし）
        $stmt = $pdo->query("SELECT DISTINCT genre_id FROM book WHERE genre_id IS NOT NULL ORDER BY genre_id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 学校一覧を取得（school_id から取得）
    public static function getAllSchools() {
        $pdo = self::getConnection();
        $stmt = $pdo->query("SELECT DISTINCT school_id FROM book WHERE school_id IS NOT NULL ORDER BY school_id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 書籍を検索
    public static function search($schoolId = '', $isbn = '', $bookName = '', $genreId = '', $authorId = '', $statusId = '') {
        $pdo = self::getConnection();
        
        $sql = "SELECT * FROM book WHERE 1=1";
        $params = [];
        
        if (!empty($schoolId)) {
            $sql .= " AND school_id LIKE ?";
            $params[] = '%' . $schoolId . '%';
        }
        
        if (!empty($isbn)) {
            $sql .= " AND isbn LIKE ?";
            $params[] = '%' . $isbn . '%';
        }
        
        if (!empty($bookName)) {
            $sql .= " AND book_name LIKE ?";
            $params[] = '%' . $bookName . '%';
        }
        
        if (!empty($genreId)) {
            $sql .= " AND genre_id = ?";
            $params[] = $genreId;
        }
        
        if (!empty($authorId)) {
            $sql .= " AND author_id LIKE ?";
            $params[] = '%' . $authorId . '%';
        }
        
        if (!empty($statusId)) {
            $sql .= " AND status_id = ?";
            $params[] = $statusId;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // ステータスを更新
    public static function updateStatus($bookId, $newStatusId) {
        $pdo = self::getConnection();
        
        $sql = "UPDATE book SET status_id = ? WHERE book_id = ?";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$newStatusId, $bookId]);
        
        return $result && $stmt->rowCount() > 0;
    }
}
?>