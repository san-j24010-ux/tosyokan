<?php
class Lend {
    private $userId;
    private $bookId;
    private $statusId;
    private $checkoutDate;
    private $returnDate;
    private $reservationDate;
    
    // データベース接続情報
    private static $host = 'localhost';
    private static $dbname = 'Library';
    private static $username = 'user01';
    private static $password = 'user01';
    
    public function __construct($userId = '', $bookId = '', $statusId = '', $checkoutDate = '', $returnDate = '', $reservationDate = '') {
        $this->userId = $userId;
        $this->bookId = $bookId;
        $this->statusId = $statusId;
        $this->checkoutDate = $checkoutDate;
        $this->returnDate = $returnDate;
        $this->reservationDate = $reservationDate;
    }
    
    // データベース接続を取得
    private static function getConnection() {
        try {
            $pdo = new PDO(
                "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4",
                self::$username,
                self::$password,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            return $pdo;
        } catch (PDOException $e) {
            die("データベース接続エラー: " . $e->getMessage());
        }
    }
    
    // ステータスID=2の予約を取得（book_id重複なし、予約時間が早い順）
    // school_idで必ずフィルタリング
    public static function getPendingApprovals($schoolId = '', $isbn = '', $bookName = '', $genreId = '', $authorId = '') {
        $pdo = self::getConnection();
        
        // lendテーブルとbookテーブルを結合
        // status_id=2の予約から、book_idごとに最も早い予約時間のものだけを取得
        $sql = "
            SELECT 
                l.user_id,
                l.book_id,
                l.status_id,
                l.checkout_date,
                l.return_date,
                l.reservation_date,
                b.isbn,
                b.school_id,
                b.book_name,
                b.author_id,
                b.genre_id,
                b.photograph
            FROM lend l
            INNER JOIN book b ON l.book_id = b.book_id
            INNER JOIN users x ON l.user_id = x.user_id
            WHERE l.status_id = 2
            AND l.reservation_date = (
                SELECT MIN(l2.reservation_date)
                FROM lend l2
                WHERE l2.book_id = l.book_id
                AND l2.status_id = 2
            )
        ";
        
        $params = [];
        
        // 学校IDでフィルタリング（必須）
        if (!empty($schoolId)) {
            $sql .= " AND b.school_id = ?";
            $params[] = $schoolId;
        }

        if (!empty($schoolId)) {
            $sql .= " AND x.school_id != ?";
            $params[] = $schoolId;
        }

        // 検索条件を追加
        if (!empty($isbn)) {
            $sql .= " AND b.isbn LIKE ?";
            $params[] = '%' . $isbn . '%';
        }
        
        if (!empty($bookName)) {
            $sql .= " AND b.book_name LIKE ?";
            $params[] = '%' . $bookName . '%';
        }
        
        if (!empty($genreId)) {
            $sql .= " AND b.genre_id = ?";
            $params[] = $genreId;
        }
        
        if (!empty($authorId)) {
            $sql .= " AND b.author_id LIKE ?";
            $params[] = '%' . $authorId . '%';
        }
        
        // 予約時間が早い順に並び替え
        $sql .= " ORDER BY l.reservation_date ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // ステータスを更新（2 → 3）
    public static function updateStatus($userId, $bookId, $newStatusId) {
        $pdo = self::getConnection();
        
        // user_idとbook_idの組み合わせで更新
        $sql = "UPDATE lend SET status_id = ? WHERE user_id = ? AND book_id = ? AND status_id = 2";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([$newStatusId, $userId, $bookId]);

        // bookテーブルのstatus_idを3（貸出中）に更新
        $stmt = $pdo->prepare("UPDATE book
                              SET status_id = 3 
                              WHERE book_id = :book_id");
        $stmt->execute([':book_id' => $bookId]);

        
        return $result && $stmt->rowCount() > 0;
    }
    
    // user_idとbook_idで1件取得
    public static function getByUserAndBook($userId, $bookId) {
        $pdo = self::getConnection();
        
        $sql = "
            SELECT 
                l.user_id,
                l.book_id,
                l.status_id,
                l.checkout_date,
                l.return_date,
                l.reservation_date,
                b.isbn,
                b.school_id,
                b.book_name,
                b.author_id,
                b.genre_id,
                b.photograph
            FROM lend l
            INNER JOIN book b ON l.book_id = b.book_id
            WHERE l.user_id = ? AND l.book_id = ?
        ";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId, $bookId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
?>