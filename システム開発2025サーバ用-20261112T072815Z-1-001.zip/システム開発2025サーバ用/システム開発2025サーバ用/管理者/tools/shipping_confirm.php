<?php
// このファイルは admin.php に include されるため、
// 他のページに影響しないように条件付きで実行
$currentPage = $_GET['page'] ?? '';
$shippingResults = [];
$searched = false;
$confirmMessage = '';
$confirmError = '';

// ログインユーザーの学校IDを取得
$userSchoolId = $_SESSION['school_id'] ?? '';

// 発送確認ページまたは承認関連のアクションの時のみ実行
if ($currentPage === 'shipping-confirm' || isset($_POST['confirm']) || isset($_POST['confirm_all'])) {
    try {
        require_once(__DIR__ . '/../shipping/ShippingConfirm.php');
        
        // 個別確認処理
        if (isset($_POST['confirm']) && isset($_POST['confirm_user_id']) && isset($_POST['confirm_book_id'])) {
            $userId = $_POST['confirm_user_id'] ?? '';
            $bookId = $_POST['confirm_book_id'] ?? '';
            $reservation_date = $_POST['reservation_date'] ?? '';
            
            try {
                // ステータスを3から1に更新
                $updateResult = ShippingConfirm::confirmShipping($userId, $bookId, $reservation_date);
                
                if ($updateResult) {
                    $confirmMessage = "学籍番号 {$userId}, 書籍ID {$bookId} の発送が完了しました！";
                    
                    // 確認後、検索条件が保持されている場合は再検索
                    if (isset($_POST['search']) && $_POST['search'] == '1') {
                        $userId = $_POST['user_id'] ?? '';
                        $isbn = $_POST['isbn'] ?? '';
                        $year = $_POST['year'] ?? '';
                        
                        $shippingResults = ShippingConfirm::getShippedItems($userSchoolId, $userId, $isbn, $year);
                        $searched = true;
                    }
                } else {
                    $confirmError = "発送完了処理に失敗しました。";
                }
            } catch (PDOException $e) {
                $confirmError = "確認エラー: " . $e->getMessage();
            }
        }

        // 一括確認処理
        if (isset($_POST['confirm_all'])) {
            $selectedItems = $_POST['selected_items'] ?? [];
            
            if (count($selectedItems) > 0) {
                $result = ShippingConfirm::confirmMultiple($selectedItems);
                
                if ($result['success'] > 0) {
                    $confirmMessage = "{$result['success']}件の発送が完了しました！";
                    if ($result['fail'] > 0) {
                        $confirmMessage .= "（{$result['fail']}件は失敗しました）";
                    }
                    
                    // 確認後、検索条件が保持されている場合は再検索
                    if (isset($_POST['search']) && $_POST['search'] == '1') {
                        $userId = $_POST['user_id'] ?? '';
                        $isbn = $_POST['isbn'] ?? '';
                        $year = $_POST['year'] ?? '';
                        
                        $shippingResults = ShippingConfirm::getShippedItems($userSchoolId, $userId, $isbn, $year);
                        $searched = true;
                    }
                } else {
                    $confirmError = "発送完了処理に失敗しました。";
                }
            } else {
                $confirmMessage = "確認する項目を選択してください";
            }
        }

        // 検索処理（status_id=3、ユーザーの学校IDと書籍の学校IDが異なる）
        if (isset($_GET['search']) || isset($_POST['search']) || $currentPage === 'shipping-confirm') {
            $userId = $_REQUEST['user_id'] ?? '';
            $isbn = $_REQUEST['isbn'] ?? '';
            $year = $_REQUEST['year'] ?? '';
            
            try {
                $shippingResults = ShippingConfirm::getShippedItems($userSchoolId, $userId, $isbn, $year);
                $searched = true;
            } catch (PDOException $e) {
                $confirmError = "検索エラー: " . $e->getMessage();
                $searched = true;
            }
        }
    } catch (Exception $e) {
        $confirmError = "エラーが発生しました: " . $e->getMessage();
    }
}
?>

<!-- 発送確認ページのコンテンツ -->
<div class="admin-page" id="page-shipping-confirm">
    <style>
        #page-shipping-confirm .confirm-message {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 10px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
            animation: fadeIn 0.5s;
        }
        
        #page-shipping-confirm .confirm-message.error {
            background-color: #ffcccc;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        #page-shipping-confirm .confirm-btn {
            background-color: #90ee90;
            border: 2px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 5px 15px;
            font-size: 13px;
            cursor: pointer;
            min-width: 70px;
            border-radius: 3px;
        }
        
        #page-shipping-confirm .confirm-btn:hover {
            background-color: #7edc7e;
        }
        
        #page-shipping-confirm .confirm-btn:active {
            border-color: #000000 #ffffff #ffffff #000000;
        }
        
        #page-shipping-confirm .bulk-actions {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 4px;
        }
        
        #page-shipping-confirm .checkbox-cell {
            text-align: center;
            width: 50px;
        }
        
        #page-shipping-confirm input[type="checkbox"] {
            cursor: pointer;
            width: 16px;
            height: 16px;
        }
        
        #page-shipping-confirm .page-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            color: #2c3e50;
        }
        
        #page-shipping-confirm .search-section {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        #page-shipping-confirm .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-bottom: 15px;
        }
        
        #page-shipping-confirm .form-group {
            display: flex;
            flex-direction: column;
        }
        
        #page-shipping-confirm .form-group label {
            font-weight: 600;
            margin-bottom: 5px;
            color: #555;
        }
        
        #page-shipping-confirm .form-group input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        #page-shipping-confirm .search-btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 10px 30px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        
        #page-shipping-confirm .search-btn:hover {
            background: #2980b9;
        }
        
        #page-shipping-confirm .results-table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        #page-shipping-confirm .results-table th {
            background: #34495e;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
        }
        
        #page-shipping-confirm .results-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        
        #page-shipping-confirm .results-table tr:hover {
            background: #f8f9fa;
        }
        
        #page-shipping-confirm .no-results {
            text-align: center;
            padding: 40px;
            color: #999;
            font-size: 16px;
        }
        
        #page-shipping-confirm .status-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        #page-shipping-confirm .status-shipped {
            background: #fff3cd;
            color: #856404;
        }
    </style>

    <div class="page-title">📦 発送確認</div>
    
    <?php if ($userSchoolId): ?>
        <div style="background: #e3f2fd; padding: 10px; margin-bottom: 15px; border-radius: 4px; border-left: 4px solid #2196f3;">
            <strong>🏫 表示対象:</strong> あなたの学校（<?php echo htmlspecialchars($userSchoolId); ?>）のユーザーが予約した、他の学校の書籍が表示されます
        </div>
    <?php else: ?>
        <div style="background: #fff3cd; padding: 10px; margin-bottom: 15px; border-radius: 4px; border-left: 4px solid #ffc107;">
            <strong>⚠️ 警告:</strong> ログイン情報に学校IDが設定されていません。
        </div>
    <?php endif; ?>
    
    <?php if ($confirmError): ?>
        <div class="confirm-message error" style="background-color: #ffcccc; color: #cc0000;">
            <strong>⚠️ エラー:</strong><br>
            <?php echo $confirmError; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($confirmMessage): ?>
        <div class="confirm-message <?php echo (strpos($confirmMessage, '選択') !== false) ? 'error' : ''; ?>">
            <?php echo htmlspecialchars($confirmMessage); ?>
        </div>
    <?php endif; ?>
    
    <!-- 検索フォーム -->
    <!-- 検索フォーム -->
<div class="search-section">
    <form method="GET" action="" id="shipping-confirm-search-form" onsubmit="return handleShippingSearch(event)">
        <input type="hidden" name="page" value="shipping-confirm">
        
        <div class="form-grid">
            <div class="form-group">
                <label for="shipping-user-id">ユーザーID</label>
                <input type="text" id="shipping-user-id" name="user_id" 
                       placeholder="例: j23001"
                       value="<?php echo htmlspecialchars($_REQUEST['user_id'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="shipping-isbn">書籍番号（ISBN）</label>
                <input type="text" id="shipping-isbn" name="isbn" 
                       placeholder="例: 978-4001"
                       value="<?php echo htmlspecialchars($_REQUEST['isbn'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="shipping-year">年度</label>
                <input type="text" id="shipping-year" name="year" 
                       placeholder="例: 2026"
                       value="<?php echo htmlspecialchars($_REQUEST['year'] ?? ''); ?>">
            </div>
        </div>
        
        <div style="text-align: right;">
            <button type="submit" name="search" value="1" class="search-btn">🔍 検索</button>
        </div>
    </form>
</div>
    
    <?php if ($searched): ?>
        <div class="results">
            <?php if (count($shippingResults) > 0): ?>
                <div style="background: #f8f9fa; padding: 10px; margin-bottom: 15px; border-radius: 4px; font-size: 14px;">
                    <strong>📋 検索結果:</strong> <?php echo count($shippingResults); ?> 件の発送済み予約が見つかりました
                </div>
                
                <form method="POST" action="" id="shipping-confirm-form">
                    <!-- 検索条件を保持するための隠しフィールド -->
                    <input type="hidden" name="search" value="1">
                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($_REQUEST['user_id'] ?? ''); ?>">
                    <input type="hidden" name="isbn" value="<?php echo htmlspecialchars($_REQUEST['isbn'] ?? ''); ?>">
                    <input type="hidden" name="year" value="<?php echo htmlspecialchars($_REQUEST['year'] ?? ''); ?>">
                    
                    <div class="bulk-actions">
                        <button type="submit" name="confirm_all" value="1" class="confirm-btn">
                            ✓ 選択した項目を発送完了
                        </button>
                        <label style="display: flex; align-items: center; gap: 5px; cursor: pointer;">
                            <input type="checkbox" id="select-all-shipping" onclick="toggleAllShipping(this)">
                            <span>すべて選択</span>
                        </label>
                    </div>
                    
                    <table class="results-table">
                        <thead>
                            <tr>
                                <th class="checkbox-cell">選択</th>
                                <th>ユーザーID</th>
                                <th>書籍ID</th>
                                <th>ISBN</th>
                                <th>書名</th>
                                <th>書籍の学校</th>
                                <th>予約日</th>
                                <th>ステータス</th>
                                <th style="width: 120px;">操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($shippingResults as $item): ?>
                                <tr>
                                    <td class="checkbox-cell">
                                        <input type="checkbox" name="selected_items[]" 
                                               value="<?php echo htmlspecialchars($item['user_id'] ?? '') . '|' . htmlspecialchars($item['book_id'] ?? ''); ?>"
                                               class="shipping-checkbox">
                                    </td>
                                    <td><?php echo htmlspecialchars($item['user_id'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['book_id'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['isbn'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['book_name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['book_school_id'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($item['reservation_date'] ?? ''); ?></td>
                                    <td>
                                        <span class="status-badge status-shipped">発送済み</span>
                                    </td>
                                    <td>
                                        <button type="submit" name="confirm" value="1" class="confirm-btn"
                                                onclick="return submitSingleConfirmForm(this, '<?php echo htmlspecialchars($item['user_id'] ?? ''); ?>', '<?php echo htmlspecialchars($item['book_id'] ?? ''); ?>', '<?php echo htmlspecialchars($item['reservation_date'] ?? ''); ?>')">
                                            ✓ 完了
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </form>
            <?php else: ?>
                <p class="no-results">発送済みの予約が見つかりませんでした</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
    <script>
        function handleShippingSearch(event) {
            event.preventDefault();
            
            const form = event.target;
            const formData = new FormData(form);
            const params = new URLSearchParams(formData);
            
            // 現在のURLに検索パラメータを追加
            window.location.href = 'admin.php?' + params.toString();
            
            return false;
        }
        
        function toggleAllShipping(checkbox) {
            const checkboxes = document.querySelectorAll('.shipping-checkbox');
            checkboxes.forEach(cb => cb.checked = checkbox.checked);
        }
        
        function submitSingleConfirmForm(button, userId, bookId, reservation_date) {
            const form = button.form;
            
            // 既存の隠しフィールドを削除
            const existingUserId = form.querySelector('input[name="confirm_user_id"]');
            const existingBookId = form.querySelector('input[name="confirm_book_id"]');
            const existingReservation = form.querySelector('input[name="reservation_date"]');
            if (existingUserId) existingUserId.remove();
            if (existingBookId) existingBookId.remove();
             if (existingReservation) existingReservation.remove();
            
            // 新しい隠しフィールドを追加
            const userIdInput = document.createElement('input');
            userIdInput.type = 'hidden';
            userIdInput.name = 'confirm_user_id';
            userIdInput.value = userId;
            
            const bookIdInput = document.createElement('input');
            bookIdInput.type = 'hidden';
            bookIdInput.name = 'confirm_book_id';
            bookIdInput.value = bookId;

            const reservationInput = document.createElement('input');
            reservationInput.type = 'hidden';
            reservationInput.name = 'reservation_date';
            reservationInput.value = reservation_date;
            
            form.appendChild(userIdInput);
            form.appendChild(bookIdInput);
            form.appendChild(reservationInput);
            
            return true;
        }
        
        // ページ初回読み込み時に自動的に全件検索を実行
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const currentPage = urlParams.get('page');
            const hasSearch = urlParams.get('search');
            
            // 発送確認ページで、かつ検索パラメータがない場合
            if (currentPage === 'shipping-confirm' && !hasSearch) {
                // 自動的に検索パラメータを追加してリダイレクト
                urlParams.set('search', '1');
                window.location.href = 'admin.php?' + urlParams.toString();
            }
        });
    </script>
</div>