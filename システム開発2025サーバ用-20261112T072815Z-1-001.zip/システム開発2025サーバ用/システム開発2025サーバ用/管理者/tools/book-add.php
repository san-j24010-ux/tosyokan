<!-- ページ: 本を追加 -->
 <?php
require_once dirname(__DIR__) . '/api/db_config.php'; // 設定ファイルの読み込み

try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // --- ジャンル一覧を取得 ---
    $sql_genre = "SELECT genre_id, genre_name FROM {$DB_TABLE_GENRE}";
    $stmt_genre = $dbh->query($sql_genre);
    $genres = $stmt_genre->fetchAll(PDO::FETCH_ASSOC);

    // --- (参考) 場所一覧も同様に取得する場合 ---
    $sql_school = "SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL}";
    $stmt_school = $dbh->query($sql_school);
    $schools = $stmt_school->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    exit('データ取得失敗: ' . $e->getMessage());
}
?>

<div class="admin-page" id="page-manage">
  <h1>本を追加</h1>
  <form id="addForm" class="search-form">
    <div class="form-row">
      <label>書籍番号<br><input type="text" id="add-isbn" name="isbn" placeholder="例: 006-006" required></label>
      <label>本の題名<br><input type="text" id="add-title" name="title" placeholder="題名を入力" required></label>
    </div>
    <div class="form-row">
      <label>本の著者名<br><input type="text" id="add-author" name="author" placeholder="著者名を入力" required></label>
      <label>本のジャンル<br>
        <select id="genre" name="genre">
          <option value="">すべて</option>
          <?php foreach ($genres as $genre): ?>
            <option value="<?php echo htmlspecialchars($genre['genre_id'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($genre['genre_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>本の場所<br>
        <select id="school_id" name="school_id">
          <option value="">すべて</option>
          <?php foreach ($schools as $school): ?>
            <option value="<?php echo htmlspecialchars($school['school_id'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>表紙画像<br>
        <input type="file" id="add-photograph" name="photograph" accept="image/*">
      </label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">追加</button>
    </div>
  </form>
  <div id="addMessage" class="message"></div>
</div>
