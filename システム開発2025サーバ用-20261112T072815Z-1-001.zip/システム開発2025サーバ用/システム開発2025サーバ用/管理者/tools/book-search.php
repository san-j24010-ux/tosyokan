<!-- ページ: 本を検索 -->
<?php
require_once dirname(__DIR__) . '/api/db_config.php'; // 設定ファイルの読み込み

try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // --- ジャンル一覧を取得 ---
    $sql_genre = "SELECT genre_id, genre_name FROM {$DB_TABLE_GENRE}";
    $stmt_genre = $dbh->query($sql_genre);
    $genres = $stmt_genre->fetchAll(PDO::FETCH_ASSOC);

    // --- (参考) 場所一覧も同様に取得する場合 ---
    $sql_school = "SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL}";
    $stmt_school = $dbh->query($sql_school);
    $schools = $stmt_school->fetchAll(PDO::FETCH_ASSOC);

    // --- ステータス一覧を取得（status_idが1, 3, 4のみ） ---
    $sql_status = "SELECT status_id, status_name FROM {$DB_TABLE_STATUS} WHERE status_id IN (1, 3, 4)";
    $stmt_status = $dbh->query($sql_status);
    $statuses = $stmt_status->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    exit('データ取得失敗: ' . $e->getMessage());
}
?>

<div class="admin-page active" id="page-search">
  <h1>本を検索</h1>
  <form id="searchForm" class="search-form">
    <div class="form-row">
      <label>書籍番号<br><input type="text" id="isbn" name="isbn" placeholder="例: 001-001"></label>
      <label>本の題名<br><input type="text" id="title" name="title" placeholder="題名を入力"></label>
    </div>
    <div class="form-row">
      <label>本の著者名<br><input type="text" id="author" name="author" placeholder="著者名を入力"></label>
      <label>本のジャンル<br>
        <select id="genre" name="genre">
          <option value="">すべて</option>
          <?php foreach ($genres as $genre): ?>
            <option value="<?php echo htmlspecialchars($genre['genre_name'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($genre['genre_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>

    <div class="form-row">
      <label>本の場所<br>
        <select id="location" name="location">
          <option value="">すべて</option>
          <?php foreach ($schools as $school): ?>
            <option value="<?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>ステータス<br>
        <select id="status" name="status">
          <option value="">すべて</option>
          <?php foreach ($statuses as $status): ?>
            <option value="<?php echo htmlspecialchars($status['status_name'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($status['status_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>返却期間（開始）<br><input type="date" id="start_date" name="start_date"></label>
    </div>
    <div class="form-row">
      <label>返却期間（終了）<br><input type="date" id="end_date" name="end_date"></label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">検索</button>
    </div>
  </form>
  <section id="results" class="results"></section>
</div>

