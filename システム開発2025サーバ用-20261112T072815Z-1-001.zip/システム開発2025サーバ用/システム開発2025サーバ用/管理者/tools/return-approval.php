<!-- ページ: 返却承認 -->
<?php
// ログイン中のユーザーのschool_idを取得
$current_school_id = $_SESSION['school_id'] ?? null;

require_once dirname(__DIR__) . '/api/db_config.php';

$returnData = [];
try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // ログインユーザーと同じ学校の生徒が借りている本を取得（status_id=1は貸出中）
    if ($current_school_id) {
        $sql = "SELECT 
                    l.user_id,
                    l.book_id,
                    l.status_id,
                    l.checkout_date,
                    l.return_date,
                    l.reservation_date,
                    b.book_name,
                    b.isbn,
                    b.photograph,
                    b.school_id as book_school_id,
                    u.user_name,
                    u.user_id as borrower_id,
                    u.school_id as user_school_id,
                    s.school_name,
                    st.status_name
                FROM {$DB_TABLE_LEND} l
                INNER JOIN {$DB_TABLE_BOOK} b ON l.book_id = b.book_id
                LEFT JOIN {$DB_TABLE_USER} u ON l.user_id = u.user_id
                LEFT JOIN {$DB_TABLE_SCHOOL} s ON b.school_id = s.school_id
                LEFT JOIN {$DB_TABLE_STATUS} st ON l.status_id = st.status_id
                WHERE u.school_id = :school_id 
                  AND l.status_id = 1
                ORDER BY l.return_date ASC, l.checkout_date DESC";
        
        $stmt = $dbh->prepare($sql);
        $stmt->execute([':school_id' => $current_school_id]);
        $returnData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log('返却データ取得失敗: ' . $e->getMessage());
}
?>

<div class="admin-page" id="page-return-approval">
  <style>
    #page-return-approval .page-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 10px;
      margin-bottom: 30px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    #page-return-approval .page-header h1 {
      margin: 0 0 10px 0;
      font-size: 28px;
    }
    
    #page-return-approval .page-header p {
      margin: 0;
      opacity: 0.9;
      font-size: 14px;
    }
    
    #page-return-approval .filter-section {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    #page-return-approval .return-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    #page-return-approval .return-card {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
      border-left: 4px solid #3498db;
    }
    
    #page-return-approval .return-card.overdue {
      border-left-color: #e74c3c;
    }
    
    #page-return-approval .return-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    #page-return-approval .return-card-header {
      display: flex;
      gap: 15px;
      padding: 20px;
      background: #f8f9fa;
      border-bottom: 2px solid #e9ecef;
    }
    
    #page-return-approval .return-card-image {
      width: 80px;
      height: 120px;
      object-fit: cover;
      border-radius: 4px;
      flex-shrink: 0;
      background: #e0e0e0;
    }
    
    #page-return-approval .return-card-image-placeholder {
      width: 80px;
      height: 120px;
      background: linear-gradient(135deg, #e0e0e0, #c0c0c0);
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #666;
      font-size: 11px;
      text-align: center;
      flex-shrink: 0;
    }
    
    #page-return-approval .return-card-title {
      flex: 1;
    }
    
    #page-return-approval .return-card-title h3 {
      margin: 0 0 8px 0;
      font-size: 16px;
      color: #2c3e50;
      line-height: 1.4;
    }
    
    #page-return-approval .return-card-title .isbn {
      font-size: 12px;
      color: #7f8c8d;
      margin-bottom: 8px;
    }
    
    #page-return-approval .status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }
    
    #page-return-approval .status-borrowed {
      background: #fff3cd;
      color: #856404;
    }
    
    #page-return-approval .status-overdue {
      background: #f8d7da;
      color: #721c24;
    }
    
    #page-return-approval .return-card-body {
      padding: 20px;
    }
    
    #page-return-approval .info-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;
      font-size: 14px;
    }
    
    #page-return-approval .info-row:last-child {
      border-bottom: none;
    }
    
    #page-return-approval .info-label {
      color: #7f8c8d;
      font-weight: 500;
    }
    
    #page-return-approval .info-value {
      color: #2c3e50;
      font-weight: 600;
    }
    
    #page-return-approval .info-value.overdue {
      color: #e74c3c;
      font-weight: 700;
    }
    
    #page-return-approval .return-card-actions {
      padding: 15px 20px;
      background: #f8f9fa;
      display: flex;
      gap: 10px;
      justify-content: flex-end;
    }
    
    #page-return-approval .btn {
      padding: 8px 20px;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    #page-return-approval .btn-return {
      background: #28a745;
      color: white;
    }
    
    #page-return-approval .btn-return:hover {
      background: #218838;
    }
    
    #page-return-approval .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: #7f8c8d;
    }
    
    #page-return-approval .empty-state-icon {
      font-size: 64px;
      margin-bottom: 20px;
      opacity: 0.5;
    }
    
    #page-return-approval .empty-state-title {
      font-size: 20px;
      margin-bottom: 10px;
    }
    
    #page-return-approval .empty-state-text {
      font-size: 14px;
    }
  </style>

  <div class="page-header">
    <h1>📚 返却承認管理</h1>
    <p>貸出中の本の返却を確認・承認します</p>
    <?php if ($current_school_id): ?>
      <p style="font-size: 12px; opacity: 0.8; margin-top: 10px;">
        フィルタリング中: School ID = <?php echo htmlspecialchars($current_school_id, ENT_QUOTES, 'UTF-8'); ?>
      </p>
    <?php endif; ?>
  </div>

  <?php if (!$current_school_id): ?>
    <div class="empty-state">
      <div class="empty-state-icon">⚠️</div>
      <div class="empty-state-title">学校情報が見つかりません</div>
      <div class="empty-state-text">ログインしているユーザーに学校が設定されていません。</div>
    </div>
  <?php elseif (empty($returnData)): ?>
    <div class="empty-state">
      <div class="empty-state-icon">✅</div>
      <div class="empty-state-title">返却待ちの本はありません</div>
      <div class="empty-state-text">現在、返却待ちの貸出はありません。</div>
    </div>
  <?php else: ?>
    <!-- 検索フォーム -->
    <div class="filter-section">
      <input type="text" id="returnSearchInput" placeholder="本のタイトル、ISBN、借りた人の名前で検索..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
    </div>
    
    <div style="background: #fff3cd; padding: 15px; margin-bottom: 20px; border-radius: 8px; font-size: 13px;">
      <strong>📋</strong> <span id="resultCount"><?php echo count($returnData); ?></span>件の貸出中の本があります
    </div>
    
    <div class="return-grid" id="returnGrid">
      <?php foreach ($returnData as $return): ?>
        <?php
        // 返却期限を過ぎているかチェック
        $isOverdue = false;
        if (!empty($return['return_date'])) {
          $returnDate = new DateTime($return['return_date']);
          $today = new DateTime();
          $isOverdue = $today > $returnDate;
        }
        ?>
        <div class="return-card <?php echo $isOverdue ? 'overdue' : ''; ?>">
          <div class="return-card-header">
            <?php if (!empty($return['photograph'])): ?>
              <?php
              $imgSrc = $return['photograph'];
              if (!preg_match('/^https?:\/\//', $imgSrc)) {
                $imgSrc = $return['photograph'];
              }
              ?>
              <img src="<?php echo htmlspecialchars($imgSrc, ENT_QUOTES, 'UTF-8'); ?>" 
                   alt="表紙" 
                   class="return-card-image"
                   onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
              <div class="return-card-image-placeholder" style="display:none;">画像なし</div>
            <?php else: ?>
              <div class="return-card-image-placeholder">画像なし</div>
            <?php endif; ?>
            
            <div class="return-card-title">
              <h3><?php echo htmlspecialchars($return['book_name'] ?? '(タイトル不明)', ENT_QUOTES, 'UTF-8'); ?></h3>
              <div class="isbn">ISBN: <?php echo htmlspecialchars($return['isbn'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></div>
              <span class="status-badge <?php echo $isOverdue ? 'status-overdue' : 'status-borrowed'; ?>">
                <?php echo $isOverdue ? '⚠️ 返却期限超過' : '📖 貸出中'; ?>
              </span>
            </div>
          </div>
          
          <div class="return-card-body">
            <div class="info-row">
              <span class="info-label">借りた人</span>
              <span class="info-value"><?php echo htmlspecialchars($return['user_name'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">学校</span>
              <span class="info-value"><?php echo htmlspecialchars($return['school_name'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">貸出日</span>
              <span class="info-value"><?php echo htmlspecialchars($return['checkout_date'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">返却予定日</span>
              <span class="info-value <?php echo $isOverdue ? 'overdue' : ''; ?>">
                <?php echo htmlspecialchars($return['return_date'] ?? '---', ENT_QUOTES, 'UTF-8'); ?>
                <?php if ($isOverdue): ?>
                  <?php
                  $returnDate = new DateTime($return['return_date']);
                  $today = new DateTime();
                  $diff = $today->diff($returnDate);
                  echo ' (' . $diff->days . '日超過)';
                  ?>
                <?php endif; ?>
              </span>
            </div>
          </div>
          
          <div class="return-card-actions">
            <button type="button" class="btn btn-return" 
                    onclick="approveReturn('<?php echo htmlspecialchars($return['user_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($return['book_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($return['reservation_date'], ENT_QUOTES, 'UTF-8'); ?>')">
              ✓ 返却完了
            </button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <script>
    // 検索機能
    const returnSearchInput = document.getElementById('returnSearchInput');
    const returnGrid = document.getElementById('returnGrid');
    
    if (returnSearchInput && returnGrid) {
      const allCards = Array.from(returnGrid.children);
      
      returnSearchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase().trim();
        let visibleCount = 0;
        
        allCards.forEach(card => {
          const text = card.textContent.toLowerCase();
          if (text.includes(searchTerm)) {
            card.style.display = '';
            visibleCount++;
          } else {
            card.style.display = 'none';
          }
        });
        
        const resultCountEl = document.getElementById('resultCount');
        if (resultCountEl) {
          resultCountEl.textContent = visibleCount;
        }
      });
    }
    
    async function approveReturn(userId, bookId,reservation_date) {
      if (!confirm('この本の返却を承認しますか？')) return;
      
      try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('book_id', bookId);
        formData.append('reservation_date', reservation_date);
        
        const response = await fetch('api/return_approval.php', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
          alert('返却を承認しました');
          location.reload();
        } else {
          alert('エラー: ' + (result.error || '承認に失敗しました'));
        }
      } catch (error) {
        console.error('返却承認エラー:', error);
        alert('通信エラーが発生しました');
      }
    }
  </script>
</div>
