<!-- ページ: 学生検索 -->
 <?php
require_once dirname(__DIR__) . '/api/db_config.php'; // 設定ファイルの読み込み

try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // --- user ---
    $sql_user = "SELECT user_id, user_name, school_id, user_grade, user_password, user_authority FROM {$DB_TABLE_USER}";
    $stmt_user = $dbh->query($sql_user);
    $users = $stmt_user->fetchAll(PDO::FETCH_ASSOC);

    // --- school ---
    $sql_school = "SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL}";
    $stmt_school = $dbh->query($sql_school);
    $schools = $stmt_school->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    exit('データ取得失敗: ' . $e->getMessage());
}

// --- 学年一覧を取得 (1, 2, 3, 4 だけを抽出) ---
// DISTINCT を使うことで重複を除外します
$sql_grade = "SELECT DISTINCT user_grade FROM {$DB_TABLE_USER} WHERE user_grade IS NOT NULL ORDER BY user_grade ASC";
$stmt_grade = $dbh->query($sql_grade);
$grades = $stmt_grade->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="admin-page" id="page-student-search">
  <h1>学生検索</h1>
  <form id="studentsSearchForm" class="search-form">
    <div class="form-row">
      <label>学生ID<br><input type="text" id="search-student-id" name="student_id" placeholder="例: stu001"></label>
      <label>学生名<br><input type="text" id="search-student-name" name="name" placeholder="名前で検索"></label>
    </div>
    <div class="form-row">
      <label>学校<br>
        <select id="school_id" name="school_id">
          <option value="">すべて</option>
          <?php foreach ($schools as $school): ?>
            <option value="<?php echo htmlspecialchars($school['school_id'], ENT_QUOTES, 'UTF-8'); ?>">
              <?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>学年<br>
  <select id="user_grade" name="user_grade">
    <option value="">すべて</option>
    <?php foreach ($grades as $row): ?>
      <option value="<?php echo htmlspecialchars($row['user_grade'], ENT_QUOTES, 'UTF-8'); ?>">
        <?php echo htmlspecialchars($row['user_grade'], ENT_QUOTES, 'UTF-8'); ?>年
      </option>
    <?php endforeach; ?>
  </select>
</label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">検索</button>
      <button type="button" id="studentsSearchReset" class="btn" style="background:#95a5a6;">リセット</button>
    </div>
  </form>
  <div id="studentsSearchResults" class="results" style="margin-top:12px;"></div>
</div>
