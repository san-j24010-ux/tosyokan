<!-- ページ: 学生更新・削除 -->
 <?php
require_once dirname(__DIR__) . '/api/db_config.php'; // 設定ファイルの読み込み

try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // --- user ---
    $sql_user = "SELECT user_id, user_name, school_id, user_grade, user_password, user_authority FROM {$DB_TABLE_USER}";
    $stmt_user = $dbh->query($sql_user);
    $users = $stmt_user->fetchAll(PDO::FETCH_ASSOC);

    // --- school ---
    $sql_school = "SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL}";
    $stmt_school = $dbh->query($sql_school);
    $schools = $stmt_school->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    exit('データ取得失敗: ' . $e->getMessage());
}

// --- 学年一覧を取得 (1, 2, 3, 4 だけを抽出) ---
// DISTINCT を使うことで重複を除外します
$sql_grade = "SELECT DISTINCT user_grade FROM {$DB_TABLE_USER} WHERE user_grade IS NOT NULL ORDER BY user_grade ASC";
$stmt_grade = $dbh->query($sql_grade);
$grades = $stmt_grade->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="admin-page" id="page-student-edit">
  <h1>学生更新・削除</h1>
  <div style="display:flex; gap:20px;">
    <div style="flex:1; display:none;">
      <h3>登録済みの学生一覧</h3>
      <div id="editStudentsList" class="results"></div>
    </div>
    <div style="flex:1;">
      <div id="studentEditPanel" style="display:none;">
        <h3>学生情報</h3>
        <form id="studentForm" class="search-form">
          <div class="form-row">
            <label>学生ID<br><input type="text" id="student-id" name="student_id" placeholder="例: stu001" readonly style="background:#f5f5f5;"></label>
          </div>
          <div class="form-row">
            <label>学生名<br><input type="text" id="student-name" name="name" placeholder="学生の名前を入力" required></label>
          </div>
          <div class="form-row">
            <label>新しいパスワード<br><input type="password" id="student-password" name="password" placeholder="変更する場合のみ入力"></label>
          </div>
          <div class="form-row">
            <label>学校<br>
              <select id="student-school" name="school_id" required>
                <option value="">選択してください</option>
                <?php foreach ($schools as $school): ?>
                  <option value="<?php echo htmlspecialchars($school['school_id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </label>
            <label>学年<br>
              <select id="student-grade" name="user_grade" required>
                <option value="">選択してください</option>
                <option value="1">1年</option>
                <option value="2">2年</option>
                <option value="3">3年</option>
                <option value="4">4年</option>
                <option value="5">5年</option>
                <option value="6">6年</option>
              </select>
            </label>
          </div>
          <div class="form-row">
            <label>権限<br>
              <select id="student-authority" name="authority">
                <option value="0">管理者</option>
                <option value="1">学生</option>
              </select>
            </label>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn">保存</button>
            <button type="button" id="deleteStudentBtn" class="btn" style="background:#e74c3c;">削除</button>
            <button type="button" id="cancelStudentBtn" class="btn" style="background:#95a5a6;">戻る</button>
          </div>
        </form>
        <div id="studentMessage" class="message"></div>
      </div>
      <div id="noStudentSelected" style="text-align:center; color:#999; padding:40px 0; display:block;">検索画面から学生を選択してください</div>
    </div>
  </div>
</div>
