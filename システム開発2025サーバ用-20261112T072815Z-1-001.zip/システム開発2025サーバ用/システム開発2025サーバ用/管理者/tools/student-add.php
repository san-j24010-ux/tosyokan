<!-- ページ: 学生追加 -->
<?php
ini_set('display_errors', 1);
require_once dirname(__DIR__) . '/api/db_config.php';

try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // --- school ---
    $sql_school = "SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL}";
    $stmt_school = $dbh->query($sql_school);
    $schools = $stmt_school->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $schools = [];
    error_log('データ取得失敗: ' . $e->getMessage());
}
?>
<div class="admin-page" id="page-student-add">
  <h1>学生追加</h1>
  <form id="addStudentForm" class="search-form">
    <div class="form-row">
      <label>学生ID<br><input type="text" id="new-student-id" name="student_id" placeholder="例: stu003" required></label>
    </div>
    <div class="form-row">
      <label>学生名<br><input type="text" id="new-student-name" name="name" placeholder="学生の名前を入力" required></label>
    </div>
    <div class="form-row">
      <label>パスワード<br><input type="password" id="new-student-password" name="password" placeholder="パスワードを入力" required></label>
    </div>
    <div class="form-row">
      <label>学校<br>
              <select id="school_id" name="school_id">
                <option value="">すべて</option>
                <?php foreach ($schools as $school): ?>
                  <option value="<?php echo htmlspecialchars($school['school_id'], ENT_QUOTES, 'UTF-8'); ?>">
                    <?php echo htmlspecialchars($school['school_name'], ENT_QUOTES, 'UTF-8'); ?>
                  </option>
                  <?php endforeach; ?>
                </select>
              </label>
      
    </div>
    <div class="form-row">
      <label>学年<br><input type="number" id="new-student-grade" name="grade" min="1" max="6" placeholder="学年を入力"></label>
    </div>
    <div class="form-row">
      <label>権限<br>
        <select id="new-student-authority" name="authority">
          <option value="0">学生</option>
          <option value="1">管理者</option>
        </select>
      </label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">追加</button>
    </div>
  </form>
  <div id="addStudentMessage" class="message"></div>
</div>
