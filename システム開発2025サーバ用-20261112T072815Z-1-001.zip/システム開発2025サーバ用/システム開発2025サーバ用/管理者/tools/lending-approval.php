<!-- ページ: 貸出承認 -->
<?php
// ログイン中のユーザーのschool_idを取得
$current_school_id = $_SESSION['school_id'] ?? null;

require_once dirname(__DIR__) . '/api/db_config.php';

$lendingData = [];
try {
    $dbh = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    // ログインユーザーのschool_idと本のschool_idが一致する貸出申請を取得
    if ($current_school_id) {
        $sql = "SELECT 
                    l.user_id,
                    l.book_id,
                    l.status_id,
                    l.checkout_date,
                    l.return_date,
                    l.reservation_date,
                    b.book_name,
                    b.isbn,
                    b.photograph,
                    b.school_id as book_school_id,
                    u.user_name,
                    s.school_name,
                    st.status_name
                FROM {$DB_TABLE_LEND} l
                INNER JOIN {$DB_TABLE_BOOK} b ON l.book_id = b.book_id
                LEFT JOIN {$DB_TABLE_USER} u ON l.user_id = u.user_id
                LEFT JOIN {$DB_TABLE_SCHOOL} s ON u.school_id = s.school_id
                LEFT JOIN {$DB_TABLE_STATUS} st ON l.status_id = st.status_id
                WHERE b.school_id = :school_id
                  AND l.status_id IN (2,6)
                  AND u.school_id = :school_id
                ORDER BY l.reservation_date ASC";
        
        $stmt = $dbh->prepare($sql);
        $stmt->execute([':school_id' => $current_school_id]);
        $lendingData = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    error_log('貸出データ取得失敗: ' . $e->getMessage());
}
?>

<div class="admin-page" id="page-lending-approval">
  <style>
    #page-lending-approval .page-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      border-radius: 10px;
      margin-bottom: 30px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    #page-lending-approval .page-header h1 {
      margin: 0 0 10px 0;
      font-size: 28px;
    }
    
    #page-lending-approval .page-header p {
      margin: 0;
      opacity: 0.9;
      font-size: 14px;
    }
    
    #page-lending-approval .direct-lending-form {
      background: white;
      padding: 25px;
      border-radius: 8px;
      margin-bottom: 25px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    #page-lending-approval .direct-lending-form h3 {
      margin: 0 0 20px 0;
      color: #667eea;
      font-size: 18px;
      border-bottom: 2px solid #667eea;
      padding-bottom: 10px;
    }
    
    #page-lending-approval .direct-lending-form .form-row {
      display: flex;
      gap: 15px;
      align-items: flex-end;
    }
    
    #page-lending-approval .direct-lending-form .form-group {
      flex: 1;
    }
    
    #page-lending-approval .direct-lending-form label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
      color: #333;
      font-size: 14px;
    }
    
    #page-lending-approval .direct-lending-form input {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
    }
    
    #page-lending-approval .direct-lending-form button {
      padding: 10px 30px;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      transition: background 0.3s;
    }
    
    #page-lending-approval .direct-lending-form button:hover {
      background: #5568d3;
    }
    
    #page-lending-approval .filter-section {
      background: white;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    #page-lending-approval .lending-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    #page-lending-approval .lending-card {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      transition: transform 0.2s, box-shadow 0.2s;
    }
    
    #page-lending-approval .lending-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    #page-lending-approval .lending-card-header {
      display: flex;
      gap: 15px;
      padding: 20px;
      background: #f8f9fa;
      border-bottom: 2px solid #e9ecef;
    }
    
    #page-lending-approval .lending-card-image {
      width: 80px;
      height: 120px;
      object-fit: cover;
      border-radius: 4px;
      flex-shrink: 0;
      background: #e0e0e0;
    }
    
    #page-lending-approval .lending-card-image-placeholder {
      width: 80px;
      height: 120px;
      background: linear-gradient(135deg, #e0e0e0, #c0c0c0);
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #666;
      font-size: 11px;
      text-align: center;
      flex-shrink: 0;
    }
    
    #page-lending-approval .lending-card-title {
      flex: 1;
    }
    
    #page-lending-approval .lending-card-title h3 {
      margin: 0 0 8px 0;
      font-size: 16px;
      color: #2c3e50;
      line-height: 1.4;
    }
    
    #page-lending-approval .lending-card-title .isbn {
      font-size: 12px;
      color: #7f8c8d;
      margin-bottom: 8px;
    }
    
    #page-lending-approval .status-badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 12px;
      font-size: 12px;
      font-weight: 600;
    }
    
    #page-lending-approval .status-pending {
      background: #fff3cd;
      color: #856404;
    }
    
    #page-lending-approval .status-approved {
      background: #d4edda;
      color: #155724;
    }
    
    #page-lending-approval .status-rejected {
      background: #f8d7da;
      color: #721c24;
    }
    
    #page-lending-approval .status-returned {
      background: #d1ecf1;
      color: #0c5460;
    }
    
    #page-lending-approval .lending-card-body {
      padding: 20px;
    }
    
    #page-lending-approval .info-row {
      display: flex;
      justify-content: space-between;
      padding: 8px 0;
      border-bottom: 1px solid #f0f0f0;
      font-size: 14px;
    }
    
    #page-lending-approval .info-row:last-child {
      border-bottom: none;
    }
    
    #page-lending-approval .info-label {
      color: #7f8c8d;
      font-weight: 500;
    }
    
    #page-lending-approval .info-value {
      color: #2c3e50;
      font-weight: 600;
    }
    
    #page-lending-approval .lending-card-actions {
      padding: 15px 20px;
      background: #f8f9fa;
      display: flex;
      gap: 10px;
      justify-content: flex-end;
    }
    
    #page-lending-approval .btn {
      padding: 8px 20px;
      border: none;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    
    #page-lending-approval .btn-approve {
      background: #28a745;
      color: white;
    }
    
    #page-lending-approval .btn-approve:hover {
      background: #218838;
    }
    
    #page-lending-approval .btn-reject {
      background: #dc3545;
      color: white;
    }
    
    #page-lending-approval .btn-reject:hover {
      background: #c82333;
    }
    
    #page-lending-approval .btn-disabled {
      background: #e0e0e0;
      color: #999;
      cursor: not-allowed;
    }
    
    #page-lending-approval .empty-state {
      text-align: center;
      padding: 60px 20px;
      color: #7f8c8d;
    }
    
    #page-lending-approval .empty-state-icon {
      font-size: 64px;
      margin-bottom: 20px;
      opacity: 0.5;
    }
    
    #page-lending-approval .empty-state-title {
      font-size: 20px;
      margin-bottom: 10px;
    }
    
    #page-lending-approval .empty-state-text {
      font-size: 14px;
    }
  </style>

  <div class="page-header">
    <h1>📋 貸出承認管理</h1>
    <p>あなたの学校の本に対する貸出申請を管理します</p>
  </div>

  <!-- 直接貸出登録フォーム -->
  <div class="direct-lending-form">
    <h3>🚀 直接貸出登録</h3>
    <form id="directLendingForm">
      <div class="form-row">
        <div class="form-group">
          <label for="direct_user_id">生徒ID</label>
          <input type="text" id="direct_user_id" name="user_id" required placeholder="例: j23001">
        </div>
        <div class="form-group">
          <label for="direct_book_id">本ID</label>
          <input type="number" id="direct_book_id" name="book_id" required placeholder="例: 1">
        </div>
        <button type="submit">貸出登録</button>
      </div>
    </form>
  </div>

  <?php if (!$current_school_id): ?>
    <div class="empty-state">
      <div class="empty-state-icon">⚠️</div>
      <div class="empty-state-title">学校情報が見つかりません</div>
      <div class="empty-state-text">ログインしているユーザーに学校が設定されていません。</div>
    </div>
  <?php elseif (empty($lendingData)): ?>
    <div class="empty-state">
      <div class="empty-state-icon">📭</div>
      <div class="empty-state-title">貸出申請がありません</div>
      <div class="empty-state-text">現在、承認待ちの貸出申請はありません。</div>
    </div>
  <?php else: ?>
    <!-- 検索フォーム -->
    <div class="filter-section">
      <input type="text" id="lendingSearchInput" placeholder="本のタイトル、ISBN、申請者名で検索..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 14px;">
    </div>
    
    <div style="background: #fff3cd; padding: 15px; margin-bottom: 20px; border-radius: 8px; font-size: 13px;">
      <strong>デバッグ情報:</strong> <span id="resultCount"><?php echo count($lendingData); ?></span>件の貸出データが見つかりました
    </div>
    <div class="lending-grid" id="lendingGrid">
      <?php foreach ($lendingData as $lending): ?>
        <div class="lending-card">
          <div class="lending-card-header">
            <?php if (!empty($lending['photograph'])): ?>
              <?php
              $imgSrc = $lending['photograph'];
              if (!preg_match('/^https?:\/\//', $imgSrc)) {
                $imgSrc = $lending['photograph'];
              }
              ?>
              <img src="<?php echo htmlspecialchars($imgSrc, ENT_QUOTES, 'UTF-8'); ?>" 
                   alt="表紙" 
                   class="lending-card-image"
                   onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
              <div class="lending-card-image-placeholder" style="display:none;">画像なし</div>
            <?php else: ?>
              <div class="lending-card-image-placeholder">画像なし</div>
            <?php endif; ?>
            
            <div class="lending-card-title">
              <h3><?php echo htmlspecialchars($lending['book_name'] ?? '(タイトル不明)', ENT_QUOTES, 'UTF-8'); ?></h3>
              <div class="isbn">ISBN: <?php echo htmlspecialchars($lending['isbn'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></div>
              <span class="status-badge status-pending">
                <?php echo htmlspecialchars($lending['status_name'] ?? '状態不明', ENT_QUOTES, 'UTF-8'); ?>
              </span>
            </div>
          </div>
          
          <div class="lending-card-body">
            <div class="info-row">
              <span class="info-label">申請者</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['user_name'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">学校</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['school_name'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row" style="background: #fff3cd;">
              <span class="info-label">本の所属School ID</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['book_school_id'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">予約日</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['reservation_date'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">貸出日</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['checkout_date'] ?? '未貸出', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="info-row">
              <span class="info-label">返却予定日</span>
              <span class="info-value"><?php echo htmlspecialchars($lending['return_date'] ?? '---', ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
          </div>
          
          <div class="lending-card-actions">
            <button type="button" class="btn btn-approve" 
                    onclick="approveLending('<?php echo htmlspecialchars($lending['user_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($lending['book_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($lending['reservation_date'], ENT_QUOTES, 'UTF-8'); ?>')">
              ✓ 承認
            </button>
            <button type="button" class="btn btn-reject"
                    onclick="rejectLending('<?php echo htmlspecialchars($lending['user_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($lending['book_id'], ENT_QUOTES, 'UTF-8'); ?>','<?php echo htmlspecialchars($lending['reservation_date'], ENT_QUOTES, 'UTF-8'); ?>')">
              ✗ 拒否
            </button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <script>
    // URLパラメータから値を取得してフォームに設定
    (function() {
      const urlParams = new URLSearchParams(window.location.search);
      const urlUserId = urlParams.get('user_id');
      const urlBookId = urlParams.get('book_id');
      
      if (urlUserId && urlBookId) {
        // 少し待ってからフォームに設定（DOM読み込み完了を待つ）
        setTimeout(() => {
          const userIdInput = document.getElementById('direct_user_id');
          const bookIdInput = document.getElementById('direct_book_id');
          
          if (userIdInput && bookIdInput) {
            userIdInput.value = urlUserId;
            bookIdInput.value = urlBookId;
          }
          
          // URLパラメータをクリア
          window.history.replaceState({}, '', 'admin.php');
        }, 100);
      }
    })();
    
    // 検索機能
    const lendingSearchInput = document.getElementById('lendingSearchInput');
    const lendingGrid = document.getElementById('lendingGrid');
    const allCards = lendingGrid ? Array.from(lendingGrid.children) : [];
    
    if (lendingSearchInput && lendingGrid) {
      lendingSearchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase().trim();
        let visibleCount = 0;
        
        allCards.forEach(card => {
          const text = card.textContent.toLowerCase();
          if (text.includes(searchTerm)) {
            card.style.display = '';
            visibleCount++;
          } else {
            card.style.display = 'none';
          }
        });
        
        const resultCount = document.getElementById('resultCount');
        if (resultCount) {
          resultCount.textContent = visibleCount;
        }
      });
    }
    
    async function approveLending(userId, bookId ,reservation_date) {
      if (!confirm('この貸出申請を承認しますか？')) return;
      
      try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('book_id', bookId);
        formData.append('action', 'approve');
        formData.append('reservation_date', reservation_date);
        
        const response = await fetch('api/lending_action.php', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
          alert('貸出を承認しました');
        } else {
          alert('エラー: ' + (result.error || '承認に失敗しました'));
        }
      } catch (error) {
        console.error('承認エラー:', error);
        alert('通信エラーが発生しました');
      }
    }
    
    async function rejectLending(userId, bookId, reservation_date) {
      if (!confirm('この貸出申請を拒否しますか？')) return;
      
      try {
        const formData = new FormData();
        formData.append('user_id', userId);
        formData.append('book_id', bookId);
        formData.append('action', 'reject');
        formData.append('reservation_date', reservation_date);
        
        const response = await fetch('api/lending_action.php', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
          alert('貸出を拒否しました');
        } else {
          alert('エラー: ' + (result.error || '拒否に失敗しました'));
        }
      } catch (error) {
        console.error('拒否エラー:', error);
        alert('通信エラーが発生しました');
      }
    }
    
    // 直接貸出登録フォーム
    const directLendingForm = document.getElementById('directLendingForm');
    if (directLendingForm) {
      directLendingForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const userId = document.getElementById('direct_user_id').value.trim();
        const bookId = document.getElementById('direct_book_id').value.trim();
        
        if (!userId || !bookId) {
          alert('生徒IDと本IDを入力してください');
          return;
        }
        
        try {
          const formData = new FormData();
          formData.append('user_id', userId);
          formData.append('book_id', bookId);
          formData.append('action', 'direct_lending');
          
          const response = await fetch('api/lending_action.php', {
            method: 'POST',
            body: formData
          });
          
          const result = await response.json();
          
          if (result.success) {
            alert('貸出を登録しました');
            document.getElementById('direct_user_id').value = '';
            document.getElementById('direct_book_id').value = '';
          } else {
            alert('エラー: ' + (result.error || '登録に失敗しました'));
          }
        } catch (error) {
          console.error('登録エラー:', error);
          alert('通信エラーが発生しました');
        }
      });
    }
  </script>
</div>
