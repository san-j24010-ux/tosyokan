<?php
header('Content-Type: application/json; charset=utf-8');
$cfg = __DIR__ . '/db_config.php';
if (!file_exists($cfg)) {
    echo json_encode(['success'=>false,'error'=>'db_config.php が見つかりません']);
    exit;
}
include $cfg;
if (empty($DB_HOST) || empty($DB_NAME) || !isset($DB_USER)) {
    echo json_encode(['success'=>false,'error'=>'db_config.php に接続情報が設定されていません']);
    exit;
}
try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    // テーブル存在チェック
    $table = $DB_TABLE ?? 'books';
    $stmt = $pdo->prepare("SHOW TABLES LIKE :t");
    $stmt->execute([':t'=>$table]);
    $exists = $stmt->fetchColumn() !== false;
    echo json_encode(['success'=>true,'message'=>'MySQL 接続成功','table_exists'=>$exists,'table'=>$table]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
