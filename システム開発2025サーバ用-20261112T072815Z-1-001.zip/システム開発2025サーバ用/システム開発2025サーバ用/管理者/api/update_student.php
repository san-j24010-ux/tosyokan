<?php
header('Content-Type: application/json; charset=utf-8');

session_start();

// ログインチェック
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => '権限がありません']);
    exit;
}

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$school_id = isset($_POST['school_id']) ? trim($_POST['school_id']) : '';
$grade = isset($_POST['user_grade']) ? trim($_POST['user_grade']) : '';
$authority = isset($_POST['authority']) ? intval($_POST['authority']) : null;

if (empty($student_id)) {
    echo json_encode(['success' => false, 'error' => '学生IDは必須です']);
    exit;
}

if (empty($name)) {
    echo json_encode(['success' => false, 'error' => '学生名は必須です']);
    exit;
}

if (empty($school_id)) {
    echo json_encode(['success' => false, 'error' => '学校は必須です']);
    exit;
}

if (empty($grade)) {
    echo json_encode(['success' => false, 'error' => '学年は必須です']);
    exit;
}

require_once __DIR__ . '/db_config.php';

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    // 更新処理: userテーブルを更新
    if (!empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_USER} SET user_name = ?, school_id = ?, user_grade = ?, user_password = ?, user_authority = ? WHERE user_id = ?");
        $stmt->execute([$name, $school_id, $grade, $hash, $authority ?? 0, $student_id]);
    } else {
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_USER} SET user_name = ?, school_id = ?, user_grade = ?, user_authority = ? WHERE user_id = ?");
        $stmt->execute([$name, $school_id, $grade, $authority ?? 0, $student_id]);
    }

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => '学生情報を更新しました']);
    } else {
        echo json_encode(['success' => false, 'error' => '学生が見つからないか、変更がありません']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
