<?php
// マスタデータ取得API
header('Content-Type: application/json; charset=utf-8');
require_once 'db_config.php';

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    $result = [
        'schools' => [],
        'genres' => [],
        'authors' => [],
        'statuses' => []
    ];

    // 学校一覧
    $stmt = $pdo->query("SELECT school_id, school_name FROM {$DB_TABLE_SCHOOL} ORDER BY school_name");
    $result['schools'] = $stmt->fetchAll();

    // ジャンル一覧
    $stmt = $pdo->query("SELECT genre_id, genre_name FROM {$DB_TABLE_GENRE} ORDER BY genre_name");
    $result['genres'] = $stmt->fetchAll();

    // 著者一覧
    $stmt = $pdo->query("SELECT author_id, author_name FROM {$DB_TABLE_AUTHOR} ORDER BY author_name");
    $result['authors'] = $stmt->fetchAll();

    // ステータス一覧
    $stmt = $pdo->query("SELECT status_id, status_name FROM {$DB_TABLE_STATUS} ORDER BY status_id");
    $result['statuses'] = $stmt->fetchAll();

    echo json_encode($result, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
