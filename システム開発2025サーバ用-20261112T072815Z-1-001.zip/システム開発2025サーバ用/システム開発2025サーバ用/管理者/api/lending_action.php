<?php
session_start();
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POSTメソッドのみ対応しています'], JSON_UNESCAPED_UNICODE);
    exit;
}

// ログインチェック
if (!isset($_SESSION['user_id']) || !isset($_SESSION['school_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => '認証が必要です'], JSON_UNESCAPED_UNICODE);
    exit;
}

$user_id = $_POST['user_id'] ?? '';
$book_id = $_POST['book_id'] ?? '';
$reservation_date = $_POST['reservation_date'] ?? '';
$action = $_POST['action'] ?? ''; // 'approve' or 'reject'

if (empty($user_id) || empty($book_id) || empty($action)) {
    echo json_encode(['success' => false, 'error' => '必要なパラメータが不足しています'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // 本の情報を取得（school_idとstatus_idを確認）
    $stmt = $pdo->prepare("SELECT school_id, status_id FROM {$DB_TABLE_BOOK} WHERE book_id = :book_id");
    $stmt->execute([':book_id' => $book_id]);
    $book = $stmt->fetch();
    
    if (!$book) {
        echo json_encode(['success' => false, 'error' => '本が見つかりません'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // 直接貸出登録の場合
    if ($action === 'direct_lending') {
        error_log('直接貸出登録: user_id=' . $user_id . ', book_id=' . $book_id);
        error_log('本の情報: school_id=' . $book['school_id'] . ', status_id=' . $book['status_id']);
        error_log('管理者のschool_id: ' . $_SESSION['school_id']);
        
        // 同じ学校の本のみ借りられる
        if ($book['school_id'] != $_SESSION['school_id']) {
            error_log('エラー: 他の学校の本');
            echo json_encode(['success' => false, 'error' => '他の学校の本は借りることができません'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // bookのstatus_idが4でないと貸出できない
        if ($book['status_id'] != 4) {
            error_log('エラー: status_id=' . $book['status_id'] . '（4ではない）');
            echo json_encode(['success' => false, 'error' => 'この本を借りることはできません（status_id=' . $book['status_id'] . '）'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    } else {
        // 承認・拒否の場合は権限チェック
        if ($book['school_id'] != $_SESSION['school_id']) {
            echo json_encode(['success' => false, 'error' => 'この本に対する権限がありません'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // 貸出レコードの存在確認
    if ($action !== 'direct_lending') {
        $stmt = $pdo->prepare("SELECT * FROM {$DB_TABLE_LEND} WHERE user_id = :user_id AND book_id = :book_id AND reservation_date = :reservation_date");
        $stmt->execute([':user_id' => $user_id, ':book_id' => $book_id, ':reservation_date' => $reservation_date]);
        $lending = $stmt->fetch();
        
        if (!$lending) {
            echo json_encode(['success' => false, 'error' => '貸出申請が見つかりません'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    if ($action === 'approve') {

    // ban の有無を判定（空文字＝BANなし）
    $isBan = !empty($lending['ban']);

    if (!$isBan) {
        // 🔹 BANなし：今まで通りの処理
        $stmt = $pdo->prepare("
            UPDATE {$DB_TABLE_LEND}
            SET status_id = 1,
                checkout_date = CURDATE(),
                return_date = DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            WHERE user_id = :user_id
              AND book_id = :book_id
              AND reservation_date = :reservation_date
        ");
    } else {
        // 🔸 BANあり：status_idのみ変更
        $stmt = $pdo->prepare("
            UPDATE {$DB_TABLE_LEND}
            SET status_id = 1
            WHERE user_id = :user_id
              AND book_id = :book_id
              AND reservation_date = :reservation_date
        ");
    }

    $stmt->execute([
        ':user_id' => $user_id,
        ':book_id' => $book_id,
        ':reservation_date' => $reservation_date
    ]);

        // bookテーブルのstatus_idを1（貸出中）に更新
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_BOOK} 
                              SET status_id = 1 
                              WHERE book_id = :book_id");
        $stmt->execute([':book_id' => $book_id]);

    echo json_encode([
        'success' => true,
        'message' => $isBan
            ? '貸出を承認しました（BANのため日付は更新されません）'
            : '貸出を承認しました'
    ], JSON_UNESCAPED_UNICODE);
}elseif ($action === 'reject') {
        // 拒否: レコードを削除（またはstatus_idを拒否状態に更新）
        $stmt = $pdo->prepare("DELETE FROM {$DB_TABLE_LEND} 
                               WHERE user_id = :user_id AND book_id = :book_id AND reservation_date = :reservation_date");
        $stmt->execute([':user_id' => $user_id, ':book_id' => $book_id, ':reservation_date' => $reservation_date]);
        
        echo json_encode(['success' => true, 'message' => '貸出を拒否しました'], JSON_UNESCAPED_UNICODE);
        
    } elseif ($action === 'direct_lending') {
        // 直接貸出登録: 貸出日=今日、返却日=7日後、status_id=1（貸出中）で新規登録
        
        // ユーザーの存在確認とschool_idの取得
        $stmt = $pdo->prepare("SELECT * FROM {$DB_TABLE_USER} WHERE user_id = :user_id");
        $stmt->execute([':user_id' => $user_id]);
        $user = $stmt->fetch();
        
        error_log('生徒情報: ' . json_encode($user));
        error_log('管理者school_id: ' . $_SESSION['school_id']);
        
        if (!$user) {
            error_log('エラー: 生徒が見つかりません（user_id=' . $user_id . '）');
            echo json_encode(['success' => false, 'error' => '指定された生徒IDが見つかりません'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // 生徒が自分の学校の生徒かチェック
        if ($user['school_id'] != $_SESSION['school_id']) {
            error_log('エラー: 他校の生徒（生徒school_id=' . $user['school_id'] . ', 管理者school_id=' . $_SESSION['school_id'] . '）');
            echo json_encode(['success' => false, 'error' => '他の学校の生徒には本を貸し出せません'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // 既に同じ貸出が存在しないか確認
        $stmt = $pdo->prepare("SELECT * FROM {$DB_TABLE_LEND} WHERE user_id = :user_id AND book_id = :book_id AND status_id = 1");
        $stmt->execute([':user_id' => $user_id, ':book_id' => $book_id]);
        $existing = $stmt->fetch();
        
        if ($existing) {
            echo json_encode(['success' => false, 'error' => 'この本は既に貸出登録されています'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        
        // 新規貸出レコードを作成
        $stmt = $pdo->prepare("INSERT INTO {$DB_TABLE_LEND} 
                               (user_id, book_id, status_id, checkout_date, return_date, reservation_date)
                               VALUES (:user_id, :book_id, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY), CURDATE())");
        $stmt->execute([
            ':user_id' => $user_id,
            ':book_id' => $book_id
        ]);
        
        // bookテーブルのstatus_idを1（貸出中）に更新
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_BOOK} 
                              SET status_id = 1 
                              WHERE book_id = :book_id");
        $stmt->execute([':book_id' => $book_id]);
        
        echo json_encode(['success' => true, 'message' => '貸出を登録しました（返却期限: 7日後）'], JSON_UNESCAPED_UNICODE);
        
    } else {
        echo json_encode(['success' => false, 'error' => '不明なアクションです'], JSON_UNESCAPED_UNICODE);
    }

} catch (PDOException $e) {
    http_response_code(500);
    error_log('貸出処理エラー: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'データベースエラーが発生しました'], JSON_UNESCAPED_UNICODE);
}
