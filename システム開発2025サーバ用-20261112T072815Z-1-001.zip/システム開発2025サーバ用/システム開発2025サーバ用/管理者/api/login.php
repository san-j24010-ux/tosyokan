<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if (empty($student_id) || empty($password)) {
    echo json_encode(['success' => false, 'error' => '学生IDとパスワードは必須です']);
    exit;
}

// MySQL 設定を読み込み
$cfg = __DIR__ . '/db_config.php';
if (!file_exists($cfg)) {
    echo json_encode(['success' => false, 'error' => 'MySQL 設定ファイルが見つかりません']);
    exit;
}
include $cfg;

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // students テーブルから検索
    $stmt = $pdo->prepare("SELECT student_id, password_hash, name FROM students WHERE student_id = :id LIMIT 1");
    $stmt->execute([':id' => $student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($student && password_verify($password, $student['password_hash'])) {
        // ログイン成功
        $_SESSION['student_id'] = $student['student_id'];
        $_SESSION['student_name'] = $student['name'];
        $_SESSION['logged_in_at'] = time();
        echo json_encode(['success' => true, 'student_id' => $student['student_id'], 'message' => 'ログイン成功']);
    } else {
        echo json_encode(['success' => false, 'error' => '学生IDまたはパスワードが正しくありません']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'ログイン処理でエラーが発生しました: ' . $e->getMessage()]);
}
