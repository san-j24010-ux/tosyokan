<?php
// 発送確認用API
header('Content-Type: application/json; charset=utf-8');

try {
    $db_host = 'localhost';
    $db_name = 'books';
    $db_user = 'root';
    $db_pass = '';
    $charset = 'utf8mb4';
    
    $dsn = "mysql:host=$db_host;dbname=$db_name;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
    
    $sql = "SELECT * FROM book WHERE 1=1";
    $params = [];
    
    if (!empty($_GET['student_number'])) {
        $sql .= " AND student_number LIKE :student_number";
        $params[':student_number'] = '%' . $_GET['student_number'] . '%';
    }
    
    if (!empty($_GET['isbn'])) {
        $sql .= " AND isbn LIKE :isbn";
        $params[':isbn'] = '%' . $_GET['isbn'] . '%';
    }
    
    if (!empty($_GET['year'])) {
        $sql .= " AND year = :year";
        $params[':year'] = trim($_GET['year']);
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $results = $stmt->fetchAll();
    
    echo json_encode($results, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
