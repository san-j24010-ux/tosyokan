<?php
session_start();

require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POSTメソッドのみ対応しています'], JSON_UNESCAPED_UNICODE);
    exit;
}

// ログインチェック
if (!isset($_SESSION['user_id']) || !isset($_SESSION['school_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => '認証が必要です'], JSON_UNESCAPED_UNICODE);
    exit;
}

$user_id = $_POST['user_id'] ?? '';
$book_id = $_POST['book_id'] ?? '';
$reservation_date = $_POST['reservation_date'] ?? '';

if (empty($user_id) || empty($book_id)) {
    echo json_encode(['success' => false, 'error' => '必要なパラメータが不足しています'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // 本のschool_idがログインユーザーのschool_idと一致するか確認（削除 - 他の学校の本も返却承認できるように）
    // $stmt = $pdo->prepare("SELECT school_id FROM {$DB_TABLE_BOOK} WHERE book_id = :book_id");
    // $stmt->execute([':book_id' => $book_id]);
    // $book = $stmt->fetch();
    
    // if (!$book) {
    //     echo json_encode(['success' => false, 'error' => '本が見つかりません'], JSON_UNESCAPED_UNICODE);
    //     exit;
    // }
    
    // if ($book['school_id'] != $_SESSION['school_id']) {
    //     echo json_encode(['success' => false, 'error' => 'この本に対する権限がありません'], JSON_UNESCAPED_UNICODE);
    //     exit;
    // }
    
    // 本の情報を取得
    $stmt = $pdo->prepare("SELECT school_id FROM {$DB_TABLE_BOOK} WHERE book_id = :book_id");
    $stmt->execute([':book_id' => $book_id]);
    $book = $stmt->fetch();
    
    if (!$book) {
        echo json_encode(['success' => false, 'error' => '本が見つかりません'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 貸出レコードの存在確認（借りた人のschool_idも取得）
    $stmt = $pdo->prepare("SELECT l.*, u.school_id as user_school_id 
                          FROM {$DB_TABLE_LEND} l
                          LEFT JOIN {$DB_TABLE_USER} u ON l.user_id = u.user_id
                          WHERE l.user_id = :user_id AND l.book_id = :book_id");
    $stmt->execute([':user_id' => $user_id, ':book_id' => $book_id]);
    $lending = $stmt->fetch();
    
    if (!$lending) {
        echo json_encode(['success' => false, 'error' => '貸出レコードが見つかりません'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 返却承認: lendテーブルのstatus_idを5に更新
    $stmt = $pdo->prepare("UPDATE {$DB_TABLE_LEND} 
                          SET status_id = 5 
                          WHERE user_id = :user_id AND book_id = :book_id AND reservation_date = :reservation_date");
    $stmt->execute([':user_id' => $user_id, ':book_id' => $book_id,':reservation_date' => $reservation_date]);
    
    // bookのschool_idと管理者のschool_idが違う場合、本の所属を管理者の学校に変更
    $book_school_id = $book['school_id'];
    $admin_school_id = $_SESSION['school_id'];
    
    if ($book_school_id != $admin_school_id) {
        // bookテーブルのschool_idを管理者のschool_idに変更し、status_idを4に更新
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_BOOK} 
                              SET status_id = 4, school_id = :new_school_id 
                              WHERE book_id = :book_id");
        $stmt->execute([':new_school_id' => $admin_school_id, ':book_id' => $book_id]);
    } else {
        // 同じ学校の場合はstatus_idのみ更新
        $stmt = $pdo->prepare("UPDATE {$DB_TABLE_BOOK} 
                              SET status_id = 4 
                              WHERE book_id = :book_id");
        $stmt->execute([':book_id' => $book_id]);
    }
    
    echo json_encode(['success' => true, 'message' => '返却を承認しました（保管状態）'], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);

    error_log('返却承認エラー: ' . $e->getMessage());

    echo json_encode([
        'success' => false,
        'error'   => $e->getMessage(),
        'code'    => $e->getCode()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

