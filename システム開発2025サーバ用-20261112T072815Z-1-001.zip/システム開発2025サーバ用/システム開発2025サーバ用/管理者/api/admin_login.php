<?php
header('Content-Type: application/json; charset=utf-8');
session_start();

$admin_id = isset($_POST['admin_id']) ? trim($_POST['admin_id']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if (empty($admin_id) || empty($password)) {
    echo json_encode(['success' => false, 'error' => '管理者IDとパスワードは必須です']);
    exit;
}

// MySQL 設定を読み込み
$cfg = __DIR__ . '/db_config.php';
if (!file_exists($cfg)) {
    echo json_encode(['success' => false, 'error' => 'MySQL 設定ファイルが見つかりません']);
    exit;
}
include $cfg;

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // admins テーブルから検索
    $stmt = $pdo->prepare("SELECT user_id,user_authority,name FROM users WHERE user_id = :id");
    $stmt->execute([':id' => $admin_id]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && $admin["user_authority"] == 1) {
        // ログイン成功
        $_SESSION['admin_id'] = $admin['user_id'];
        $_SESSION['admin_name'] = $admin['name'];
        $_SESSION['logged_in_at'] = time();
        echo json_encode(['success' => true, 'admin_id' => $admin['admin_id'], 'message' => 'ログイン成功']);
    } else {
        echo json_encode(['success' => false, 'error' => '管理者IDまたはパスワードが正しくありません']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'ログイン処理でエラーが発生しました: ' . $e->getMessage()]);
}
