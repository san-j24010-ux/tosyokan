<?php
header('Content-Type: application/json; charset=utf-8');

$student_id = isset($_GET['student_id']) ? trim($_GET['student_id']) : '';
$status = isset($_GET['status']) ? trim($_GET['status']) : ''; // 'borrowed' or 'returned'

if (empty($student_id)) {
    echo json_encode(['error' => 'student_id が必須です']);
    http_response_code(400);
    exit;
}

// MySQL 設定を読み込み
$cfg = __DIR__ . '/db_config.php';
if (!file_exists($cfg)) {
    echo json_encode(['error' => 'MySQL 設定ファイルが見つかりません']);
    http_response_code(500);
    exit;
}
include $cfg;

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // 履歴テーブルを想定: borrow_history (student_id, book_id, book_title, book_author, borrow_date, due_date, returned_date)
    $sql = "SELECT book_id, book_title, book_author, borrow_date, due_date, returned_date FROM borrow_history WHERE student_id = :id";
    $params = [':id' => $student_id];

    if ($status === 'borrowed') {
        $sql .= " AND returned_date IS NULL";
    } elseif ($status === 'returned') {
        $sql .= " AND returned_date IS NOT NULL";
    }

    $sql .= " ORDER BY borrow_date DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($records, JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    // テーブル不在の場合はダミーデータを返す（デモ）
    if (strpos($e->getMessage(), 'borrow_history') !== false || strpos($e->getMessage(), '1146') !== false) {
        // ダミー履歴データを返す
        $dummyHistory = [
            [
                'book_id' => '001-001',
                'book_title' => '線形代数入門',
                'book_author' => '山田 太郎',
                'borrow_date' => '2025-12-01',
                'due_date' => '2025-12-15',
                'returned_date' => null
            ],
            [
                'book_id' => '002-002',
                'book_title' => '古代の歴史',
                'book_author' => '佐藤 花子',
                'borrow_date' => '2025-11-20',
                'due_date' => '2025-12-04',
                'returned_date' => '2025-12-03'
            ]
        ];
        echo json_encode($dummyHistory, JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
}
