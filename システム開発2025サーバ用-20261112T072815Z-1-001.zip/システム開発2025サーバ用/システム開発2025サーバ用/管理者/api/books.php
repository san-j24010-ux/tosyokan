<?php
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    // 検索パラメータ
    $isbn = isset($_GET['isbn']) ? trim($_GET['isbn']) : '';
    $title = isset($_GET['title']) ? trim($_GET['title']) : '';
    $author = isset($_GET['author']) ? trim($_GET['author']) : '';
    $genre = isset($_GET['genre']) ? trim($_GET['genre']) : '';
    $location = isset($_GET['location']) ? trim($_GET['location']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : '';

    // JOINを使用して関連テーブルから情報を取得
    $sql = "SELECT 
                b.book_id,
                b.isbn,
                b.book_name AS title,
                a.author_name AS author,
                g.genre_name AS genre,
                s.school_name AS location,
                st.status_name AS status,
                b.photograph
            FROM {$DB_TABLE_BOOK} b
            LEFT JOIN {$DB_TABLE_AUTHOR} a ON b.author_id = a.author_id
            LEFT JOIN {$DB_TABLE_GENRE} g ON b.genre_id = g.genre_id
            LEFT JOIN {$DB_TABLE_SCHOOL} s ON b.school_id = s.school_id
            LEFT JOIN {$DB_TABLE_STATUS} st ON b.status_id = st.status_id
            WHERE 1=1";
    
    $params = [];

    if ($isbn !== '') {
        $sql .= " AND b.isbn LIKE :isbn";
        $params[':isbn'] = '%' . $isbn . '%';
    }
    if ($title !== '') {
        $sql .= " AND b.book_name LIKE :title";
        $params[':title'] = '%' . $title . '%';
    }
    if ($author !== '') {
        $sql .= " AND a.author_name LIKE :author";
        $params[':author'] = '%' . $author . '%';
    }
    if ($genre !== '') {
        $sql .= " AND g.genre_name = :genre";
        $params[':genre'] = $genre;
    }
    if ($location !== '') {
        $sql .= " AND s.school_name = :location";
        $params[':location'] = $location;
    }
    if ($status !== '') {
        $sql .= " AND st.status_name = :status";
        $params[':status'] = $status;
    }

    $sql .= " ORDER BY b.book_name";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $books = $stmt->fetchAll();

    echo json_encode($books, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'データベースエラー: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

