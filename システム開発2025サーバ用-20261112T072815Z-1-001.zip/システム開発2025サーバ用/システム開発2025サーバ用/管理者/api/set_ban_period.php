<?php
header('Content-Type: application/json; charset=utf-8');

session_start();

// ログインチェック
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => '権限がありません'], JSON_UNESCAPED_UNICODE);
    exit;
}

$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : 0;
$start_date = isset($_POST['start_date']) ? trim($_POST['start_date']) : '';
$end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : '';
$user_id = $_SESSION['user_id'];

if (!$book_id || !$start_date || !$end_date) {
    echo json_encode(['success' => false, 'error' => '必須項目が入力されていません'], JSON_UNESCAPED_UNICODE);
    exit;
}

// 日付の妥当性チェック
$today = date('Y-m-d');
if ($start_date < $today) {
    echo json_encode(['success' => false, 'error' => '開始日は今日以降の日付を指定してください'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($start_date > $end_date) {
    echo json_encode(['success' => false, 'error' => '開始日は終了日より前の日付を指定してください'], JSON_UNESCAPED_UNICODE);
    exit;
}

require_once __DIR__ . '/db_config.php';

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    
    // 本の存在確認
    $stmt = $pdo->prepare("SELECT book_id FROM {$DB_TABLE_BOOK} WHERE book_id = ?");
    $stmt->execute([$book_id]);
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$book) {
        echo json_encode(['success' => false, 'error' => '指定された本が見つかりません'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // lendテーブルに登録
    // checkout_date: 禁止期間開始日
    // return_date: 禁止期間終了日
    // reservation_date: 今日の日付
    // user_id: ログイン中のユーザー
    // status_id: 2（予約）
    $today = date('Y-m-d');
    
    $stmt = $pdo->prepare("INSERT INTO {$DB_TABLE_LEND} (user_id, book_id, status_id, checkout_date, return_date, reservation_date, ban) 
                          VALUES (:user_id, :book_id, 2, :checkout_date, :return_date, :reservation_date, 1)");
    $stmt->execute([
        ':user_id' => $user_id,
        ':book_id' => $book_id,
        ':checkout_date' => $start_date,
        ':return_date' => $end_date,
        ':reservation_date' => $today
    ]);
    
    echo json_encode(['success' => true, 'message' => '禁止期間を設定しました'], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    error_log('禁止期間設定エラー: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'データベースエラーが発生しました: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
