<?php
require_once dirname(__DIR__) . '/api/db_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);

    // 1. 入力値の取得
    $isbn      = $_POST['isbn']      ?? '';
    $title     = $_POST['title']     ?? '';
    $author    = $_POST['author']    ?? '';
    $genre_id  = $_POST['genre']     ?? '';    // 数値が入る
    $school_id = $_POST['school_id'] ?? '';    // 数値が入る

    if (!$isbn || !$title || !$author || !$genre_id || !$school_id) {
        throw new Exception('全ての項目を入力してください');
    }

    // 2. 著者(author)の処理
    // 名前からIDを取得、なければ新規作成(AUTxxx)する便利なロジック
    $stmt = $pdo->prepare("SELECT author_id FROM {$DB_TABLE_AUTHOR} WHERE author_name = ?");
    $stmt->execute([$author]);
    $author_id = $stmt->fetchColumn();

    if (!$author_id) {
        // 新規著者IDの生成
        $stmt = $pdo->prepare("SELECT author_id FROM {$DB_TABLE_AUTHOR} ORDER BY author_id DESC LIMIT 1");
        $stmt->execute();
        $lastId = $stmt->fetchColumn();
        $nextNum = $lastId ? (int)substr($lastId, 3) + 1 : 1;
        $author_id = 'AUT' . str_pad($nextNum, 3, '0', STR_PAD_LEFT);

        $pdo->prepare("INSERT INTO {$DB_TABLE_AUTHOR} (author_id, author_name) VALUES (?, ?)")
            ->execute([$author_id, $author]);
    }

    // 3. 画像の処理 (isbn.png という名前で保存)
    $photograph = '';  // デフォルトは空文字列
    if (isset($_FILES['photograph']) && $_FILES['photograph']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['photograph']['name'], PATHINFO_EXTENSION);
        $fileName = $isbn . '.' . $ext;
        if (move_uploaded_file($_FILES['photograph']['tmp_name'], __DIR__ . '/../covers/' . $fileName)) {
            $photograph = $fileName;
        }
    }

    // 4. bookテーブルへの挿入
    $sql = "INSERT INTO {$DB_TABLE_BOOK} 
            (isbn, school_id, book_name, author_id, genre_id, status_id, photograph) 
            VALUES (:isbn, :school_id, :book_name, :author_id, :genre_id, :status_id, :photograph)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':isbn'        => $isbn,
        ':school_id'   => $school_id, // 1, 2, 3 などの数値
        ':book_name'   => $title,
        ':author_id'   => $author_id, // AUT001 などのID
        ':genre_id'    => $genre_id,  // 1, 2, 3 などの数値
        ':status_id'   => 4,          // 初期状態：保管
        ':photograph'  => $photograph
    ]);

    echo json_encode(['success' => true, 'message' => '本を追加しました']);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}