<?php
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

$book_id = isset($_POST['book_id']) ? intval($_POST['book_id']) : null;

if ($book_id === null || $book_id < 0) {
    echo json_encode(['success' => false, 'error' => '本IDが必須です']);
    exit;
}

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    // まず本のステータスを確認
    $stmt = $pdo->prepare("SELECT status_id FROM {$DB_TABLE_BOOK} WHERE book_id = :book_id");
    $stmt->execute([':book_id' => $book_id]);
    $book = $stmt->fetch();

    if (!$book) {
        echo json_encode(['success' => false, 'error' => '本が見つかりません']);
        exit;
    }

    // status_idが4（保管）以外は削除不可
    if ($book['status_id'] != 4) {
        echo json_encode(['success' => false, 'error' => '保管状態の本のみ削除できます']);
        exit;
    }

    // 削除実行
    $stmt = $pdo->prepare("DELETE FROM {$DB_TABLE_BOOK} WHERE book_id = :book_id");
    $stmt->execute([':book_id' => $book_id]);

    echo json_encode(['success' => true, 'message' => '本を削除しました']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'データベースエラー: ' . $e->getMessage()]);
}
