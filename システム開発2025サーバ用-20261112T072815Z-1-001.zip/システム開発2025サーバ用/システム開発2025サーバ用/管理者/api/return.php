<?php
header('Content-Type: application/json; charset=utf-8');

$isbn = isset($_POST['isbn']) ? trim($_POST['isbn']) : '';
if ($isbn === '') { echo json_encode(['success' => false, 'error' => 'isbn が指定されていません']); exit; }

// Try MySQL
$useMysql = false; $cfg = __DIR__ . '/db_config.php';
if (file_exists($cfg)) { include $cfg; if (!empty($DB_HOST) && !empty($DB_NAME) && isset($DB_USER)) $useMysql = true; }

if ($useMysql) {
    try {
        $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $table = $DB_TABLE ?? 'books';
        $colIsbn = $COL_ISBN ?? 'isbn';

        // If table has return_date/returned columns, update them; otherwise attempt best-effort
        $stmt = $pdo->prepare("UPDATE `{$table}` SET `returned` = 1, `return_date` = CURDATE() WHERE `{$colIsbn}` = :isbn");
        $stmt->execute([':isbn'=>$isbn]);
        if ($stmt->rowCount() > 0) { echo json_encode(['success'=>true]); } else { echo json_encode(['success'=>false,'error'=>'該当する本が見つかりませんでした']); }
        exit;
    } catch (Exception $e) {
        error_log('return.php MySQL error: ' . $e->getMessage());
        // fall through to sqlite
    }
}

// SQLite fallback
$dbDir = __DIR__ . '/../db'; if (!is_dir($dbDir)) mkdir($dbDir,0755,true); $dbFile = $dbDir . '/books.db';
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->prepare('UPDATE books SET returned = 1, return_date = date("now") WHERE isbn = :isbn');
    $stmt->execute([':isbn' => $isbn]);
    if ($stmt->rowCount() > 0) { echo json_encode(['success' => true]); } else { echo json_encode(['success' => false, 'error' => '該当する本が見つかりませんでした']); }
} catch (Exception $e) { http_response_code(500); echo json_encode(['success' => false, 'error' => $e->getMessage()]); }
