<?php
// MySQL 接続設定ファイル

$DB_HOST = 'localhost';
$DB_NAME = 'Library';
$DB_USER = 'user01';
$DB_PASS = 'user01';
$DB_CHARSET = 'utf8mb4';

// DSN
$DB_DSN = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";

// テーブル名定数
$DB_TABLE_SCHOOL = 'school';
$DB_TABLE_USER = 'users';
$DB_TABLE_GENRE = 'genre';
$DB_TABLE_STATUS = 'status';
$DB_TABLE_AUTHOR = 'author';
$DB_TABLE_BOOK = 'book';
$DB_TABLE_LEND = 'lend';

