<?php
header('Content-Type: application/json; charset=utf-8');

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$current_password = isset($_POST['current_password']) ? $_POST['current_password'] : '';
$new_password = isset($_POST['new_password']) ? $_POST['new_password'] : '';

if (empty($student_id) || empty($current_password) || empty($new_password)) {
    echo json_encode(['success' => false, 'error' => '全ての項目は必須です']);
    exit;
}

if (strlen($new_password) < 6) {
    echo json_encode(['success' => false, 'error' => 'パスワードは6文字以上である必要があります']);
    exit;
}

// MySQL 設定を読み込み
$cfg = __DIR__ . '/db_config.php';
if (!file_exists($cfg)) {
    echo json_encode(['success' => false, 'error' => 'MySQL 設定ファイルが見つかりません']);
    exit;
}
include $cfg;

// デモ用の簡易認証
$demoStudents = [
    'stu001' => 'password123',
    'stu002' => 'password456',
];

if (isset($demoStudents[$student_id]) && $demoStudents[$student_id] === $current_password) {
    // デモモードではパスワード変更を承認する（実際には保存しない）
    echo json_encode(['success' => true, 'message' => 'パスワードを変更しました（デモモード）']);
    exit;
}

// 本番用：MySQL の students テーブルで確認・更新
try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // students テーブルから現在のパスワードハッシュを取得
    $stmt = $pdo->prepare("SELECT password_hash FROM students WHERE student_id = :id LIMIT 1");
    $stmt->execute([':id' => $student_id]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$student) {
        echo json_encode(['success' => false, 'error' => '学生が見つかりません']);
        exit;
    }

    // 現在のパスワードを確認
    if (!password_verify($current_password, $student['password_hash'])) {
        echo json_encode(['success' => false, 'error' => '現在のパスワードが正しくありません']);
        exit;
    }

    // 新しいパスワードをハッシュ化して更新
    $newHash = password_hash($new_password, PASSWORD_DEFAULT);
    $updateStmt = $pdo->prepare("UPDATE students SET password_hash = :hash WHERE student_id = :id");
    $updateStmt->execute([':hash' => $newHash, ':id' => $student_id]);

    echo json_encode(['success' => true, 'message' => 'パスワードを変更しました']);
} catch (Exception $e) {
    if (strpos($e->getMessage(), 'students') !== false || strpos($e->getMessage(), '1146') !== false) {
        echo json_encode(['success' => true, 'message' => 'パスワード変更を承認しました（デモモード - DB 未設定）']);
    } else {
        echo json_encode(['success' => false, 'error' => 'パスワード変更処理でエラー: ' . $e->getMessage()]);
    }
}
