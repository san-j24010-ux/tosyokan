<?php
header('Content-Type: application/json; charset=utf-8');

session_start();

// 管理者チェック
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => '権限がありません']);
    exit;
}

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';

if (empty($student_id)) {
    echo json_encode(['success' => false, 'error' => '学生IDは必須です']);
    exit;
}

require_once __DIR__ . '/db_config.php';

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    $stmt = $pdo->prepare("DELETE FROM student WHERE Student_number = ?");
    $stmt->execute([$student_id]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => '学生を削除しました']);
    } else {
        echo json_encode(['success' => false, 'error' => '学生が見つかりません']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
