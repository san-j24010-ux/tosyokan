<?php
/**
 * アカウント管理 CLI ツール
 * コマンドラインから学生・管理者アカウントを登録・削除・確認できます
 * 
 * 使用例:
 * - php manage_accounts.php create-student stu001 password123 "山田太郎"
 * - php manage_accounts.php create-admin admin001 adminpass "管理者"
 * - php manage_accounts.php list-accounts
 * - php manage_accounts.php delete-account stu001
 */

require_once __DIR__ . '/api/db_config.php';

if (php_sapi_name() !== 'cli') {
    die("このスクリプトはコマンドラインからのみ実行できます。\n");
}

$command = $argv[1] ?? '';

function getConnection() {
    global $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS, $DB_CHARSET;
    if (empty($DB_HOST) || empty($DB_NAME)) {
        die("エラー: MySQL 設定が不完全です。api/db_config.php を確認してください。\n");
    }
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    return new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
}

function createTablesIfNotExist($pdo) {
    try {
        // students テーブル
        $pdo->exec("CREATE TABLE IF NOT EXISTS students (
            student_id VARCHAR(50) PRIMARY KEY,
            password_hash VARCHAR(255) NOT NULL,
            name VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        // admins テーブル
        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            admin_id VARCHAR(50) PRIMARY KEY,
            password_hash VARCHAR(255) NOT NULL,
            name VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        echo "✓ テーブルを確認しました。\n";
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        exit(1);
    }
}

function createStudentAccount($id, $password, $name = '') {
    try {
        $pdo = getConnection();
        createTablesIfNotExist($pdo);

        // ID の重複チェック
        $stmt = $pdo->prepare("SELECT student_id FROM students WHERE student_id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetch()) {
            echo "エラー: 学生ID '{$id}' は既に存在します。\n";
            return false;
        }

        // パスワードをハッシュ化して挿入
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO students (student_id, password_hash, name) VALUES (?, ?, ?)");
        $stmt->execute([$id, $hash, $name ?: '']);
        echo "✓ 学生アカウントを作成しました。\n";
        echo "  学生ID: {$id}\n";
        echo "  名前: " . ($name ?: '（なし）') . "\n";
        return true;
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        return false;
    }
}

function createAdminAccount($id, $password, $name = '') {
    try {
        $pdo = getConnection();
        createTablesIfNotExist($pdo);

        // ID の重複チェック
        $stmt = $pdo->prepare("SELECT admin_id FROM admins WHERE admin_id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetch()) {
            echo "エラー: 管理者ID '{$id}' は既に存在します。\n";
            return false;
        }

        // パスワードをハッシュ化して挿入
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO admins (admin_id, password_hash, name) VALUES (?, ?, ?)");
        $stmt->execute([$id, $hash, $name ?: '']);
        echo "✓ 管理者アカウントを作成しました。\n";
        echo "  管理者ID: {$id}\n";
        echo "  名前: " . ($name ?: '（なし）') . "\n";
        return true;
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        return false;
    }
}

function listAccounts() {
    try {
        $pdo = getConnection();
        createTablesIfNotExist($pdo);

        echo "\n=== 学生アカウント ===\n";
        $stmt = $pdo->query("SELECT student_id, name, created_at FROM students ORDER BY created_at DESC");
        $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($students) {
            foreach ($students as $s) {
                echo "- {$s['student_id']} ({$s['name']}) 作成: {$s['created_at']}\n";
            }
        } else {
            echo "  （アカウントなし）\n";
        }

        echo "\n=== 管理者アカウント ===\n";
        $stmt = $pdo->query("SELECT admin_id, name, created_at FROM admins ORDER BY created_at DESC");
        $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if ($admins) {
            foreach ($admins as $a) {
                echo "- {$a['admin_id']} ({$a['name']}) 作成: {$a['created_at']}\n";
            }
        } else {
            echo "  （アカウントなし）\n";
        }
        echo "\n";
        return true;
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        return false;
    }
}

function deleteAccount($id, $type = 'student') {
    try {
        $pdo = getConnection();
        
        if ($type === 'student') {
            $stmt = $pdo->prepare("DELETE FROM students WHERE student_id = ?");
        } else {
            $stmt = $pdo->prepare("DELETE FROM admins WHERE admin_id = ?");
        }
        
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) {
            echo "✓ アカウント '{$id}' を削除しました。\n";
            return true;
        } else {
            echo "エラー: アカウント '{$id}' が見つかりません。\n";
            return false;
        }
    } catch (Exception $e) {
        echo "エラー: " . $e->getMessage() . "\n";
        return false;
    }
}

function showHelp() {
    echo <<<'HELP'
アカウント管理 CLI ツール

使用方法:
  php manage_accounts.php <command> [arguments]

コマンド一覧:
  create-student <ID> <PASSWORD> [名前]
    学生アカウントを作成します
    例: php manage_accounts.php create-student stu001 password123 "山田太郎"

  create-admin <ID> <PASSWORD> [名前]
    管理者アカウントを作成します
    例: php manage_accounts.php create-admin admin001 adminpass "田中管理者"

  create-demo
    デモアカウントを自動作成します（学生1名、管理者1名）
    - 学生ID: stu001 / パスワード: password123
    - 管理者ID: admin001 / パスワード: adminpass

  list-accounts
    すべてのアカウントを表示します

  delete-account <ID> [type]
    アカウントを削除します（type: student or admin, デフォルト: student）
    例: php manage_accounts.php delete-account stu001 student

  help
    このヘルプを表示します

HELP;
}

function createDemoAccounts() {
    echo "デモアカウントを作成中...\n\n";
    
    // 学生アカウント
    echo "【学生アカウント】\n";
    createStudentAccount('stu001', 'password123', '学生太郎');
    echo "\n";
    
    // 管理者アカウント
    echo "【管理者アカウント】\n";
    createAdminAccount('admin001', 'adminpass', '管理者花子');
    echo "\n";
    
    echo "デモアカウント作成が完了しました。\n";
}

// コマンド実行
if ($command === 'create-student') {
    createStudentAccount($argv[2] ?? '', $argv[3] ?? '', $argv[4] ?? '');
} elseif ($command === 'create-admin') {
    createAdminAccount($argv[2] ?? '', $argv[3] ?? '', $argv[4] ?? '');
} elseif ($command === 'create-demo') {
    createDemoAccounts();
} elseif ($command === 'list-accounts') {
    listAccounts();
} elseif ($command === 'delete-account') {
    deleteAccount($argv[2] ?? '', $argv[3] ?? 'student');
} elseif ($command === 'help' || $command === '-h' || $command === '--help') {
    showHelp();
} elseif ($command === '') {
    showHelp();
} else {
    echo "不明なコマンド: {$command}\n";
    showHelp();
}
