document.addEventListener('DOMContentLoaded', ()=>{
  function escapeHtml(s){
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  const menuItems = document.querySelectorAll('.menu-item');
  const pages = document.querySelectorAll('.page');

  function showPage(pageName){
    pages.forEach(p=>p.style.display='none');
    document.getElementById('page-' + pageName).style.display='block';
    menuItems.forEach(m=>m.classList.remove('active'));
    document.querySelector(`[data-page="${pageName}"]`).classList.add('active');
  }

  menuItems.forEach(item=>{
    item.addEventListener('click', ()=>{
      const pageName = item.getAttribute('data-page');
      showPage(pageName);
      if(pageName === 'list') loadAllBooks();
      if(pageName === 'edit') loadBooksForEdit();
    });
  });

  const searchForm = document.getElementById('searchForm');
  const resultsEl = document.getElementById('results');
  const sortOrder = document.getElementById('sortOrder');

  function renderResults(list){
    resultsEl.innerHTML = '';
    if(!list || list.length === 0){
      resultsEl.innerHTML = '<p class="muted">該当する本が見つかりませんでした。</p>';
      return;
    }
    list.forEach(b=>{
      const card = document.createElement('article');
      card.className = 'card';
      const cover = document.createElement('div');
      cover.className = 'cover';
      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.innerHTML = `<p><strong>書籍番号:</strong> ${escapeHtml(b.isbn)}</p><p><strong>本の題名:</strong> ${escapeHtml(b.title)}</p><p><strong>本の著者名:</strong> ${escapeHtml(b.author)}</p><p class="muted"><strong>本のジャンル:</strong> ${escapeHtml(b.genre)} <span class="right"><strong>本の場所:</strong> ${escapeHtml(b.location)}</span></p>`;
      card.appendChild(cover);
      card.appendChild(meta);
      resultsEl.appendChild(card);
    });
  }

  async function doSearch(){
    const f = new FormData(searchForm);
    const params = new URLSearchParams();
    for (const [k,v] of f.entries()){
      if (v.trim() !== '') params.append(k, v.trim());
    }
    const sort = sortOrder.value;
    params.set('sort', sort);
    const url = 'api/books.php?' + params.toString();
    try{
      const res = await fetch(url);
      if(!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      renderResults(data);
    }catch(err){
      resultsEl.innerHTML = `<p class="muted">エラーが発生しました: ${escapeHtml(err.message)}</p>`;
    }
  }

  searchForm.addEventListener('submit', e=>{ e.preventDefault(); doSearch(); });
  sortOrder.addEventListener('change', ()=>doSearch());

  const addForm = document.getElementById('addForm');
  const addMessage = document.getElementById('addMessage');

  addForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(addForm);
    const body = new URLSearchParams(fd);
    try{
      const res = await fetch('api/add.php', {method:'POST', body});
      const json = await res.json();
      if(json.success){
        addMessage.textContent = '本を追加しました！';
        addMessage.className = 'message success';
        addMessage.style.display = 'block';
        addForm.reset();
        setTimeout(()=>{ addMessage.style.display='none'; }, 3000);
      }else{
        throw new Error(json.error || '追加に失敗しました');
      }
    }catch(err){
      addMessage.textContent = 'エラー: ' + err.message;
      addMessage.className = 'message error';
      addMessage.style.display = 'block';
    }
  });

  const allResults = document.getElementById('allResults');

  async function loadAllBooks(){
    try{
      const res = await fetch('api/books.php');
      if(!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      renderToElement(allResults, data);
    }catch(err){
      allResults.innerHTML = `<p class="muted">エラー: ${escapeHtml(err.message)}</p>`;
    }
  }

  function renderToElement(el, list){
    el.innerHTML = '';
    if(!list || list.length === 0){
      el.innerHTML = '<p class="muted">本がありません。</p>';
      return;
    }
    list.forEach(b=>{
      const card = document.createElement('article');
      card.className = 'card';
      const cover = document.createElement('div');
      cover.className = 'cover';
      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.innerHTML = `<p><strong>書籍番号:</strong> ${escapeHtml(b.isbn)}</p><p><strong>本の題名:</strong> ${escapeHtml(b.title)}</p><p><strong>本の著者名:</strong> ${escapeHtml(b.author)}</p><p class="muted"><strong>本のジャンル:</strong> ${escapeHtml(b.genre)} <span class="right"><strong>本の場所:</strong> ${escapeHtml(b.location)}</span></p>`;
      card.appendChild(cover);
      card.appendChild(meta);
      el.appendChild(card);
    });
  }

  const editBooksList = document.getElementById('editBooksList');
  const editPanel = document.getElementById('editPanel');
  const noSelection = document.getElementById('noSelection');
  const editForm = document.getElementById('editForm');
  const editMessage = document.getElementById('editMessage');
  const deleteBtn = document.getElementById('deleteBtn');
  const cancelBtn = document.getElementById('cancelBtn');
  let currentBookId = null;

  async function loadBooksForEdit(){
    try{
      const res = await fetch('api/books.php');
      if(!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      renderBooksForEdit(data);
    }catch(err){
      editBooksList.innerHTML = `<p class="muted">エラー: ${escapeHtml(err.message)}</p>`;
    }
  }

  function renderBooksForEdit(list){
    editBooksList.innerHTML = '';
    if(!list || list.length === 0){
      editBooksList.innerHTML = '<p class="muted">本がありません。</p>';
      return;
    }
    list.forEach((b, idx)=>{
      const item = document.createElement('div');
      item.className = 'book-item';
      item.innerHTML = `<div><strong>${escapeHtml(b.title)}</strong></div><div class="book-meta">${escapeHtml(b.author)} / ${escapeHtml(b.isbn)}</div>`;
      item.addEventListener('click', ()=>selectBookForEdit(b, idx));
      editBooksList.appendChild(item);
    });
  }

  function selectBookForEdit(book, idx){
    currentBookId = book.isbn;
    document.querySelectorAll('#editBooksList .book-item').forEach((el,i)=>{
      el.classList.toggle('selected', i===idx);
    });
    document.getElementById('edit-isbn').value = book.isbn;
    document.getElementById('edit-title').value = book.title;
    document.getElementById('edit-author').value = book.author;
    document.getElementById('edit-genre').value = book.genre;
    document.getElementById('edit-location').value = book.location;
    editPanel.style.display = 'block';
    noSelection.style.display = 'none';
    editMessage.style.display = 'none';
  }

  editForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const fd = new FormData(editForm);
    const body = new URLSearchParams(fd);
    body.append('oldIsbn', currentBookId);
    try{
      const res = await fetch('api/update.php', {method:'POST', body});
      const json = await res.json();
      if(json.success){
        editMessage.textContent = '本を更新しました！';
        editMessage.className = 'message success';
        editMessage.style.display = 'block';
        setTimeout(()=>{ loadBooksForEdit(); editPanel.style.display='none'; noSelection.style.display='block'; }, 1500);
      }else{
        throw new Error(json.error || '更新に失敗しました');
      }
    }catch(err){
      editMessage.textContent = 'エラー: ' + err.message;
      editMessage.className = 'message error';
      editMessage.style.display = 'block';
    }
  });

  deleteBtn.addEventListener('click', async ()=>{
    if(!confirm('この本を削除しますか？')) return;
    const body = new URLSearchParams({isbn: currentBookId});
    try{
      const res = await fetch('api/delete.php', {method:'POST', body});
      const json = await res.json();
      if(json.success){
        editMessage.textContent = '本を削除しました！';
        editMessage.className = 'message success';
        editMessage.style.display = 'block';
        setTimeout(()=>{ loadBooksForEdit(); editPanel.style.display='none'; noSelection.style.display='block'; }, 1500);
      }else{
        throw new Error(json.error || '削除に失敗しました');
      }
    }catch(err){
      editMessage.textContent = 'エラー: ' + err.message;
      editMessage.className = 'message error';
      editMessage.style.display = 'block';
    }
  });

  cancelBtn.addEventListener('click', ()=>{
    editPanel.style.display = 'none';
    noSelection.style.display = 'block';
    currentBookId = null;
    document.querySelectorAll('#editBooksList .book-item').forEach(el=>el.classList.remove('selected'));
  });

  doSearch();
});
