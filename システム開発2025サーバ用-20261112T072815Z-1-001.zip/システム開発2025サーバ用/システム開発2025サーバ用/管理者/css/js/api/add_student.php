<?php
header('Content-Type: application/json; charset=utf-8');

session_start();

// 管理者チェック
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => '権限がありません']);
    exit;
}

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$school = isset($_POST['school']) ? trim($_POST['school']) : '';
$grade = isset($_POST['grade']) ? trim($_POST['grade']) : '';
$authority = isset($_POST['authority']) ? intval($_POST['authority']) : 0;

if (empty($student_id) || empty($password)) {
    echo json_encode(['success' => false, 'error' => '学生IDとパスワードは必須です']);
    exit;
}

require_once __DIR__ . '/db_config.php';

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // ID の重複チェック
    $stmt = $pdo->prepare("SELECT Student_number FROM student WHERE Student_number = ?");
    $stmt->execute([$student_id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'error' => '学生ID は既に存在します']);
        exit;
    }

    // パスワードをハッシュ化して挿入 (Student_password カラムに保存)
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO student (Student_number, Student_name, Student_school, Student_grade, Student_password, Student_authority) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$student_id, $name, $school, $grade, $hash, $authority]);

    echo json_encode(['success' => true, 'message' => '学生を追加しました']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
