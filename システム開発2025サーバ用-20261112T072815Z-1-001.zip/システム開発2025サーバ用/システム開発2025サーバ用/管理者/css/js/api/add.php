<?php
header('Content-Type: application/json; charset=utf-8');

// 入力取得
$isbn = isset($_POST['isbn']) ? trim($_POST['isbn']) : '';
$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$author = isset($_POST['author']) ? trim($_POST['author']) : '';
$genre = isset($_POST['genre']) ? trim($_POST['genre']) : '';
$location = isset($_POST['location']) ? trim($_POST['location']) : '';

if (empty($isbn) || empty($title) || empty($author) || empty($genre) || empty($location)) {
    echo json_encode(['success' => false, 'error' => '全ての項目は必須です']);
    exit;
}

// まず MySQL 設定があるか確認
$useMysql = false;
$mysqlConfigFile = __DIR__ . '/db_config.php';
if (file_exists($mysqlConfigFile)) {
    include $mysqlConfigFile; // 期待: $DB_HOST, $DB_NAME, $DB_USER, $DB_PASS, $DB_TABLE, カラム変数
    if (!empty($DB_HOST) && !empty($DB_NAME) && isset($DB_USER)) {
        $useMysql = true;
    }
}

// MySQL に接続できればそこに挿入、できなければ既存の SQLite を使う
if ($useMysql) {
    try {
        $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);

        // テーブル名・カラム名の指定（設定ファイルで変更可能）
        $table = isset($DB_TABLE) && $DB_TABLE ? $DB_TABLE : 'books';
        $colIsbn = isset($COL_ISBN) && $COL_ISBN ? $COL_ISBN : 'isbn';
        $colTitle = isset($COL_TITLE) && $COL_TITLE ? $COL_TITLE : 'title';
        $colAuthor = isset($COL_AUTHOR) && $COL_AUTHOR ? $COL_AUTHOR : 'author';
        $colGenre = isset($COL_GENRE) && $COL_GENRE ? $COL_GENRE : 'genre';
        $colLocation = isset($COL_LOCATION) && $COL_LOCATION ? $COL_LOCATION : 'location';

        $sql = "INSERT INTO `{$table}` (`{$colIsbn}`, `{$colTitle}`, `{$colAuthor}`, `{$colGenre}`, `{$colLocation}`) VALUES (:isbn,:title,:author,:genre,:location)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':isbn'=>$isbn, ':title'=>$title, ':author'=>$author, ':genre'=>$genre, ':location'=>$location]);

        echo json_encode(['success' => true, 'message' => '本を MySQL に追加しました']);
        exit;
    } catch (Exception $e) {
        // MySQL 接続/挿入失敗 -> フォールバックで SQLite に書き込む
        error_log('MySQL error in add.php: ' . $e->getMessage());
        // 続けて SQLite へフォールバック
    }
}

// SQLite フォールバック（既存の動作）
$dbDir = __DIR__ . '/../db';
$dbFile = $dbDir . '/books.db';
if (!is_dir($dbDir)) { mkdir($dbDir, 0755, true); }
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('INSERT INTO books (isbn,title,author,genre,location) VALUES (?,?,?,?,?)');
    $stmt->execute([$isbn, $title, $author, $genre, $location]);

    echo json_encode(['success' => true, 'message' => '本を SQLite に追加しました']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
