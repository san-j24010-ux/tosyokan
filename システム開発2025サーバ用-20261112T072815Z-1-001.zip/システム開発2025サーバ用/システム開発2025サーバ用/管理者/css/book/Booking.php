<?php
class Book {
    private $studentNumber;
    private $isbn;
    private $title;
    private $genre;
    private $author;
    private $loanDate; // 貸出日
    
    // データベース接続情報
    private static $host = 'localhost';
    private static $dbname = '図書館';
    private static $username = 'root';
    private static $password = '';
    
    public function __construct($studentNumber = '', $isbn = '', $title = '', $genre = '', $author = '', $loanDate = '') {
        $this->studentNumber = $studentNumber;
        $this->isbn = $isbn;
        $this->title = $title;
        $this->genre = $genre;
        $this->author = $author;
        $this->loanDate = $loanDate;
    }
    
    // データベース接続を取得
    private static function getConnection() {
        try {
            $pdo = new PDO(
                "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4",
                self::$username,
                self::$password,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            return $pdo;
        } catch (PDOException $e) {
            die("データベース接続エラー: " . $e->getMessage());
        }
    }
    
    public function getStudentNumber() {
        return $this->studentNumber;
    }
    
    public function getIsbn() {
        return $this->isbn;
    }
    
    public function getTitle() {
        return $this->title;
    }
    
    public function getGenre() {
        return $this->genre;
    }
    
    public function getAuthor() {
        return $this->author;
    }
    
    public function getLoanDate() {
        return $this->loanDate;
    }
    
    // 全書籍を取得
    public static function getAll() {
        $pdo = self::getConnection();
        $stmt = $pdo->query("SELECT * FROM book1");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // ジャンル一覧を取得
    public static function getAllGenres() {
        $pdo = self::getConnection();
        $stmt = $pdo->query("SELECT DISTINCT genre FROM book1 WHERE genre IS NOT NULL AND genre != '' ORDER BY genre");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 書籍を検索
    public static function search($studentNumber = '', $isbn = '', $title = '', $genre = '', $author = '', $loanDate = '') {
        $pdo = self::getConnection();
        
        $sql = "SELECT * FROM book1 WHERE 1=1";
        $params = [];
        
        if (!empty($studentNumber)) {
            $sql .= " AND student_number LIKE ?";
            $params[] = '%' . $studentNumber . '%';
        }
        
        if (!empty($isbn)) {
            $sql .= " AND isbn LIKE ?";
            $params[] = '%' . $isbn . '%';
        }
        
        if (!empty($title)) {
            $sql .= " AND title LIKE ?";
            $params[] = '%' . $title . '%';
        }
        
        if (!empty($genre)) {
            $sql .= " AND genre = ?";
            $params[] = $genre;
        }
        
        if (!empty($author)) {
            $sql .= " AND author LIKE ?";
            $params[] = '%' . $author . '%';
        }
        
        if (!empty($loanDate)) {
            $sql .= " AND publisher LIKE ?";
            $params[] = '%' . $loanDate . '%';
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>