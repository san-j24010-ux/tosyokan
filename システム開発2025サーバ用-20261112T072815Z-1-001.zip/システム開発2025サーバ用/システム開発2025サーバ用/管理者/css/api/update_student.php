<?php
header('Content-Type: application/json; charset=utf-8');

session_start();

// 管理者チェック
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'error' => '権限がありません']);
    exit;
}

$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$school = isset($_POST['school']) ? trim($_POST['school']) : '';
$grade = isset($_POST['grade']) ? trim($_POST['grade']) : '';
$authority = isset($_POST['authority']) ? intval($_POST['authority']) : null;

if (empty($student_id)) {
    echo json_encode(['success' => false, 'error' => '学生IDは必須です']);
    exit;
}

require_once __DIR__ . '/db_config.php';

try {
    $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

    // 更新処理: 学生テーブルの Student_* カラムを更新
    if (!empty($password)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE student SET Student_name = ?, Student_school = ?, Student_grade = ?, Student_password = ?, Student_authority = ? WHERE Student_number = ?");
        $stmt->execute([$name, $school, $grade, $hash, $authority ?? 0, $student_id]);
    } else {
        $stmt = $pdo->prepare("UPDATE student SET Student_name = ?, Student_school = ?, Student_grade = ?, Student_authority = ? WHERE Student_number = ?");
        $stmt->execute([$name, $school, $grade, $authority ?? 0, $student_id]);
    }

    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => '学生情報を更新しました']);
    } else {
        echo json_encode(['success' => false, 'error' => '学生が見つからないか、変更がありません']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
