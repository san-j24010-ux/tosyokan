<?php
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    $user_id = isset($_GET['student_id']) ? trim($_GET['student_id']) : '';
    $name = isset($_GET['name']) ? trim($_GET['name']) : '';
    $school = isset($_GET['school']) ? trim($_GET['school']) : '';
    $grade = isset($_GET['grade']) ? trim($_GET['grade']) : '';

    $sql = "SELECT 
                u.user_id AS student_id,
                u.user_name AS name,
                s.school_name AS school,
                u.user_grade AS grade,
                u.user_authority AS authority
            FROM {$DB_TABLE_USER} u
            LEFT JOIN {$DB_TABLE_SCHOOL} s ON u.school_id = s.school_id
            WHERE 1=1";
    $params = [];

    if (!empty($user_id)) {
        $sql .= " AND u.user_id LIKE :user_id";
        $params[':user_id'] = '%' . $user_id . '%';
    }
    if (!empty($name)) {
        $sql .= " AND u.user_name LIKE :name";
        $params[':name'] = '%' . $name . '%';
    }
    if (!empty($school)) {
        $sql .= " AND s.school_name = :school";
        $params[':school'] = $school;
    }
    if (!empty($grade)) {
        $sql .= " AND u.user_grade = :grade";
        $params[':grade'] = $grade;
    }

    $sql .= " ORDER BY u.user_id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $students = $stmt->fetchAll();

    echo json_encode($students, JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'データベースエラー: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

