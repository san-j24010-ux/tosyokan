<?php
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    // 入力取得
    $isbn = isset($_POST['isbn']) ? trim($_POST['isbn']) : '';
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $author = isset($_POST['author']) ? trim($_POST['author']) : '';
    $genre = isset($_POST['genre']) ? trim($_POST['genre']) : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';

    if (empty($isbn) || empty($title) || empty($author) || empty($genre) || empty($location)) {
        echo json_encode(['success' => false, 'error' => '全ての項目は必須です'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 画像アップロード処理
    $photograph = null;
    if (isset($_FILES['photograph']) && $_FILES['photograph']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../covers/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileExtension = pathinfo($_FILES['photograph']['name'], PATHINFO_EXTENSION);
        $fileName = $isbn . '.' . $fileExtension;
        $uploadPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['photograph']['tmp_name'], $uploadPath)) {
            $photograph = $fileName;
        }
    }

    // school_idの解決
    $school_id = null;
    if (!empty($location)) {
        $stmt = $pdo->prepare("SELECT school_id FROM {$DB_TABLE_SCHOOL} WHERE school_name = :school_name");
        $stmt->execute([':school_name' => $location]);
        $result = $stmt->fetch();
        $school_id = $result ? $result['school_id'] : null;
    }

    // author_idの解決（存在しなければ追加）
    $author_id = null;
    if (!empty($author)) {
        $stmt = $pdo->prepare("SELECT author_id FROM {$DB_TABLE_AUTHOR} WHERE author_name = :author_name");
        $stmt->execute([':author_name' => $author]);
        $result = $stmt->fetch();
        if ($result) {
            $author_id = $result['author_id'];
        } else {
            // 新しいauthor_idを生成（AUT + ゼロ埋め連番）
            $stmt = $pdo->prepare("SELECT author_id FROM {$DB_TABLE_AUTHOR} ORDER BY author_id DESC LIMIT 1");
            $stmt->execute();
            $lastAuthor = $stmt->fetch();
            if ($lastAuthor && preg_match('/^AUT(\\d+)$/', $lastAuthor['author_id'], $matches)) {
                $nextNum = intval($matches[1]) + 1;
            } else {
                $nextNum = 1;
            }
            $author_id = 'AUT' . str_pad($nextNum, 3, '0', STR_PAD_LEFT);
            
            $stmt = $pdo->prepare("INSERT INTO {$DB_TABLE_AUTHOR} (author_id, author_name) VALUES (:author_id, :author_name)");
            $stmt->execute([':author_id' => $author_id, ':author_name' => $author]);
        }
    }

    // genre_idの解決
    $genre_id = null;
    if (!empty($genre)) {
        $stmt = $pdo->prepare("SELECT genre_id FROM {$DB_TABLE_GENRE} WHERE genre_name = :genre_name");
        $stmt->execute([':genre_name' => $genre]);
        $result = $stmt->fetch();
        $genre_id = $result ? $result['genre_id'] : null;
    }

    // デフォルトstatus_idは1（利用可能）と仮定
    $status_id = 1;

    // book挿入
    $sql = "INSERT INTO {$DB_TABLE_BOOK} (isbn, school_id, book_name, author_id, genre_id, status_id, photograph) 
            VALUES (:isbn, :school_id, :book_name, :author_id, :genre_id, :status_id, :photograph)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':isbn' => $isbn,
        ':school_id' => $school_id,
        ':book_name' => $title,
        ':author_id' => $author_id,
        ':genre_id' => $genre_id,
        ':status_id' => $status_id,
        ':photograph' => $photograph
    ]);

    echo json_encode(['success' => true, 'message' => '本を追加しました'], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'データベースエラー: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
