<?php
header('Content-Type: application/json; charset=utf-8');

$isbn = isset($_POST['isbn']) ? trim($_POST['isbn']) : '';
if (empty($isbn)) {
    echo json_encode(['success' => false, 'error' => '書籍番号が必須です']);
    exit;
}

// Try MySQL if configured
$useMysql = false;
$cfg = __DIR__ . '/db_config.php';
if (file_exists($cfg)) { include $cfg; if (!empty($DB_HOST) && !empty($DB_NAME) && isset($DB_USER)) $useMysql = true; }

if ($useMysql) {
    try {
        $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=" . ($DB_CHARSET ?? 'utf8mb4');
        $pdo = new PDO($dsn, $DB_USER, $DB_PASS ?? '', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
        $table = $DB_TABLE ?? 'books';
        $colIsbn = $COL_ISBN ?? 'isbn';

        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE `{$colIsbn}` = :isbn");
        $stmt->execute([':isbn'=>$isbn]);
        echo json_encode(['success'=>true,'message'=>'本を MySQL から削除しました']);
        exit;
    } catch (Exception $e) {
        error_log('delete.php MySQL error: ' . $e->getMessage());
        // fall through to sqlite
    }
}

// SQLite fallback
$dbDir = __DIR__ . '/../db'; $dbFile = $dbDir . '/books.db'; if (!is_dir($dbDir)) mkdir($dbDir,0755,true);
try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('DELETE FROM books WHERE isbn = ?');
    $stmt->execute([$isbn]);

    echo json_encode(['success' => true, 'message' => '本を削除しました']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
