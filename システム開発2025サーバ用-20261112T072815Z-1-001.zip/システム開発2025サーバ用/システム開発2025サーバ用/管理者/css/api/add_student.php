<?php
require_once 'db_config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'POSTメソッドのみ対応しています'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);

    $user_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $school = isset($_POST['school']) ? trim($_POST['school']) : '';
    $grade = isset($_POST['grade']) ? trim($_POST['grade']) : '';
    $authority = isset($_POST['authority']) ? intval($_POST['authority']) : 0;

    if (empty($user_id) || empty($name) || empty($password)) {
        echo json_encode(['success' => false, 'error' => '学籍番号、名前、パスワードは必須です'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 学籍番号の重複チェック
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM {$DB_TABLE_USER} WHERE user_id = :user_id");
    $stmt->execute([':user_id' => $user_id]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['success' => false, 'error' => 'この学籍番号は既に登録されています'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // school_idを取得（school_nameから）
    $school_id = null;
    if (!empty($school)) {
        $stmt = $pdo->prepare("SELECT school_id FROM {$DB_TABLE_SCHOOL} WHERE school_name = :school_name");
        $stmt->execute([':school_name' => $school]);
        $result = $stmt->fetch();
        $school_id = $result ? $result['school_id'] : null;
    }

    // パスワードをハッシュ化
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO {$DB_TABLE_USER} (user_id, user_name, school_id, user_grade, user_password, user_authority) 
            VALUES (:user_id, :user_name, :school_id, :user_grade, :user_password, :user_authority)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $user_id,
        ':user_name' => $name,
        ':school_id' => $school_id,
        ':user_grade' => $grade,
        ':user_password' => $hashed_password,
        ':user_authority' => $authority
    ]);

    echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'データベースエラー: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

