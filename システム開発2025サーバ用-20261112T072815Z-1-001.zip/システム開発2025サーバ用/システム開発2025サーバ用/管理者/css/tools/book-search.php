<!-- ページ: 本を検索 -->
<div class="admin-page active" id="page-search">
  <h1>本を検索</h1>
  <form id="searchForm" class="search-form">
    <div class="form-row">
      <label>書籍番号<br><input type="text" id="isbn" name="isbn" placeholder="例: 001-001"></label>
      <label>本の題名<br><input type="text" id="title" name="title" placeholder="題名を入力"></label>
    </div>
    <div class="form-row">
      <label>本の著者名<br><input type="text" id="author" name="author" placeholder="著者名を入力"></label>
      <label>本のジャンル<br>
        <select id="genre" name="genre">
          <option value="">すべて</option>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>本の場所<br>
        <select id="location" name="location">
          <option value="">すべて</option>
        </select>
      </label>
      <label>返却期間（開始）<br><input type="date" id="start_date" name="start_date"></label>
    </div>
    <div class="form-row">
      <label>返却期間（終了）<br><input type="date" id="end_date" name="end_date"></label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">検索</button>
    </div>
  </form>
  <section id="results" class="results"></section>
</div>
