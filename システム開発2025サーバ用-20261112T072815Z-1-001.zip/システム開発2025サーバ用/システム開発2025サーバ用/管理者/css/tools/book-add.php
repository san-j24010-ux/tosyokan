<!-- ページ: 本を追加 -->
<div class="admin-page" id="page-manage">
  <h1>本を追加</h1>
  <form id="addForm" class="search-form">
    <div class="form-row">
      <label>書籍番号<br><input type="text" id="add-isbn" name="isbn" placeholder="例: 006-006" required></label>
      <label>本の題名<br><input type="text" id="add-title" name="title" placeholder="題名を入力" required></label>
    </div>
    <div class="form-row">
      <label>本の著者名<br><input type="text" id="add-author" name="author" placeholder="著者名を入力" required></label>
      <label>本のジャンル<br>
        <select id="add-genre" name="genre" required>
          <option value="">選択してください</option>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>本の場所<br>
        <select id="add-location" name="location" required>
          <option value="">選択してください</option>
        </select>
      </label>
    </div>
    <div class="form-row">
      <label>表紙画像<br>
        <input type="file" id="add-photograph" name="photograph" accept="image/*">
      </label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">追加</button>
    </div>
  </form>
  <div id="addMessage" class="message"></div>
</div>
