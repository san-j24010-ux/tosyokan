<!-- ページ: 学生更新・削除 -->
<div class="admin-page" id="page-student-edit">
  <h1>学生更新・削除</h1>
  <div style="display:flex; gap:20px;">
    <div style="flex:1; display:none;">
      <h3>登録済みの学生一覧</h3>
      <div id="editStudentsList" class="results"></div>
    </div>
    <div style="flex:1;">
      <div id="studentEditPanel" style="display:none;">
        <h3>学生情報</h3>
        <form id="studentForm" class="search-form">
          <div class="form-row">
            <label>学生ID<br><input type="text" id="student-id" name="student_id" placeholder="例: stu001" readonly style="background:#f5f5f5;"></label>
          </div>
          <div class="form-row">
            <label>学生名<br><input type="text" id="student-name" name="name" placeholder="学生の名前を入力" required></label>
          </div>
          <div class="form-row">
            <label>新しいパスワード<br><input type="password" id="student-password" name="password" placeholder="変更する場合のみ入力"></label>
          </div>
          <div class="form-row">
            <label>学校<br>
              <select id="student-school" name="school"></select>
            </label>
          </div>
          <div class="form-row">
            <label>学年<br><input type="number" id="student-grade" name="grade" min="1" max="6" placeholder="学年を入力"></label>
          </div>
          <div class="form-row">
            <label>権限<br>
              <select id="student-authority" name="authority">
                <option value="0">学生</option>
                <option value="1">管理者</option>
              </select>
            </label>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn">保存</button>
            <button type="button" id="deleteStudentBtn" class="btn" style="background:#e74c3c;">削除</button>
            <button type="button" id="cancelStudentBtn" class="btn" style="background:#95a5a6;">戻る</button>
          </div>
        </form>
        <div id="studentMessage" class="message"></div>
      </div>
      <div id="noStudentSelected" style="text-align:center; color:#999; padding:40px 0; display:block;">検索画面から学生を選択してください</div>
    </div>
  </div>
</div>
