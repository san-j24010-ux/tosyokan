<!-- ページ: 学生検索 -->
<div class="admin-page" id="page-student-search">
  <h1>学生検索</h1>
  <form id="studentsSearchForm" class="search-form">
    <div class="form-row">
      <label>学生ID<br><input type="text" id="search-student-id" name="student_id" placeholder="例: stu001"></label>
      <label>学生名<br><input type="text" id="search-student-name" name="name" placeholder="名前で検索"></label>
    </div>
    <div class="form-row">
      <label>学校<br>
        <select id="search-student-school" name="school"></select>
      </label>
      <label>学年<br><input type="number" id="search-student-grade" name="grade" min="1" max="6"></label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">検索</button>
      <button type="button" id="studentsSearchReset" class="btn" style="background:#95a5a6;">リセット</button>
    </div>
  </form>
  <div id="studentsSearchResults" class="results" style="margin-top:12px;"></div>
</div>
