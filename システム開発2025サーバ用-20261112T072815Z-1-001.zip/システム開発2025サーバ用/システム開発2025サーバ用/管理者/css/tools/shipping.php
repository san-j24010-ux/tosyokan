<!-- ページ: 発送確認 -->
<div class="admin-page" id="page-shipping">
  <h1>発送確認</h1>
  <form id="shippingSearchForm" class="search-form">
    <div class="form-row">
      <label>学籍番号<br><input type="text" id="shipping-student-number" name="student_number" placeholder="学籍番号で検索"></label>
      <label>書籍番号<br><input type="text" id="shipping-isbn" name="isbn" placeholder="書籍番号で検索"></label>
    </div>
    <div class="form-row">
      <label>年度<br><input type="text" id="shipping-year" name="year" placeholder="例: 2026"></label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">検索</button>
    </div>
  </form>
  <div id="shippingResults" class="results" style="margin-top:12px;"></div>
</div>
