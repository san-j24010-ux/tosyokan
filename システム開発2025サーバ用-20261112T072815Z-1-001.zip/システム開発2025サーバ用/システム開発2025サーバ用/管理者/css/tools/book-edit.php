<!-- ページ: 更新・削除 -->
<div class="admin-page" id="page-edit">
  <h1>更新・削除</h1>
  <div style="display:flex; gap:20px;">
    <div style="flex:1; display:none;">
      <h3>登録済みの本一覧</h3>
      <div id="editBooksList" class="results"></div>
    </div>
    <div style="flex:1;">
      <div id="editPanel" style="display:none">
        <h3>編集内容</h3>
        <form id="editForm" class="search-form">
          <div class="form-row">
            <label>書籍番号<br><input type="text" id="edit-isbn" name="isbn" placeholder="例: 001-001"></label>
          </div>
          <div class="form-row">
            <label>本の題名<br><input type="text" id="edit-title" name="title" placeholder="題名を入力"></label>
          </div>
          <div class="form-row">
            <label>本の著者名<br><input type="text" id="edit-author" name="author" placeholder="著者名を入力"></label>
          </div>
          <div class="form-row">
            <label>本のジャンル<br>
              <select id="edit-genre" name="genre">
                <option value="">選択してください</option>
              </select>
            </label>
          </div>
          <div class="form-row">
            <label>本の場所<br>
              <select id="edit-location" name="location">
                <option value="">選択してください</option>
              </select>
            </label>
          </div>
          <div class="form-row">
            <label>表紙画像<br>
              <input type="file" id="edit-photograph" name="photograph" accept="image/*">
              <div id="current-photograph" style="margin-top:10px;"></div>
            </label>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn">保存</button>
            <button type="button" id="deleteBtn" class="btn" style="background:#e74c3c;">削除</button>
            <button type="button" id="cancelBtn" class="btn" style="background:#95a5a6;">戻る</button>
          </div>
        </form>
        <div id="editMessage" class="message"></div>
      </div>
      <div id="noSelection" style="text-align:center; color:#999; padding:40px 0; display:block;">検索画面から本を選択してください</div>
    </div>
  </div>
</div>
