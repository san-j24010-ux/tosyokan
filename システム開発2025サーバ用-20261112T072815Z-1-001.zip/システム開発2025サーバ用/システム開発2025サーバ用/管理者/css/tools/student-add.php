<!-- ページ: 学生追加 -->
<div class="admin-page" id="page-student-add">
  <h1>学生追加</h1>
  <form id="addStudentForm" class="search-form">
    <div class="form-row">
      <label>学生ID<br><input type="text" id="new-student-id" name="student_id" placeholder="例: stu003" required></label>
    </div>
    <div class="form-row">
      <label>学生名<br><input type="text" id="new-student-name" name="name" placeholder="学生の名前を入力" required></label>
    </div>
    <div class="form-row">
      <label>パスワード<br><input type="password" id="new-student-password" name="password" placeholder="パスワードを入力" required></label>
    </div>
    <div class="form-row">
      <label>学校<br>
        <select id="new-student-school" name="school"></select>
      </label>
    </div>
    <div class="form-row">
      <label>学年<br><input type="number" id="new-student-grade" name="grade" min="1" max="6" placeholder="学年を入力"></label>
    </div>
    <div class="form-row">
      <label>権限<br>
        <select id="new-student-authority" name="authority">
          <option value="0">学生</option>
          <option value="1">管理者</option>
        </select>
      </label>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">追加</button>
    </div>
  </form>
  <div id="addStudentMessage" class="message"></div>
</div>
