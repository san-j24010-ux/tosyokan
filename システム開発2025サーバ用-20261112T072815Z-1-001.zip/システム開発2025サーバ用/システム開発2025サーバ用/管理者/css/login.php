<?php
// 学生ログイン画面
session_start();

// 既にログインしていれば、student.php へリダイレクト
if (isset($_SESSION['student_id'])) {
    header('Location: student.php');
    exit;
}
?>
<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>ログイン - 本の検索・管理システム</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body { margin: 0; padding: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; justify-content: center; align-items: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    .login-container { background: white; border-radius: 10px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); width: 100%; max-width: 400px; padding: 40px; }
    .login-header { text-align: center; margin-bottom: 30px; }
    .login-header h1 { margin: 0; font-size: 28px; color: #2c3e50; }
    .login-header p { margin: 10px 0 0 0; color: #7f8c8d; font-size: 14px; }
    .login-form .form-group { margin-bottom: 20px; }
    .login-form label { display: block; margin-bottom: 8px; color: #2c3e50; font-weight: 500; }
    .login-form input { width: 100%; padding: 10px; border: 1px solid #bdc3c7; border-radius: 5px; font-size: 14px; box-sizing: border-box; }
    .login-form input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 5px rgba(102,126,234,0.3); }
    .login-form button { width: 100%; padding: 12px; background: #667eea; color: white; border: none; border-radius: 5px; font-size: 16px; font-weight: 600; cursor: pointer; transition: background 0.3s; }
    .login-form button:hover { background: #764ba2; }
    .login-message { margin-top: 15px; padding: 12px; border-radius: 5px; text-align: center; display: none; font-size: 14px; }
    .login-message.error { background: #ffebee; color: #c62828; }
    .login-message.success { background: #e8f5e9; color: #2e7d32; }
    .demo-info { margin-top: 30px; padding: 15px; background: #f0f4ff; border-radius: 5px; border-left: 4px solid #667eea; color: #333; font-size: 13px; }
    .demo-info strong { display: block; margin-bottom: 8px; }
  </style>
</head>
<body>
  <div class="login-container">
    <div class="login-header">
      <h1>📚 図書館</h1>
      <p>学生用ログイン</p>
    </div>

    <form class="login-form" id="loginForm">
      <div class="form-group">
        <label>学生ID</label>
        <input type="text" name="student_id" placeholder="例: STU001" required autofocus>
      </div>
      <div class="form-group">
        <label>パスワード</label>
        <input type="password" name="password" placeholder="パスワードを入力" required>
      </div>
      <button type="submit">ログイン</button>
      <div id="loginMessage" class="login-message"></div>
    </form>

    <div class="demo-info">
      <strong>デモアカウント:</strong>
      学生ID: stu001<br>
      パスワード: password123<br>
      <br>
      <small>📝 初めての場合は、コマンドラインで以下を実行してください:<br>
      <code style="background: #f0f0f0; padding: 2px 4px;">php manage_accounts.php create-demo</code></small>
    </div>

    <div style="margin-top: 20px; text-align: center; padding-top: 20px; border-top: 1px solid #e0e0e0;">
      <p style="margin: 0 0 10px 0; color: #666; font-size: 13px;">管理者の方はこちら</p>
      <a href="admin_login.php" style="display: inline-block; padding: 10px 20px; background: #34495e; color: white; text-decoration: none; border-radius: 5px; font-size: 14px; transition: background 0.3s;">管理者ログイン</a>
    </div>
  </div>

  <script>
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const studentId = e.target.student_id.value.trim();
      const password = e.target.password.value;

      try {
        const body = new URLSearchParams({ student_id: studentId, password });
        const res = await fetch('api/login.php', { method: 'POST', body });
        const json = await res.json();

        const msg = document.getElementById('loginMessage');
        if (json.success) {
          // ログイン成功
          msg.textContent = 'ログイン成功 - リダイレクト中...';
          msg.className = 'login-message success';
          msg.style.display = 'block';
          setTimeout(() => {
            window.location.href = 'student.php';
          }, 1000);
        } else {
          msg.textContent = json.error || 'ログインに失敗しました';
          msg.className = 'login-message error';
          msg.style.display = 'block';
        }
      } catch (err) {
        const msg = document.getElementById('loginMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.className = 'login-message error';
        msg.style.display = 'block';
      }
    });
  </script>
</body>
</html>
