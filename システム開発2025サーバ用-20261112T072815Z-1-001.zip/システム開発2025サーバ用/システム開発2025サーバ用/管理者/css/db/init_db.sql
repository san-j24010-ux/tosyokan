-- データベース作成
CREATE DATABASE IF NOT EXISTS `toshokan` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `toshokan`;

-- schoolテーブル
CREATE TABLE IF NOT EXISTS `school` (
  `school_id` INT AUTO_INCREMENT PRIMARY KEY,
  `school_name` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- usersテーブル
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` VARCHAR(50) PRIMARY KEY,
  `user_name` VARCHAR(100) NOT NULL,
  `school_id` INT,
  `user_grade` INT,
  `user_password` VARCHAR(255),
  `user_authority` INT DEFAULT 0,
  FOREIGN KEY (`school_id`) REFERENCES `school`(`school_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ganreテーブル
CREATE TABLE IF NOT EXISTS `ganre` (
  `genre_id` INT AUTO_INCREMENT PRIMARY KEY,
  `genre_name` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- statusテーブル
CREATE TABLE IF NOT EXISTS `status` (
  `status_id` INT AUTO_INCREMENT PRIMARY KEY,
  `status_name` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- authorテーブル
CREATE TABLE IF NOT EXISTS `author` (
  `author_id` INT AUTO_INCREMENT PRIMARY KEY,
  `author_name` VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- bookテーブル
CREATE TABLE IF NOT EXISTS `book` (
  `book_id` INT AUTO_INCREMENT PRIMARY KEY,
  `isbn` VARCHAR(50),
  `school_id` INT,
  `book_name` VARCHAR(255) NOT NULL,
  `author_id` INT,
  `ganre_id` INT,
  `status_id` INT,
  `photograph` VARCHAR(255),
  FOREIGN KEY (`school_id`) REFERENCES `school`(`school_id`),
  FOREIGN KEY (`author_id`) REFERENCES `author`(`author_id`),
  FOREIGN KEY (`ganre_id`) REFERENCES `ganre`(`genre_id`),
  FOREIGN KEY (`status_id`) REFERENCES `status`(`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- lendテーブル
CREATE TABLE IF NOT EXISTS `lend` (
  `user_id` VARCHAR(50),
  `book_id` INT,
  `status_id` INT,
  `checkout_date` DATE,
  `return_date` DATE,
  `reservation_date` DATE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`user_id`),
  FOREIGN KEY (`book_id`) REFERENCES `book`(`book_id`),
  FOREIGN KEY (`status_id`) REFERENCES `status`(`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- マスターデータ挿入
INSERT IGNORE INTO `school` (`school_id`, `school_name`) VALUES
(1, 'A小学校'),
(2, 'B小学校'),
(3, 'A中学校');

INSERT IGNORE INTO `ganre` (`genre_id`, `genre_name`) VALUES
(1, '小説'),
(2, '文学'),
(3, 'ビジネス・経済'),
(4, '趣味・実用'),
(5, 'コミック・マンガ'),
(6, '専門書'),
(7, '児童書');

INSERT IGNORE INTO `status` (`status_id`, `status_name`) VALUES
(1, '利用可能'),
(2, '貸出中'),
(3, '予約済み'),
(4, '整備中');
