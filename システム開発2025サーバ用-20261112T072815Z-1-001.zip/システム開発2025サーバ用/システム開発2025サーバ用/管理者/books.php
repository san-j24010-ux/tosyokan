<?php
header('Content-Type: application/json; charset=utf-8');

$dbDir = __DIR__ . '/../db';
$dbFile = $dbDir . '/books.db';

if (!is_dir($dbDir)) {
    mkdir($dbDir, 0755, true);
}

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 初期化（テーブルが無ければ作成してサンプルを挿入）
    $pdo->exec("CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        isbn TEXT,
        title TEXT,
        author TEXT,
        genre TEXT,
        location TEXT
    )");

    // サンプルが空なら挿入
    $count = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
    if ($count == 0) {
        $samples = [
            ['001-001','線形代数入門','山田 太郎','数学','図書館A'],
            ['002-002','古代の歴史','佐藤 花子','歴史','図書館B'],
            ['003-003','量子力学の基礎','鈴木 次郎','物理','図書館A'],
            ['004-004','日本文学選','高橋 一郎','文学','教室1'],
            ['005-005','解析入門','山田 太郎','数学','図書館B']
        ];
        $stmt = $pdo->prepare('INSERT INTO books (isbn,title,author,genre,location) VALUES (?,?,?,?,?)');
        foreach ($samples as $s) {
            $stmt->execute($s);
        }
    }

    // パラメータ取得
    $isbn = isset($_GET['isbn']) ? trim($_GET['isbn']) : '';
    $title = isset($_GET['title']) ? trim($_GET['title']) : '';
    $author = isset($_GET['author']) ? trim($_GET['author']) : '';
    $genre = isset($_GET['genre']) ? trim($_GET['genre']) : '';
    $location = isset($_GET['location']) ? trim($_GET['location']) : '';
    $sort = isset($_GET['sort']) && in_array($_GET['sort'], ['title','author']) ? $_GET['sort'] : 'title';

    $wheres = [];
    $params = [];
    if ($isbn !== '') { $wheres[] = 'isbn LIKE :isbn'; $params[':isbn'] = "%$isbn%"; }
    if ($title !== '') { $wheres[] = 'title LIKE :title'; $params[':title'] = "%$title%"; }
    if ($author !== '') { $wheres[] = 'author LIKE :author'; $params[':author'] = "%$author%"; }
    if ($genre !== '') { $wheres[] = 'genre = :genre'; $params[':genre'] = $genre; }
    if ($location !== '') { $wheres[] = 'location = :location'; $params[':location'] = $location; }

    $sql = 'SELECT isbn,title,author,genre,location FROM books';
    if (count($wheres) > 0) {
        $sql .= ' WHERE ' . implode(' AND ', $wheres);
    }
    $sql .= ' ORDER BY ' . ($sort === 'author' ? 'author' : 'title') . ' COLLATE NOCASE';

    $stmt = $pdo->prepare($sql);
    foreach ($params as $k=>$v) { $stmt->bindValue($k, $v); }
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($rows, JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
