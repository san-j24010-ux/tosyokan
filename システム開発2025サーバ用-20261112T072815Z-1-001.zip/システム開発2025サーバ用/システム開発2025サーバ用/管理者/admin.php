<?php
// 管理者向けの画面
// SPA 形式: 検索、追加、編集・削除、発送確認、発送承認
session_start(); // これを必ず一番上に書く！
if (!isset($_SESSION['user_id'])) {
    // 未ログインの場合、ログインページへリダイレクト
    header('Location: login.php');
    exit;
}
$user_name = $_SESSION['user_name'];
$user_id = $_SESSION['user_id'];
$school_id = $_SESSION['school_id'] ?? null;

// 学校名を取得
$school_name = '未設定';
if ($school_id) {
    require_once 'api/db_config.php';
    try {
        $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $stmt = $pdo->prepare("SELECT school_name FROM {$DB_TABLE_SCHOOL} WHERE school_id = :school_id");
        $stmt->execute([':school_id' => $school_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($result) {
            $school_name = $result['school_name'];
        }
    } catch (PDOException $e) {
        error_log('学校名取得エラー: ' . $e->getMessage());
    }
}
?>


<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>本の検索・管理システム - 管理者用</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .admin-container { display: flex; height: 100vh; }
    .admin-sidebar { flex: 0 0 250px; background: #f5f5f5; border-right: 1px solid #ddd; overflow-y: auto; }
    .admin-main { flex: 1; overflow-y: auto; }
    .admin-header { background: #34495e; color: white; padding: 20px; }
    .admin-header h2 { margin: 0 0 10px 0; font-size: 20px; }
    .admin-header p { margin: 5px 0; font-size: 14px; }
    .user-info { background: #2c3e50; padding: 15px 20px; border-top: 1px solid #1a252f; }
    .user-info-label { font-size: 11px; color: #95a5a6; text-transform: uppercase; margin-bottom: 5px; }
    .user-info-value { font-size: 14px; color: white; margin-bottom: 10px; font-weight: 600; }
    .user-info-row { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .user-info-icon { font-size: 16px; }
    .logout-section { padding: 15px 20px; border-top: 1px solid #ddd; }
    .admin-menu { list-style: none; padding: 0; margin: 0; }
    .admin-menu li { border-bottom: 1px solid #ddd; }
    .admin-menu a { display: block; padding: 15px 20px; text-decoration: none; color: #333; transition: background 0.2s; }
    .admin-menu a:hover { background: #e8e8e8; }
    .admin-menu a.active { background: #34495e; color: white; }
    .admin-page { padding: 30px; display: none; }
    .admin-page.active { display: block; }
    .logout-btn { background: #e74c3c; color: white; border: none; padding: 10px 20px; border-radius: 3px; cursor: pointer; font-size: 14px; }
    .logout-btn:hover { background: #c0392b; }
  </style>
</head>
<body>
  <div class="admin-container">
    <!-- 左サイドバー -->
    <aside class="admin-sidebar">
      <div class="admin-header">
        <h2>図書館管理システム</h2>
      </div>
      
      <!-- ログインユーザー情報 -->
      <div class="user-info">
        <div class="user-info-row">
          <span class="user-info-icon">👤</span>
          <div style="flex: 1;">
            <div class="user-info-label">ログイン中</div>
            <div class="user-info-value"><?php echo htmlspecialchars($user_name, ENT_QUOTES, 'UTF-8'); ?></div>
          </div>
        </div>
        <div class="user-info-row">
          <span class="user-info-icon">🆔</span>
          <div style="flex: 1;">
            <div class="user-info-label">ユーザーID</div>
            <div class="user-info-value"><?php echo htmlspecialchars($user_id, ENT_QUOTES, 'UTF-8'); ?></div>
          </div>
        </div>
      </div>
      
      <ul class="admin-menu">
        <li><a href="#" class="menu-link active" data-page="search">🔍 本を検索</a></li>
        <li><a href="#" class="menu-link" data-page="manage">➕ 本を追加</a></li>
        <li><a href="#" class="menu-link" data-page="edit">✏️ 本を更新・削除</a></li>
        <li><a href="#" class="menu-link" data-page="ban-period">🚫 禁止期間</a></li>
        <li style="border-top: 2px solid #ccc; margin-top: 10px;"><a href="#" class="menu-link" data-page="student-search">🔍 学生検索</a></li>
        <li><a href="#" class="menu-link" data-page="student-add">➕ 学生追加</a></li>
        <li style="border-top: 2px solid #ccc; margin-top: 10px;"><a href="#" class="menu-link" data-page="lending-approval">📋 貸出承認</a></li>
        <li><a href="#" class="menu-link" data-page="return-approval">📚 返却承認</a></li>
        <li><a href="#" class="menu-link" data-page="shipping-confirm">📦 発送確認</a></li>
        <li><a href="#" class="menu-link" data-page="approval">✅ 発送承認</a></li> 
      </ul>
      
      <!-- ログアウトボタン -->
      <div class="logout-section">
        <form action="logout.php" method="post" style="margin: 0;">
          <button type="submit" class="logout-btn" style="width: 100%;">🚪 ログアウト</button>
        </form>
      </div>
    </aside>

    <!-- メインコンテンツ -->
    <main class="admin-main">
      <?php include 'tools/book-search.php'; ?>
      <?php include 'tools/book-add.php'; ?>
      <?php include 'tools/book-edit.php'; ?>
      <?php include 'tools/ban-period.php'; ?>
      <?php include 'tools/lending-approval.php'; ?>
      <?php include 'tools/return-approval.php'; ?>
      <?php include 'tools/shipping_confirm.php'; ?>
      <?php include 'tools/student-search.php'; ?>
      <?php include 'tools/student-add.php'; ?>
      <?php include 'tools/student-edit.php'; ?>
      <?php include 'book/approval.php'; ?>
      <!-- ページ: 発送確認 (重複削除のため、上に既に定義済み) -->
      <!-- ページ: 学生アカウント管理 (非表示、後方互換性用) -->

     <div class="admin-page" id="page-students" style="display:none;">
      </div>
    </main>
  </div>

  <script>
    // メニューリンク処理
    document.querySelectorAll('.menu-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = e.target.dataset.page;
        
        // 発送承認ページに切り替える際はURLに page パラメータを追加
        if (page === 'approval') {
          window.history.pushState({}, '', 'admin.php?page=approval');
        } else {
          // 他のページに切り替える際は page パラメータをクリア
          window.history.pushState({}, '', 'admin.php');
        }
        
        document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
        
        document.getElementById(`page-${page}`).classList.add('active');
        e.target.classList.add('active');
        
        if (page === 'edit') {
          loadEditBooks();
        } else if (page === 'student-search') {
          // 学生検索画面を表示：全件取得
          fetch('api/get_students.php')
            .then(res => res.json())
            .then(students => renderStudentSearchResults(students))
            .catch(err => console.error('エラー:', err));
        } else if (page === 'student-edit') {
          // 学生更新・削除画面を表示：全件取得して一覧表示
          loadEditStudents();
        }
      });
    });

    // 本を検索
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
      searchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const params = new URLSearchParams(new FormData(e.target));
        try {
          const res = await fetch('api/books.php?' + params);
          const books = await res.json();
          console.log('検索結果:', books);
          console.log('最初の本のデータ:', books[0]);
          const resultsDiv = document.getElementById('results');
        
        if (!Array.isArray(books) || books.length === 0) {
          resultsDiv.innerHTML = '<p>本が見つかりません</p>';
          return;
        }

        resultsDiv.innerHTML = books.map(b => {
          // 画像のURLを判定（http/httpsで始まる場合は完全URL、それ以外は相対パス）
          let imgSrc = '';
          if (b.photograph) {
            if (b.photograph.startsWith('http://') || b.photograph.startsWith('https://')) {
              imgSrc = b.photograph;
            } else {
              imgSrc = b.photograph;
            }
          }
          
          // ステータスに応じた色を決定
          const statusColors = {
            '貸出': '#ffc107',
            '予約': '#17a2b8',
            '輸送': '#fd7e14',
            '保管': '#28a745'
          };
          const statusColor = statusColors[b.status] || '#6c757d';
          
          return `
          <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px; cursor:pointer; display:flex; gap:16px;" onclick="selectBookFromSearch('${escapeHtml(b.isbn)}', '${escapeHtml(b.title)}', '${escapeHtml(b.author)}', '${escapeHtml(b.genre)}', '${escapeHtml(b.location)}', '${escapeHtml(b.photograph || '')}', ${b.book_id})">
            ${imgSrc ? `<img src="${escapeHtml(imgSrc)}" alt="表紙" style="width:80px; height:120px; object-fit:cover; border-radius:4px; flex-shrink:0;" onerror="this.src=''; this.style.background='#e0e0e0'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.style.color='#999'; this.style.fontSize='10px'; this.innerHTML='画像なし';">` : '<div style="width:80px; height:120px; background:#e0e0e0; border-radius:4px; flex-shrink:0; display:flex; align-items:center; justify-content:center; color:#999; font-size:12px;">画像なし</div>'}
            <div style="flex:1;">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                <div>
                  <strong>${escapeHtml(b.title || '(題名なし)')}</strong>
                  <span style="display:inline-block;margin-left:8px;padding:3px 8px;background:${statusColor};color:white;border-radius:3px;font-size:11px;font-weight:bold;">${escapeHtml(b.status || '不明')}</span>
                  <br>
                  <small style="color:#666;">ISBN: ${escapeHtml(b.isbn)}</small>
                </div>
                <div style="text-align:right;font-size:12px;color:#999;">
                  ${escapeHtml(b.genre || '(ジャンル未定)')}
                </div>
              </div>
              <div style="margin-top:8px;font-size:13px;color:#555;">
                著者: ${escapeHtml(b.author || '(著者なし)')} | 場所: ${escapeHtml(b.location || '(未定)')}
              </div>
            </div>
          </div>
        `}).join('');
      } catch (err) {
        document.getElementById('results').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    });
    }

    // 禁止期間検索
    const banPeriodForm = document.getElementById('banPeriodForm');
    if (banPeriodForm) {
      banPeriodForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const params = new URLSearchParams(new FormData(e.target));
        try {
          const res = await fetch('api/books.php?' + params);
          const books = await res.json();
          const resultsDiv = document.getElementById('banPeriodResults');
        
        if (!Array.isArray(books) || books.length === 0) {
          resultsDiv.innerHTML = '<p>本が見つかりません</p>';
          return;
        }

        resultsDiv.innerHTML = books.map(b => {
          // 画像のURLを判定（http/httpsで始まる場合は完全URL、それ以外は相対パス）
          let imgSrc = '';
          if (b.photograph) {
            if (b.photograph.startsWith('http://') || b.photograph.startsWith('https://')) {
              imgSrc = b.photograph;
            } else {
              imgSrc = b.photograph;
            }
          }
          
          // ステータスに応じた色を決定
          const statusColors = {
            '貸出': '#ffc107',
            '予約': '#17a2b8',
            '輸送': '#fd7e14',
            '保管': '#28a745'
          };
          const statusColor = statusColors[b.status] || '#6c757d';
          
          return `
          <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px; display:flex; gap:16px; cursor:default;">
            ${imgSrc ? `<img src="${escapeHtml(imgSrc)}" alt="表紙" style="width:80px; height:120px; object-fit:cover; border-radius:4px; flex-shrink:0;" onerror="this.src=''; this.style.background='#e0e0e0'; this.style.display='flex'; this.style.alignItems='center'; this.style.justifyContent='center'; this.style.color='#999'; this.style.fontSize='10px'; this.innerHTML='画像なし';">` : '<div style="width:80px; height:120px; background:#e0e0e0; border-radius:4px; flex-shrink:0; display:flex; align-items:center; justify-content:center; color:#999; font-size:12px;">画像なし</div>'}
            <div style="flex:1;">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                <div>
                  <strong>${escapeHtml(b.title || '(題名なし)')}</strong>
                  <span style="display:inline-block;margin-left:8px;padding:3px 8px;background:${statusColor};color:white;border-radius:3px;font-size:11px;font-weight:bold;">${escapeHtml(b.status || '不明')}</span>
                  <br>
                  <small style="color:#666;">ISBN: ${escapeHtml(b.isbn)}</small>
                </div>
                <div style="text-align:right;font-size:12px;color:#999;">
                  ${escapeHtml(b.genre || '(ジャンル未定)')}
                </div>
              </div>
              <div style="margin-top:8px;font-size:13px;color:#555;">
                著者: ${escapeHtml(b.author || '(著者なし)')} | 場所: ${escapeHtml(b.location || '(未定)')}
              </div>
              <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e9ecef;">
                <div style="display:flex;gap:10px;align-items:flex-end;">
                  <div style="flex:1;">
                    <label style="display:block;font-size:12px;color:#666;margin-bottom:4px;">禁止期間開始日</label>
                    <input type="date" id="ban-start-${b.book_id}" min="${new Date().toISOString().split('T')[0]}" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;">
                  </div>
                  <div style="flex:1;">
                    <label style="display:block;font-size:12px;color:#666;margin-bottom:4px;">禁止期間終了日</label>
                    <input type="date" id="ban-end-${b.book_id}" min="${new Date().toISOString().split('T')[0]}" style="width:100%;padding:6px;border:1px solid #ddd;border-radius:4px;font-size:13px;">
                  </div>
                  <button onclick="setBanPeriod(${b.book_id})" style="padding:8px 20px;background:#dc3545;color:white;border:none;border-radius:4px;cursor:pointer;font-size:13px;font-weight:bold;white-space:nowrap;">設定</button>
                </div>
              </div>
            </div>
          </div>
        `}).join('');
      } catch (err) {
        document.getElementById('banPeriodResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    });
    }

    // 本を追加
    const addForm = document.getElementById('addForm');
    if (addForm) {
      addForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      try {
        const res = await fetch('api/add.php', { method: 'POST', body: formData });
        const json = await res.json();
        const msg = document.getElementById('addMessage');
        
        if (json.success) {
          msg.textContent = '本を追加しました';
          msg.style.color = 'green';
          e.target.reset();
        } else {
          msg.textContent = 'エラー: ' + (json.error || '追加に失敗しました');
          msg.style.color = 'red';
        }
        msg.style.display = 'block';
      } catch (err) {
        const msg = document.getElementById('addMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.style.color = 'red';
        msg.style.display = 'block';
      }
    });
    }

    // 編集用の本リストを読み込み
    function loadEditBooks() {
      fetch('api/books.php')
        .then(res => res.json())
        .then(books => {
          const list = document.getElementById('editBooksList');
          if (!Array.isArray(books) || books.length === 0) {
            list.innerHTML = '<p>本がありません</p>';
            return;
          }
          list.innerHTML = books.map((b, i) => `
            <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px; cursor:pointer;" onclick="selectBook(${i}, '${escapeHtml(b.isbn)}', '${escapeHtml(b.title)}', '${escapeHtml(b.author)}', '${escapeHtml(b.genre)}', '${escapeHtml(b.location)}', '${escapeHtml(b.photograph || '')}', ${b.book_id || 'null'})">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                <div>
                  <strong>${escapeHtml(b.title || '(題名なし)')}</strong><br>
                  <small style="color:#666;">ISBN: ${escapeHtml(b.isbn)}</small>
                </div>
              </div>
              <div style="margin-top:6px;font-size:12px;color:#888;">
                ${escapeHtml(b.author || '(著者なし)')}
              </div>
            </div>
          `).join('');
        })
        .catch(err => console.error('エラー:', err));
    }

    // 本を選択して編集フォームに表示（左の一覧から）
    function selectBook(idx, isbn, title, author, genre, location, photograph = null, book_id = null) {
      document.getElementById('editPanel').style.display = 'block';
      document.getElementById('noSelection').style.display = 'none';
      document.getElementById('edit-isbn').value = isbn;
      document.getElementById('edit-title').value = title;
      document.getElementById('edit-author').value = author;
      window.currentIsbn = isbn;
      window.currentBookId = book_id;
      
      // セレクトボックスにオプションを読み込んでから値を設定
      if (masterData) {
        populateGenreSelects();
        populateLocationSelects();
        setTimeout(() => {
          document.getElementById('edit-genre').value = genre;
          document.getElementById('edit-location').value = location;
        }, 10);
      } else {
        document.getElementById('edit-genre').value = genre;
        document.getElementById('edit-location').value = location;
      }
      
      // 現在の画像表示
      const photoDiv = document.getElementById('current-photograph');
      if (photograph && photoDiv) {
        photoDiv.innerHTML = `<img src="covers/${escapeHtml(photograph)}" alt="表紙" style="max-width:150px; max-height:200px; border-radius:4px;" onerror="this.style.display='none'">`;
      } else if (photoDiv) {
        photoDiv.innerHTML = '<small style="color:#999;">画像なし</small>';
      }
    }

    // 本を選択して編集画面に遷移（検索結果から）
    function selectBookFromSearch(isbn, title, author, genre, location, photograph = null, book_id = null) {
      console.log('selectBookFromSearch呼び出し:', { isbn, title, author, genre, location, photograph, book_id });
      
      // 更新・削除ページに移動
      document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
      document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
      
      document.getElementById('page-edit').classList.add('active');
      document.querySelector('.menu-link[data-page="edit"]').classList.add('active');
      document.getElementById('editPanel').style.display = 'block';
      document.getElementById('noSelection').style.display = 'none';
      
      document.getElementById('edit-isbn').value = isbn;
      document.getElementById('edit-title').value = title;
      document.getElementById('edit-author').value = author;
      window.currentIsbn = isbn;
      window.currentBookId = book_id;
      console.log('currentBookIdを設定:', window.currentBookId);
      
      // セレクトボックスにオプションを読み込んでから値を設定
      if (masterData) {
        populateGenreSelects();
        populateLocationSelects();
        setTimeout(() => {
          document.getElementById('edit-genre').value = genre;
          document.getElementById('edit-location').value = location;
        }, 10);
      } else {
        document.getElementById('edit-genre').value = genre;
        document.getElementById('edit-location').value = location;
      }
      
      // 現在の画像表示
      const photoDiv = document.getElementById('current-photograph');
      if (photograph && photoDiv) {
        photoDiv.innerHTML = `<img src="covers/${escapeHtml(photograph)}" alt="表紙" style="max-width:150px; max-height:200px; border-radius:4px;" onerror="this.style.display='none'">`;
      } else if (photoDiv) {
        photoDiv.innerHTML = '<small style="color:#999;">画像なし</small>';
      }
      
      loadEditBooks();
    }

    // 本を更新
    const editForm = document.getElementById('editForm');
    if (editForm) {
      editForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(e.target);
      formData.set('book_id', window.currentBookId);
      try {
        const res = await fetch('api/update.php', { method: 'POST', body: formData });
        const json = await res.json();
        const msg = document.getElementById('editMessage');
        
        if (json.success) {
          msg.textContent = '本を更新しました';
          msg.style.color = 'green';
          loadEditBooks();
        } else {
          msg.textContent = 'エラー: ' + (json.error || '更新に失敗しました');
          msg.style.color = 'red';
        }
        msg.style.display = 'block';
      } catch (err) {
        const msg = document.getElementById('editMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.style.color = 'red';
        msg.style.display = 'block';
      }
    });
    }

    // 本を削除
    const deleteBtn = document.getElementById('deleteBtn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', async () => {
      console.log('削除ボタンがクリックされました');
      console.log('currentBookId:', window.currentBookId);
      
      if (window.currentBookId === null || window.currentBookId === undefined) {
        alert('削除する本が選択されていません');
        return;
      }
      if (!confirm('この本を削除しますか？\n※保管状態の本のみ削除できます')) return;
      try {
        const body = new URLSearchParams({ book_id: window.currentBookId });
        console.log('送信データ:', { book_id: window.currentBookId });
        const res = await fetch('api/delete.php', { method: 'POST', body });
        const json = await res.json();
        console.log('サーバーレスポンス:', json);
        const msg = document.getElementById('editMessage');
        
        if (json.success) {
          msg.textContent = '本を削除しました';
          msg.style.color = 'green';
          msg.style.display = 'block';
          // 2秒後に本を検索ページに戻る
          setTimeout(() => {
            document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
            
            document.getElementById('page-search').classList.add('active');
            const searchLink = document.querySelector('.menu-link[data-page="search"]');
            if (searchLink) searchLink.classList.add('active');
          }, 2000);
        } else {
          msg.textContent = 'エラー: ' + (json.error || '削除に失敗しました');
          msg.style.color = 'red';
          msg.style.display = 'block';
        }
      } catch (err) {
        const msg = document.getElementById('editMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.style.color = 'red';
        msg.style.display = 'block';
      }
    });
    }

    // キャンセル
    const cancelBtn = document.getElementById('cancelBtn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
      // 本を検索ページに戻る
      document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
      document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
      
      document.getElementById('page-search').classList.add('active');
      const searchLink = document.querySelector('.menu-link[data-page="search"]');
      if (searchLink) searchLink.classList.add('active');
    });
    }

    // 返却検索
    const returnForm = document.getElementById('returnForm');
    if (returnForm) {
      returnForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      function safeAddListener(id, event, handler) {
        const el = document.getElementById(id);
        if (el) {
          el.addEventListener(event, handler);
        }
      }

      const params = new URLSearchParams(new FormData(e.target));
      try {
        const res = await fetch('api/books.php?' + params);
        const books = await res.json();
        const resultsDiv = document.getElementById('returnResults');
        
        if (!Array.isArray(books) || books.length === 0) {
          resultsDiv.innerHTML = '<p>本が見つかりません</p>';
          return;
        }

        resultsDiv.innerHTML = books.map(b => `
          <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;">
              <div>
                <strong>${escapeHtml(b.title || '(題名なし)')}</strong><br>
                <small style="color:#666;">ISBN: ${escapeHtml(b.isbn)}</small>
              </div>
              <div style="text-align:right;">
                <div style="font-size:12px;color:#999;margin-bottom:8px;">
                  返却済み: <strong style="color:#${b.returned ? '27ae60' : 'e74c3c'}">${b.returned ? 'はい ✓' : 'いいえ'}</strong>
                </div>
              </div>
            </div>
            <div style="margin:10px 0 0 0;font-size:13px;color:#555;">
              返却予定日: ${b.return_due || '(設定なし)'}
            </div>
            <div style="margin-top:10px;">
              <button onclick="markReturned('${escapeHtml(b.isbn)}')" class="btn" style="padding:6px 12px;font-size:12px;">返却済みにマーク</button>
            </div>
          </div>
        `).join('');
      } catch (err) {
        document.getElementById('returnResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    });
    }

    // 返却済みにマーク
    function markReturned(isbn) {
      fetch('api/return.php', {
        method: 'POST',
        body: new URLSearchParams({ isbn })
      })
      .then(res => res.json())
      .then(json => {
        if (json.success) {
          alert('返却済みにマークしました');
          document.getElementById('returnForm').dispatchEvent(new Event('submit'));
        } else {
          alert('エラー: ' + (json.error || '処理に失敗しました'));
        }
      })
      .catch(err => alert('エラー: ' + err.message));
    }

    // HTML エスケープ
    function escapeHtml(s) {
      return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // 禁止期間を設定
    async function setBanPeriod(bookId) {
      const startDate = document.getElementById(`ban-start-${bookId}`).value;
      const endDate = document.getElementById(`ban-end-${bookId}`).value;
      
      if (!startDate || !endDate) {
        alert('開始日と終了日を入力してください');
        return;
      }
      
      const today = new Date().toISOString().split('T')[0];
      if (startDate < today) {
        alert('開始日は今日以降の日付を指定してください');
        return;
      }
      
      if (startDate > endDate) {
        alert('開始日は終了日より前の日付を指定してください');
        return;
      }
      
      try {
        const formData = new FormData();
        formData.append('book_id', bookId);
        formData.append('start_date', startDate);
        formData.append('end_date', endDate);
        
        const response = await fetch('api/set_ban_period.php', {
          method: 'POST',
          body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
          alert('禁止期間を設定しました');
          document.getElementById(`ban-start-${bookId}`).value = '';
          document.getElementById(`ban-end-${bookId}`).value = '';
        } else {
          alert('エラー: ' + (result.error || '設定に失敗しました'));
        }
      } catch (error) {
        console.error('設定エラー:', error);
        alert('通信エラーが発生しました');
      }
    }

    // 学生編集一覧を読み込み（更新・削除ページ用）
    function loadEditStudents() {
      fetch('api/get_students.php')
        .then(res => res.json())
        .then(students => {
          const list = document.getElementById('editStudentsList');
          if (!Array.isArray(students) || students.length === 0) {
            list.innerHTML = '<p>学生がいません</p>';
            document.getElementById('noStudentSelected').style.display = '';
            document.getElementById('studentEditPanel').style.display = 'none';
            return;
          }
          list.innerHTML = students.map((s) => `
            <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px; cursor:pointer;" onclick="selectStudentFromSearch('${escapeHtml(s.student_id)}', '${escapeHtml(s.name)}', '${escapeHtml(s.school || '')}', '${escapeHtml(s.grade || '')}', '${escapeHtml(s.authority || 0)}')">
              <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                <div>
                  <strong>${escapeHtml(s.name || '(名前なし)')}</strong><br>
                  <small style="color:#666;">ID: ${escapeHtml(s.student_id)}</small>
                </div>
                <div style="text-align:right;font-size:12px;color:#666;">
                  ${escapeHtml(s.school || '')} ${s.grade ? '／' + escapeHtml(String(s.grade)) + '年' : ''}
                </div>
              </div>
            </div>
          `).join('');
        })
        .catch(err => console.error('エラー:', err));
    }

    // 検索結果を描画する共通関数
    function renderStudentSearchResults(students) {
      const results = document.getElementById('studentsSearchResults');
      if (!Array.isArray(students) || students.length === 0) {
        results.innerHTML = '<p style="padding:20px; text-align:center; color:#999;">データがありません</p>';
        return;
      }
      results.innerHTML = students.map((s) => `
        <div class="result-item" style="border:1px solid #ddd; padding:16px; border-radius:8px; background:#fff; margin-bottom:12px; cursor:pointer;" onclick="selectStudentFromSearch('${escapeHtml(s.student_id)}', '${escapeHtml(s.name)}', '${s.school_id || ''}', '${escapeHtml(s.grade || '')}', ${typeof s.authority !== 'undefined' ? s.authority : 0})">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <strong>${escapeHtml(s.name || '(名前なし)')}</strong><br>
              <small style="color:#666;">ID: ${escapeHtml(s.student_id)}</small>
            </div>
            <div style="text-align:right;font-size:12px;color:#666;">
              ${escapeHtml(s.school || '')} ${s.grade ? '／' + escapeHtml(String(s.grade)) + '年' : ''}
            </div>
          </div>
        </div>
      `).join('');
    }

    // 学生を選択して編集画面に遷移（検索画面から）
    function selectStudent(studentId, name, school, grade, authority) {
      document.getElementById('student-id').value = studentId;
      document.getElementById('student-name').value = name;
      document.getElementById('student-password').value = '';
      document.getElementById('student-school').value = school || '';
      document.getElementById('student-grade').value = grade || '';
      document.getElementById('student-authority').value = (typeof authority !== 'undefined') ? authority : '0';
      window.currentStudentId = studentId;
      
      // 学生更新・削除ページに移動
      document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
      document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
      
      document.getElementById('page-student-edit').classList.add('active');
      document.getElementById('studentEditPanel').style.display = '';
      document.getElementById('noStudentSelected').style.display = 'none';
      loadEditStudents();
    }

    // 学生検索結果から学生を選択して編集ページに遷移
    function selectStudentFromSearch(studentId, name, school, grade, authority) {
      console.log('selectStudentFromSearch called:', { studentId, name, school, grade, authority });
      
      const studentIdEl = document.getElementById('student-id');
      const studentNameEl = document.getElementById('student-name');
      const studentPasswordEl = document.getElementById('student-password');
      const studentSchoolEl = document.getElementById('student-school');
      const studentGradeEl = document.getElementById('student-grade');
      const studentAuthorityEl = document.getElementById('student-authority');
      const pageStudentEdit = document.getElementById('page-student-edit');
      const studentEditPanel = document.getElementById('studentEditPanel');
      const noStudentSelected = document.getElementById('noStudentSelected');
      
      console.log('要素の確認:', { studentSchoolEl, studentGradeEl, studentAuthorityEl });
      
      if (!studentIdEl || !studentNameEl || !pageStudentEdit) {
        console.error('必要な要素が見つかりません', {
          studentIdEl, studentNameEl, pageStudentEdit
        });
        return;
      }
      
      studentIdEl.value = studentId;
      studentNameEl.value = name;
      if (studentPasswordEl) studentPasswordEl.value = '';
      if (studentSchoolEl) {
        console.log('学校設定前:', studentSchoolEl.value);
        console.log('学校select要素のoption一覧:');
        Array.from(studentSchoolEl.options).forEach(opt => {
          console.log('  value:', opt.value, 'text:', opt.text);
        });
        studentSchoolEl.value = school || '';
        console.log('学校設定後:', studentSchoolEl.value, '期待値:', school);
        if (studentSchoolEl.value !== school && school) {
          console.warn('⚠️ 学校の値が一致しません。option要素に該当する値がありません');
        }
      }
      if (studentGradeEl) {
        console.log('学年設定前:', studentGradeEl.value);
        studentGradeEl.value = grade || '';
        console.log('学年設定後:', studentGradeEl.value, '期待値:', grade);
      }
      if (studentAuthorityEl) {
        console.log('権限設定前:', studentAuthorityEl.value);
        console.log('権限select要素のoption一覧:');
        Array.from(studentAuthorityEl.options).forEach(opt => {
          console.log('  value:', opt.value, 'text:', opt.text);
        });
        const authorityValue = (typeof authority !== 'undefined') ? String(authority) : '0';
        studentAuthorityEl.value = authorityValue;
        console.log('権限設定後:', studentAuthorityEl.value, '期待値:', authorityValue);
        if (studentAuthorityEl.value !== authorityValue) {
          console.warn('⚠️ 権限の値が一致しません');
        }
      }
      window.currentStudentId = studentId;
      
      // 学生更新・削除ページに移動
      document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
      document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
      
      pageStudentEdit.classList.add('active');
      if (studentEditPanel) studentEditPanel.style.display = '';
      if (noStudentSelected) noStudentSelected.style.display = 'none';
      loadEditStudents();
    }

    // 発送確認検索
    const shippingSearchForm = document.getElementById('shippingSearchForm');
    if (shippingSearchForm) {
      shippingSearchForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const params = new URLSearchParams(new FormData(e.target));
      try {
        const res = await fetch('api/shipping.php?' + params);
        const results = await res.json();
        const resultsDiv = document.getElementById('shippingResults');
        
        if (!Array.isArray(results) || results.length === 0) {
          resultsDiv.innerHTML = '<p>検索結果が見つかりませんでした</p>';
          return;
        }

        resultsDiv.innerHTML = `
          <table style="width:100%; border-collapse:collapse; margin-top:20px;">
            <thead>
              <tr style="background:#34495e; color:white;">
                <th style="padding:12px; border:1px solid #ddd;">学籍番号</th>
                <th style="padding:12px; border:1px solid #ddd;">名前</th>
                <th style="padding:12px; border:1px solid #ddd;">書籍番号</th>
                <th style="padding:12px; border:1px solid #ddd;">年度</th>
                <th style="padding:12px; border:1px solid #ddd;">書名</th>
                <th style="padding:12px; border:1px solid #ddd;">著者</th>
              </tr>
            </thead>
            <tbody>
              ${results.map(r => `
                <tr>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.student_number || '')}</td>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.name || '')}</td>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.isbn || '')}</td>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.year || '')}</td>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.title || '')}</td>
                  <td style="padding:10px; border:1px solid #ddd;">${escapeHtml(r.author || '')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <p style="margin-top:12px; color:#666;">検索結果: ${results.length}件</p>
        `;
      } catch (err) {
        document.getElementById('shippingResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    });
    }

    // 学生情報を保存
    const studentForm = document.getElementById('studentForm');
    if (studentForm) {
      studentForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('student-name').value;
      const password = document.getElementById('student-password').value;
      const school = document.getElementById('student-school').value;
      const grade = document.getElementById('student-grade').value;
      const authority = document.getElementById('student-authority').value;
      
      console.log('フォーム送信データ:', { name, school, grade, authority });
      
      const body = new URLSearchParams({
        student_id: window.currentStudentId,
        name: name,
        password: password || '',
        school_id: school || '',
        user_grade: grade || '',
        authority: authority || '0'
      });
      
      console.log('送信するパラメータ:', Object.fromEntries(body));

      try {
        const res = await fetch('api/update_student.php', { method: 'POST', body });
        const json = await res.json();
        console.log('サーバーレスポンス:', json);
        const msg = document.getElementById('studentMessage');
        
        if (json.success) {
          msg.textContent = '学生情報を更新しました';
          msg.style.color = 'green';
        } else {
          msg.textContent = 'エラー: ' + (json.error || '更新に失敗しました');
          msg.style.color = 'red';
        }
        msg.style.display = 'block';
      } catch (err) {
        const msg = document.getElementById('studentMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.style.color = 'red';
        msg.style.display = 'block';
      }
    });
    }

    // 学生を削除
    const deleteStudentBtn = document.getElementById('deleteStudentBtn');
    if (deleteStudentBtn) {
      deleteStudentBtn.addEventListener('click', async () => {
      if (!confirm('この学生を削除しますか?')) return;
      try {
        const body = new URLSearchParams({ student_id: window.currentStudentId });
        const res = await fetch('api/delete_student.php', { method: 'POST', body });
        const json = await res.json();
        const msg = document.getElementById('studentMessage');
        
        if (json.success) {
          msg.textContent = '学生を削除しました';
          msg.style.color = 'green';
          msg.style.display = 'block';
          setTimeout(() => {
            document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
            document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
            
            document.getElementById('page-student-search').classList.add('active');
            const studentSearchLink = document.querySelector('.menu-link[data-page="student-search"]');
            if (studentSearchLink) studentSearchLink.classList.add('active');
          }, 2000);
        } else {
          msg.textContent = 'エラー: ' + (json.error || '削除に失敗しました');
          msg.style.color = 'red';
          msg.style.display = 'block';
        }
      } catch (err) {
        const msg = document.getElementById('studentMessage');
        msg.textContent = 'エラー: ' + err.message;
        msg.style.color = 'red';
        msg.style.display = 'block';
      }
    });
    }

    // 戻るボタン（学生更新・削除ページ）
    const cancelStudentBtn = document.getElementById('cancelStudentBtn');
    if (cancelStudentBtn) {
      cancelStudentBtn.addEventListener('click', () => {
        console.log('戻るボタンがクリックされました');
        // 学生検索ページに戻る
        document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.menu-link').forEach(l => l.classList.remove('active'));
        
        document.getElementById('page-student-search').classList.add('active');
        const searchLink = document.querySelector('.menu-link[data-page="student-search"]');
        if (searchLink) searchLink.classList.add('active');
        
        // 編集パネルをリセット
        const studentEditPanel = document.getElementById('studentEditPanel');
        const noStudentSelected = document.getElementById('noStudentSelected');
        if (studentEditPanel) studentEditPanel.style.display = 'none';
        if (noStudentSelected) noStudentSelected.style.display = 'block';
      });
    } else {
      console.error('cancelStudentBtn が見つかりません');
    }

    // 学生を追加
    const addStudentForm = document.getElementById('addStudentForm');
    if (addStudentForm) {
      addStudentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        console.log('学生追加フォーム送信開始');
        
        // FormDataをURLSearchParamsに変換（add_student.phpは$_POSTで受け取るため）
        const formData = new FormData(e.target);
        const body = new URLSearchParams(formData);
        const msg = document.getElementById('addStudentMessage');
        
        console.log('送信データ:', Object.fromEntries(body));

        try {
          // 正しいAPIエンドポイントに送信
          const res = await fetch('api/add_student.php', { 
            method: 'POST', 
            body: body 
          });
          
          console.log('レスポンスステータス:', res.status);
          
          // PHP側から返ってきたJSONを解析
          const json = await res.json();
          
          console.log('レスポンスJSON:', json);
          
          if (json.success) {
            msg.textContent = '学生を追加しました';
            msg.style.color = 'green';
            e.target.reset(); // 入力欄をクリア
          } else {
            // PHP側で「既に登録されています」などのエラーがあればここを表示
            msg.textContent = 'エラー: ' + (json.error || '追加に失敗しました');
            msg.style.color = 'red';
          }
          msg.style.display = 'block';
        } catch (err) {
          // 通信エラー（ファイルが見つからない、ネット断線など）の場合
          console.error('通信エラー:', err);
          msg.textContent = 'エラー: ' + err.message;
          msg.style.color = 'red';
          msg.style.display = 'block';
        }
      });
    }

    // 学生検索フォームハンドラ
    const studentsSearchForm = document.getElementById('studentsSearchForm');
    if (studentsSearchForm) {
      studentsSearchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const params = new URLSearchParams(new FormData(e.target));
        try {
          const res = await fetch('api/get_students.php?' + params);
          const students = await res.json();
          renderStudentSearchResults(students);
        } catch (err) {
          document.getElementById('studentsSearchResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
        }
      });
    }

    const resetBtn = document.getElementById('studentsSearchReset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        const f = document.getElementById('studentsSearchForm');
        if (!f) return;
        f.reset();
        const params = new URLSearchParams();
        fetch('api/get_students.php?' + params)
          .then(res => res.json())
          .then(students => renderStudentSearchResults(students))
          .catch(err => console.error(err));
      });
    }

    // 学校セレクトの初期化は不要（PHPで生成済み）
    // const SCHOOL_OPTIONS = ['A小学校', 'B小学校', 'A中学校'];
    // function populateSchoolSelects() {
    //   const selects = [document.getElementById('student-school'), document.getElementById('new-student-school'), document.getElementById('search-student-school')];
    //   selects.forEach(sel => {
    //     if (!sel) return;
    //     sel.innerHTML = '';
    //     const empty = document.createElement('option');
    //     empty.value = '';
    //     empty.textContent = '-- 学校を選択 --';
    //     sel.appendChild(empty);
    //     SCHOOL_OPTIONS.forEach(s => {
    //       const opt = document.createElement('option');
    //       opt.value = s;
    //       opt.textContent = s;
    //       sel.appendChild(opt);
    //     });
    //   });
    // }

    // マスタデータの読み込みとセレクトボックスの初期化
    let masterData = null;
    async function loadMasterData() {
      try {
        const res = await fetch('api/masters.php');
        masterData = await res.json();
        populateGenreSelects();
        populateLocationSelects();
      } catch (err) {
        console.error('マスタデータ読み込みエラー:', err);
      }
    }

    function populateGenreSelects() {
      if (!masterData || !masterData.genres) return;
      const selects = [
        { el: document.getElementById('genre'), defaultText: 'すべて' },
        { el: document.getElementById('add-genre'), defaultText: '選択してください' },
        { el: document.getElementById('edit-genre'), defaultText: '選択してください' }
      ];
      selects.forEach(s => {
        if (!s.el) return;
        const currentValue = s.el.value;
        s.el.innerHTML = `<option value="">${s.defaultText}</option>`;
        masterData.genres.forEach(g => {
          const opt = document.createElement('option');
          opt.value = g.genre_name;
          opt.textContent = g.genre_name;
          s.el.appendChild(opt);
        });
        if (currentValue) s.el.value = currentValue;
      });
    }

    function populateLocationSelects() {
      if (!masterData || !masterData.schools) return;
      const selects = [
        { el: document.getElementById('location'), defaultText: 'すべて' },
        { el: document.getElementById('add-location'), defaultText: '選択してください' },
        { el: document.getElementById('edit-location'), defaultText: '選択してください' }
      ];
      selects.forEach(s => {
        if (!s.el) return;
        const currentValue = s.el.value;
        s.el.innerHTML = `<option value="">${s.defaultText}</option>`;
        masterData.schools.forEach(school => {
          const opt = document.createElement('option');
          opt.value = school.school_name;
          opt.textContent = school.school_name;
          s.el.appendChild(opt);
        });
        if (currentValue) s.el.value = currentValue;
      });
    }

    document.addEventListener('DOMContentLoaded', () => {
      // populateSchoolSelects(); // PHPで生成済みなので不要
      loadMasterData();
    });
  </script>
</body>
</html>
