# 本の検索・管理システム

PHP + MySQL / SQLite を使用した本の検索・管理システムです。管理者画面と学生用画面の2つのインターフェースを提供しています。

## 動作手順

1. XAMPP を起動し、Apache を稼働させます。
2. ブラウザで以下のいずれかにアクセス:
   - **管理者画面**: `http://localhost/system_develop/admin.php`
   - **学生用画面**: `http://localhost/system_develop/login.php`（ログイン画面から）

## システム構成

### 管理者画面（admin.php）
- **本を検索**: ISBN、題名、著者、ジャンル、場所で本を検索
- **本を追加**: 新しい本をデータベースに登録
- **全件表示**: 登録済みの全ての本を表示
- **更新・削除**: 既存の本情報を編集または削除
- **本を返却**: 返却予定期間で本を検索し、返却状態を管理

### 学生用画面（login.php → student.php）
- **本を検索**: ISBN、題名、著者、ジャンル、場所で本を検索
- **借りた本の履歴**: 自分が借りた本の記録を確認（借出中/返却済み）
- **パスワード変更**: ログインパスワードを変更

## MySQL 設定

`api/db_config.php` を編集して MySQL の接続情報を設定してください:

```php
$DB_HOST = '127.0.0.1';
$DB_NAME = 'books';      // あなたのデータベース名
$DB_USER = 'root';
$DB_PASS = '';           // パスワード（必要に応じて）
$DB_CHARSET = 'utf8mb4';

$DB_TABLE = 'books';     // テーブル名
// カラム名マッピング（既存のテーブル列名に合わせる）
$COL_ISBN = 'book_id';
$COL_TITLE = 'book_name';
$COL_AUTHOR = 'author_name';
$COL_GENRE = 'book_genre';
$COL_LOCATION = 'book_school';
```

## 学生ログイン（デモ）

MySQL が未設定の場合、以下のデモアカウントでログイン可能:
- **学生ID**: `stu001`
- **パスワード**: `password123`

本番運用では、`api/db_config.php` を設定し、`students` テーブル（student_id, password_hash）を MySQL に作成してください。

## アカウント管理（学生・管理者）

`manage_accounts.php` CLI ツールを使用して、学生及び管理者のアカウントを作成・管理します。

### CLI ツール使用方法

```bash
# ディレクトリに移動
cd c:\xampp\htdocs\system_develop

# 学生アカウントを作成
php manage_accounts.php create-student stu001 password123 "学生太郎"

# 管理者アカウントを作成
php manage_accounts.php create-admin admin001 adminpass "管理者花子"

# すべてのアカウントを表示
php manage_accounts.php list-accounts

# アカウントを削除
php manage_accounts.php delete-account stu001 student
php manage_accounts.php delete-account admin001 admin

# ヘルプを表示
php manage_accounts.php help
```

### ログインフロー

**学生のログイン**:
1. `http://localhost/system_develop/login.php` にアクセス
2. 作成した学生アカウントの ID とパスワードを入力
3. ログイン成功後、`student.php` に移動
4. 右上の「ログアウト」で終了

**管理者のログイン**:
1. `http://localhost/system_develop/admin_login.php` にアクセス
2. 作成した管理者アカウントの ID とパスワードを入力
3. ログイン成功後、`admin.php` に移動
4. 左サイドバーの「ログアウト」で終了

### デモテスト手順

1. **デモアカウントを作成**:
   ```bash
   php manage_accounts.php create-demo
   ```
   これにより以下が自動作成されます:
   - 学生: stu001 / password123
   - 管理者: admin001 / adminpass

2. **管理者でログイン**: `http://localhost/system_develop/admin_login.php`
   - 管理者ID: admin001
   - パスワード: adminpass

3. **本を追加**: 管理者画面で数冊登録

4. **学生でログイン**: `http://localhost/system_develop/login.php`
   - 学生ID: stu001
   - パスワード: password123

5. **検索・履歴を確認**

## API エンドポイント

- `api/books.php` : 本の検索（GET）
- `api/add.php` : 本を追加（POST）
- `api/update.php` : 本を更新（POST）
- `api/delete.php` : 本を削除（POST）
- `api/return.php` : 本を返却済みにマーク（POST）
- `api/login.php` : 学生ログイン（POST）
- `api/logout.php` : 学生ログアウト（POST）
- `api/admin_login.php` : 管理者ログイン（POST）
- `api/admin_logout.php` : 管理者ログアウト（POST）
- `api/history.php` : 借出履歴取得（GET）
- `api/change_password.php` : パスワード変更（POST）

## ファイル構成

```
system_develop/
├── admin.php                    # 管理者画面（SPA）
├── admin_login.php              # 管理者ログイン画面
├── student.php                  # 学生用画面（SPA）
├── login.php                    # 学生ログイン画面
├── manage_accounts.php          # アカウント管理 CLI ツール
├── index.php.bak                # バックアップ
├── css/
│   └── style.css                # 共通スタイル
├── js/
│   └── app.js                   # 管理者画面用 JavaScript
├── api/
│   ├── db_config.php            # MySQL 接続設定（テンプレート）
│   ├── books.php                # 本検索 API
│   ├── add.php                  # 本追加 API
│   ├── update.php               # 本更新 API
│   ├── delete.php               # 本削除 API
│   ├── return.php               # 本返却 API
│   ├── login.php                # 学生ログイン API
│   ├── logout.php               # 学生ログアウト API
│   ├── admin_login.php          # 管理者ログイン API
│   ├── admin_logout.php         # 管理者ログアウト API
│   ├── history.php              # 履歴取得 API
│   ├── change_password.php      # パスワード変更 API
│   └── db_test.php              # MySQL 接続テスト
├── db/
│   └── books.db                 # SQLite データベース（自動生成）
└── README.md                    # このファイル
```

## 備考

- **セッション管理**: 学生・管理者共に PHP セッション（サーバーサイド）を使用します。ログイン状態は自動的に管理されます。
- **SQLite フォールバック**: MySQL が未設定の場合、`db/books.db`（SQLite）を自動作成してデータを保存します。
- **セキュリティ**: 本番運用では以下を追加してください:
  - SQL インジェクション対策（既に prepared statement を使用）
  - CSRF トークン
  - パスワード検証の強化
  - HTTPS の使用
  - ユーザー入力の厳密な検証
  - セッション固定化攻撃対策

## 動作確認

### 管理者画面で本を追加
1. `http://localhost/system_develop/admin.php` にアクセス
2. 「本を追加」メニューから本を登録
3. MySQL に接続設定していれば MySQL に、未設定なら SQLite に自動保存

### 学生画面でログイン・検索
1. `http://localhost/system_develop/login.php` にアクセス
2. デモアカウント（stu001 / password123）でログイン
3. 「本を検索」で本を検索
4. 「借りた本の履歴」でダミーの借出記録を表示
5. 「パスワード変更」でパスワードを変更

---

作成日: 2026年1月7日
