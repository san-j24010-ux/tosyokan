<?php
// 学生向けの画面
// SPA 形式: 検索（ホーム）、履歴、パスワード変更

session_start();

// セッションチェック: ログインしていなければ login.php へ
if (!isset($_SESSION['student_id'])) {
    header('Location: login.php');
    exit;
}

$student_id = $_SESSION['student_id'];
$student_name = $_SESSION['student_name'] ?? 'Student';
?>
<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>本の検索・管理システム - 学生用</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .student-container { display: flex; height: 100vh; }
    .student-sidebar { flex: 0 0 250px; background: #f5f5f5; border-right: 1px solid #ddd; overflow-y: auto; }
    .student-main { flex: 1; overflow-y: auto; }
    .student-header { background: #2c3e50; color: white; padding: 20px; }
    .student-header h2 { margin: 0 0 10px 0; font-size: 20px; }
    .student-header p { margin: 5px 0; font-size: 14px; }
    .student-menu { list-style: none; padding: 0; margin: 0; }
    .student-menu li { border-bottom: 1px solid #ddd; }
    .student-menu a { display: block; padding: 15px 20px; text-decoration: none; color: #333; transition: background 0.2s; }
    .student-menu a:hover { background: #e8e8e8; }
    .student-menu a.active { background: #3498db; color: white; }
    .student-page { padding: 30px; display: none; }
    .student-page.active { display: block; }
    .profile-card { background: white; border: 1px solid #ddd; border-radius: 5px; padding: 20px; margin-bottom: 20px; }
    .logout-btn { background: #e74c3c; color: white; border: none; padding: 10px 20px; border-radius: 3px; cursor: pointer; font-size: 14px; }
    .logout-btn:hover { background: #c0392b; }
  </style>
</head>
<body>
  <div class="student-container">
    <!-- 左サイドバー -->
    <aside class="student-sidebar">
      <div class="student-header">
        <h2>図書館</h2>
        <p id="studentNameDisplay">学生: <?php echo htmlspecialchars($student_name, ENT_QUOTES, 'UTF-8'); ?></p>
      </div>
      <ul class="student-menu">
        <li><a href="#" class="menu-link active" data-page="search">本を検索</a></li>
        <li><a href="#" class="menu-link" data-page="history">借りた本の履歴</a></li>
        <li><a href="#" class="menu-link" data-page="settings">パスワード変更</a></li>
        <li style="border-top: 2px solid #ccc; margin-top: 10px;"><button class="logout-btn" style="width: 100%; text-align: left; padding-left: 20px; border: none;" onclick="logout()">🚪 ログアウト</button></li>
      </ul>
    </aside>

    <!-- メインコンテンツ -->
    <main class="student-main">
      <!-- ページ: 本を検索（ホーム） -->
      <div class="student-page active" id="page-search">
        <h1 class="page-title">本を検索</h1>
        <form id="searchForm" class="search-form">
          <div class="form-row">
            <label>書籍番号<br><input type="text" name="isbn" placeholder="例: 001-001"></label>
            <label>本の題名<br><input type="text" name="title" placeholder="題名を入力"></label>
          </div>
          <div class="form-row">
            <label>本の著者名<br><input type="text" name="author" placeholder="著者名を入力"></label>
            <label>本のジャンル<br>
              <select name="genre">
                <option value="">すべて</option>
                <option>小説</option>
                <option>文学</option>
                <option>ビジネス・経済</option>
                <option>趣味・実用</option>
                <option>コミック・マンガ</option>
                <option>専門書</option>
                <option>児童書</option>
              </select>
            </label>
          </div>
          <div class="form-row">
            <label>本の場所<br>
              <select name="location">
                <option value="">すべて</option>
                <option>A小学校</option>
                <option>B小学校</option>
                <option>A中学校</option>
              </select>
            </label>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn">検索</button>
          </div>
        </form>
        <section id="searchResults" class="results"></section>
      </div>

      <!-- ページ: 借りた本の履歴 -->
      <div class="student-page" id="page-history">
        <h1 class="page-title">借りた本の履歴</h1>
        <div style="margin-bottom: 20px;">
          <label>状態: 
            <select id="historyFilter" style="padding: 5px;">
              <option value="">全て</option>
              <option value="borrowed">借出中</option>
              <option value="returned">返却済み</option>
            </select>
          </label>
        </div>
        <section id="historyResults" class="results"></section>
      </div>

      <!-- ページ: パスワード変更 -->
      <div class="student-page" id="page-settings">
        <h1 class="page-title">パスワード変更</h1>
        <div class="profile-card" style="max-width: 500px;">
          <h3>パスワードを変更します</h3>
          <form id="passwordForm">
            <div class="form-row">
              <label>現在のパスワード<br>
                <input type="password" name="current_password" placeholder="現在のパスワード" required>
              </label>
            </div>
            <div class="form-row">
              <label>新しいパスワード<br>
                <input type="password" name="new_password" placeholder="新しいパスワード" required>
              </label>
            </div>
            <div class="form-row">
              <label>新しいパスワード（確認）<br>
                <input type="password" name="new_password_confirm" placeholder="新しいパスワード（確認）" required>
              </label>
            </div>
            <div class="form-actions">
              <button type="submit" class="btn">変更</button>
            </div>
          </form>
          <div id="passwordMessage" class="message" style="display:none; margin-top:15px;"></div>
        </div>
      </div>
    </main>
  </div>

  <script>
    // メニュー切り替え
    document.querySelectorAll('.menu-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const pageName = link.getAttribute('data-page');
        showStudentPage(pageName);
      });
    });

    function showStudentPage(pageName) {
      // 全ページ非表示
      document.querySelectorAll('.student-page').forEach(p => p.classList.remove('active'));
      // 全メニュー非活性化
      document.querySelectorAll('.menu-link').forEach(m => m.classList.remove('active'));
      // 対象ページと対象メニューを活性化
      document.getElementById('page-' + pageName).classList.add('active');
      document.querySelector(`[data-page="${pageName}"]`).classList.add('active');

      if (pageName === 'history') {
        loadHistory();
      }
    }

    // 本を検索
    document.getElementById('searchForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const params = new URLSearchParams();
      for (const [k, v] of fd.entries()) {
        if (v.trim()) params.append(k, v.trim());
      }
      const url = 'api/books.php?' + params.toString();
      try {
        const res = await fetch(url);
        const data = await res.json();
        renderSearchResults(data || []);
      } catch (err) {
        document.getElementById('searchResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    });

    function renderSearchResults(books) {
      const el = document.getElementById('searchResults');
      el.innerHTML = '';
      if (!books || books.length === 0) {
        el.innerHTML = '<p style="color:#999;">該当する本が見つかりませんでした。</p>';
        return;
      }
      books.forEach(b => {
        const card = document.createElement('div');
        card.className = 'card';
        card.style.marginBottom = '15px';
        card.innerHTML = `
          <div class="cover"></div>
          <div class="meta">
            <p><strong>書籍番号:</strong> ${escapeHtml(b.isbn)}</p>
            <p><strong>本の題名:</strong> ${escapeHtml(b.title)}</p>
            <p><strong>本の著者名:</strong> ${escapeHtml(b.author)}</p>
            <p style="color:#666;"><strong>本のジャンル:</strong> ${escapeHtml(b.genre)} / <strong>本の場所:</strong> ${escapeHtml(b.location)}</p>
          </div>
        `;
        el.appendChild(card);
      });
    }

    // 履歴を読み込み
    async function loadHistory() {
      const filter = document.getElementById('historyFilter').value;
      try {
        const url = `api/history.php?student_id=${encodeURIComponent(getStudentId())}${filter ? '&status=' + filter : ''}`;
        const res = await fetch(url);
        const data = await res.json();
        renderHistory(data || []);
      } catch (err) {
        document.getElementById('historyResults').innerHTML = `<p style="color:red;">エラー: ${err.message}</p>`;
      }
    }

    function renderHistory(records) {
      const el = document.getElementById('historyResults');
      el.innerHTML = '';
      if (!records || records.length === 0) {
        el.innerHTML = '<p style="color:#999;">借出記録がありません。</p>';
        return;
      }
      records.forEach(r => {
        const status = r.returned_date ? '返却済み' : '借出中';
        const statusColor = r.returned_date ? '#27ae60' : '#e67e22';
        const card = document.createElement('div');
        card.style.border = '1px solid #ddd';
        card.style.borderRadius = '5px';
        card.style.padding = '15px';
        card.style.marginBottom = '15px';
        card.style.background = 'white';
        card.innerHTML = `
          <div style="display:flex; justify-content:space-between; align-items:start;">
            <div style="flex:1;">
              <p style="margin:5px 0;"><strong>${escapeHtml(r.book_title)}</strong></p>
              <p style="margin:5px 0; color:#666; font-size:14px;">著者: ${escapeHtml(r.book_author)}</p>
              <p style="margin:5px 0; color:#666; font-size:14px;">借出日: ${r.borrow_date}</p>
              <p style="margin:5px 0; color:#666; font-size:14px;">返却予定日: ${r.due_date}</p>
              ${r.returned_date ? `<p style="margin:5px 0; color:#666; font-size:14px;">返却日: ${r.returned_date}</p>` : ''}
            </div>
            <span style="background:${statusColor}; color:white; padding:5px 10px; border-radius:3px; font-size:12px; white-space:nowrap;">${status}</span>
          </div>
        `;
        el.appendChild(card);
      });
    }

    // 履歴フィルタ変更時
    document.getElementById('historyFilter').addEventListener('change', loadHistory);

    // パスワード変更
    document.getElementById('passwordForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const current = e.target.current_password.value;
      const newPass = e.target.new_password.value;
      const confirm = e.target.new_password_confirm.value;

      if (newPass !== confirm) {
        showPasswordMessage('新しいパスワードが一致しません', 'error');
        return;
      }

      if (newPass.length < 6) {
        showPasswordMessage('パスワードは6文字以上である必要があります', 'error');
        return;
      }

      try {
        const body = new URLSearchParams({
          student_id: getStudentId(),
          current_password: current,
          new_password: newPass
        });
        const res = await fetch('api/change_password.php', { method: 'POST', body });
        const json = await res.json();
        if (json.success) {
          showPasswordMessage('パスワードを変更しました', 'success');
          e.target.reset();
        } else {
          showPasswordMessage(json.error || 'パスワード変更に失敗しました', 'error');
        }
      } catch (err) {
        showPasswordMessage('エラー: ' + err.message, 'error');
      }
    });

    function showPasswordMessage(msg, type) {
      const el = document.getElementById('passwordMessage');
      el.textContent = msg;
      el.className = 'message ' + type;
      el.style.display = 'block';
      if (type === 'success') setTimeout(() => el.style.display = 'none', 3000);
    }

    // ログアウト
    function logout() {
      if (confirm('ログアウトしますか?')) {
        fetch('api/logout.php', { method: 'POST' })
          .then(() => {
            sessionStorage.removeItem('student_id');
            window.location.href = 'login.php';
          })
          .catch(err => {
            console.error('ログアウトエラー:', err);
            sessionStorage.removeItem('student_id');
            window.location.href = 'login.php';
          });
      }
    }

    // 学生 ID を取得（PHP セッションから）
    function getStudentId() {
      return <?php echo json_encode($student_id); ?>;
    }

    // HTML エスケープ
    function escapeHtml(s) {
      return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
  </script>
</body>
</html>
