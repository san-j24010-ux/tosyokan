document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('searchForm');
  const resultsEl = document.getElementById('results');
  const sortOrder = document.getElementById('sortOrder');

  function render(list){
    resultsEl.innerHTML = '';
    if(!list || list.length === 0){
      resultsEl.innerHTML = '<p class="muted">該当する本が見つかりませんでした。</p>';
      return;
    }
    list.forEach(b=>{
      const card = document.createElement('article');
      card.className = 'card';

      const cover = document.createElement('div');
      cover.className = 'cover';

      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.innerHTML = `
        <p>書籍番号　${escapeHtml(b.isbn)}</p>
        <p>本の題名　${escapeHtml(b.title)}</p>
        <p>本の著者名　${escapeHtml(b.author)}</p>
        <p class="muted">本のジャンル　${escapeHtml(b.genre)}　　<span class="right">本の場所　${escapeHtml(b.location)}</span></p>
      `;

      card.appendChild(cover);
      card.appendChild(meta);
      resultsEl.appendChild(card);
    });
  }

  function escapeHtml(s){
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  async function doSearch(){
    const f = new FormData(form);
    const params = new URLSearchParams();
    for (const [k,v] of f.entries()){
      if (v.trim() !== '') params.append(k, v.trim());
    }
    // sort は select の name=sort で送っている
    const sort = document.getElementById('sortOrder').value;
    params.set('sort', sort);

    const url = 'api/books.php?' + params.toString();
    try{
      const res = await fetch(url);
      if(!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      render(data);
    }catch(err){
      resultsEl.innerHTML = `<p class="muted">エラーが発生しました: ${escapeHtml(err.message)}</p>`;
    }
  }

  form.addEventListener('submit', e=>{ e.preventDefault(); doSearch(); });
  sortOrder.addEventListener('change', ()=>doSearch());

  // 初回表示
  doSearch();
});
