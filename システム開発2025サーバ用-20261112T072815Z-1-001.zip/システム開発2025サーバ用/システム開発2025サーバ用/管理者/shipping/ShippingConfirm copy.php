<?php
class ShippingConfirm {
    private static $pdo = null;
    
    // データベース接続を取得
    private static function getConnection() {
        if (self::$pdo === null) {
            $db_host = 'localhost'; 
            $db_name = 'Library';
            $db_user = 'user01';
            $db_pass = 'user01';
            $charset = 'utf8mb4';
            
            $dsn = "mysql:host=$db_host;dbname=$db_name;charset=$charset";
            
            try {
                self::$pdo = new PDO($dsn, $db_user, $db_pass);
            } catch (PDOException $e) {
                throw new Exception("データベース接続エラー: " . $e->getMessage());
            }
        }
        
        return self::$pdo;
    }
    
    // ステータス3（発送済み）の予約を取得
    // ユーザーの学校IDと一致し、book_id重複なし、予約時間が早い順
    public static function getShippedItems($userSchoolId, $userId = '', $isbn = '', $year = '') {
        $pdo = self::getConnection();
        
        // lendテーブルとbookテーブルを結合
        // ユーザーの学校IDと書籍の学校IDが異なる（他の学校への発送）
        // status_id=3（発送済み）の予約から、book_idごとに最も早い予約のみ取得(先着順)
        $sql = "
            SELECT 
                l.user_id,
                l.book_id,
                l.status_id,
                l.checkout_date,
                l.return_date,
                l.reservation_date,
                l.ban,
                b.isbn,
                b.school_id AS book_school_id,
                b.book_name,
                b.author_id,
                b.genre_id,
                b.photograph,
                u.school_id AS user_school_id
            FROM lend l
            INNER JOIN book b ON l.book_id = b.book_id
            LEFT JOIN users u ON l.user_id = u.user_id
            WHERE l.status_id = 3
            AND u.school_id = :user_school_id
            AND b.school_id != :user_school_id
            AND l.reservation_date = (
                SELECT MIN(l2.reservation_date)
                FROM lend l2
                WHERE l2.book_id = l.book_id
                AND l2.status_id = 3
            )
        ";
        
        $params = [':user_school_id' => $userSchoolId];
        
        // 検索条件を追加
        if (!empty($userId)) {
            $sql .= " AND l.user_id LIKE :user_id";
            $params[':user_id'] = '%' . $userId . '%';
        }
        
        if (!empty($isbn)) {
            $sql .= " AND b.isbn LIKE :isbn";
            $params[':isbn'] = '%' . $isbn . '%';
        }
        
        if (!empty($year)) {
            // 年度での検索（reservation_dateから年を抽出）
            $sql .= " AND YEAR(l.reservation_date) = :year";
            $params[':year'] = trim($year);
        }
        
        // 予約時間が早い順に並び替え
        $sql .= " ORDER BY l.reservation_date ASC";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    // ステータスを更新（3 → 1）発送完了
  public static function confirmShipping($userId, $bookId, $reservation_date) {
    $pdo = self::getConnection();

    // 対象取得
    $stmt = $pdo->prepare("
        SELECT ban
        FROM lend
        WHERE user_id = :user_id
          AND book_id = :book_id
          AND reservation_date = :reservation_date
          AND status_id = 3
    ");
    $stmt->execute([
        ':user_id' => $userId,
        ':book_id' => $bookId,
        ':reservation_date' => $reservation_date
    ]);

    $shipping = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$shipping) {
        return false;
    }

    $isBan = !empty($shipping['ban']);

    if (!$isBan) {
        $sql = "
            UPDATE lend
            SET status_id = 1,
                checkout_date = CURDATE(),
                return_date = DATE_ADD(CURDATE(), INTERVAL 7 DAY)
            WHERE user_id = :user_id
              AND book_id = :book_id
              AND reservation_date = :reservation_date
              AND status_id = 3
        ";
    } else {
        $sql = "
            UPDATE lend
            SET status_id = 1
            WHERE user_id = :user_id
              AND book_id = :book_id
              AND reservation_date = :reservation_date
              AND status_id = 3
        ";
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':user_id' => $userId,
        ':book_id' => $bookId,
        ':reservation_date' => $reservation_date
    ]);

    return $stmt->rowCount() > 0;
}

    
    // 複数件を一括で発送完了にする
    public static function confirmMultiple($items) {
        $pdo = self::getConnection();
        $successCount = 0;
        $failCount = 0;
        
        foreach ($items as $item) {
            list($userId, $bookId) = explode('|', $item);
            
            try {
                $result = self::confirmShipping($userId, $bookId, $reservation_date);
                if ($result) {
                    $successCount++;
                } else {
                    $failCount++;
                }
            } catch (Exception $e) {
                $failCount++;
            }
        }
        
        return ['success' => $successCount, 'fail' => $failCount];
    }
}
?>