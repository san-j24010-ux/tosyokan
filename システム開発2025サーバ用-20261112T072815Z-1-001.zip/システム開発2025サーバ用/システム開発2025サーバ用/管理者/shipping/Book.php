<?php
class Book {
    private static $pdo = null;
    
    // データベース接続を取得
    private static function getConnection() {
        if (self::$pdo === null) {
            $db_host = 'localhost'; 
            $db_name = '図書館';
            $db_user = 'root';
            $db_pass = '';
            $charset = 'utf8mb4';
            
            $dsn = "mysql:host=$db_host;dbname=$db_name;charset=$charset";
            
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,  
            ];
            
            try {
                self::$pdo = new PDO($dsn, $db_user, $db_pass, $options);
            } catch (PDOException $e) {
                throw new Exception("データベース接続エラー: " . $e->getMessage());
            }
        }
        
        return self::$pdo;
    }
    
    // 全件取得
    public static function getAll() {
        try {
            $pdo = self::getConnection();
            $stmt = $pdo->query("SELECT * FROM book");
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log($e->getMessage());
            return [];
        }
    }
    
    // 検索
    // 検索
// 検索
public static function search($student_number = '', $isbn = '', $year = '') {
    try {
        $pdo = self::getConnection();
        
        $sql = "SELECT * FROM book WHERE 1=1";
        $params = [];
        
        if (!empty($student_number)) {
            $sql .= " AND student_number LIKE :student_number";
            $params[':student_number'] = '%' . $student_number . '%';
        }
        
        if (!empty($isbn)) {
            $sql .= " AND isbn LIKE :isbn";
            $params[':isbn'] = '%' . $isbn . '%';
        }
        
        if (!empty($year)) {
            // yearは数値型なので = で比較
            $sql .= " AND year = :year";
            $params[':year'] = trim($year);  // 前後の空白を削除
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll();
        
    } catch (Exception $e) {
        error_log($e->getMessage());
        return [];
    }
}
}
?>