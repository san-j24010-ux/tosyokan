<?php
require_once 'Book.php';

$searchResults = [];
$searched = false;
$errorMessage = '';

// 変数を先に初期化(ifブロックの外)
$student_number = $_GET['student_number'] ?? '';
$isbn = $_GET['isbn'] ?? '';
$year = $_GET['year'] ?? '';

// 検索処理
if (isset($_GET['search'])) {
    try {
        $searchResults = Book::search($student_number, $isbn, $year);
        $searched = true;
        
    } catch (Exception $e) {
        $errorMessage = "検索エラー: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>検索</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <?php if ($errorMessage): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($errorMessage); ?>
            </div>
        <?php endif; ?>
        
        <form method="GET" action="">
            <div class="search-header">
                <input type="text" id="student_number" name="student_number" placeholder="学籍番号" value="<?php echo htmlspecialchars($_GET['student_number'] ?? ''); ?>">
                <span class="search-icon">🔍</span>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="isbn">書籍番号</label>
                    <input type="text" id="isbn" name="isbn" value="<?php echo htmlspecialchars($_GET['isbn'] ?? ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="year">年度</label>
                    <input type="text" id="year" name="year" value="<?php echo htmlspecialchars($_GET['year'] ?? ''); ?>">
                </div>
            </div>
            
            <div class="button-container">
                <button type="submit" name="search" value="1">検索</button>
            </div>
        </form>
        
        <?php if ($searched): ?>
            <div class="results">
                <?php if (count($searchResults) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>学籍番号</th>
                                <th>名前</th>
                                <th>書籍番号</th>
                                <th>年度</th>
                                <th>書名</th>
                                <th>著者</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($searchResults as $book): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($book['student_number'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($book['name'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($book['isbn'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($book['year'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($book['title'] ?? ''); ?></td>
                                    <td><?php echo htmlspecialchars($book['author'] ?? ''); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p class="result-count">検索結果: <?php echo count($searchResults); ?>件</p>
                <?php else: ?>
                    <p class="no-results">検索結果が見つかりませんでした</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>