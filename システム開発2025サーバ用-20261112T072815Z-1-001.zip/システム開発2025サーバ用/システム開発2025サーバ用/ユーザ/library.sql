-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2026-01-21 04:15:18
-- サーバのバージョン： 10.4.32-MariaDB
-- PHP のバージョン: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `library`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `author`
--

CREATE TABLE `author` (
  `author_id` varchar(20) NOT NULL,
  `author_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `author`
--

INSERT INTO `author` (`author_id`, `author_name`) VALUES
('A001', '夏目漱石'),
('A002', '村上春樹');

-- --------------------------------------------------------

--
-- テーブルの構造 `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `isbn` varchar(40) DEFAULT NULL,
  `school_id` varchar(20) NOT NULL,
  `book_name` varchar(40) NOT NULL,
  `author_id` varchar(20) DEFAULT NULL,
  `genre_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `photograph` varchar(100) DEFAULT NULL,
  `synopsis` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `book`
--

INSERT INTO `book` (`book_id`, `isbn`, `school_id`, `book_name`, `author_id`, `genre_id`, `status_id`, `photograph`, `synopsis`) VALUES
(1, '978-0000000001', 'S001', 'こころ', 'A001', 1, 1, 'jpg/kokoro.jpg', '人間の心の葛藤を描いた名作'),
(2, '978-0000000002', 'S002', 'ノルウェイの森', 'A002', 1, 2, 'jpg/norwegian.jpg', '青春と喪失を描く物語');

-- --------------------------------------------------------

--
-- テーブルの構造 `genre`
--

CREATE TABLE `genre` (
  `genre_id` int(11) NOT NULL,
  `genre_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `genre`
--

INSERT INTO `genre` (`genre_id`, `genre_name`) VALUES
(1, 'バトル'),
(2, '恋愛'),
(3, 'スポーツ'),
(4, '文学'),
(5, 'IT'),
(6, 'コミック');

-- --------------------------------------------------------

--
-- テーブルの構造 `lend`
--

CREATE TABLE `lend` (
  `user_id` varchar(20) NOT NULL,
  `book_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `checkout_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `reservation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `lend`
--

INSERT INTO `lend` (`user_id`, `book_id`, `status_id`, `checkout_date`, `return_date`, `reservation_date`) VALUES
('j23001', 1, 3, NULL, NULL, '2026-01-21'),
('j23008', 2, 2, NULL, NULL, '2026-01-21');

-- --------------------------------------------------------

--
-- テーブルの構造 `school`
--

CREATE TABLE `school` (
  `school_id` varchar(20) NOT NULL,
  `school_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `school`
--

INSERT INTO `school` (`school_id`, `school_name`) VALUES
('S001', '静岡産業技術専門学校'),
('S002', '帝京大学');

-- --------------------------------------------------------

--
-- テーブルの構造 `status`
--

CREATE TABLE `status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, '貸出'),
(2, '予約'),
(3, '運搬');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `user_id` varchar(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `user_grade` int(11) DEFAULT NULL,
  `user_password` varchar(20) NOT NULL,
  `user_authority` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `school_id`, `user_grade`, `user_password`, `user_authority`) VALUES
('j23001', '佐藤花子', 'S002', 3, 'pass456', 0),
('j23008', '長田武龍', 'S001', 3, 'j23008', 1);

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`author_id`);

--
-- テーブルのインデックス `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `fk_book_school` (`school_id`),
  ADD KEY `fk_book_genre` (`genre_id`),
  ADD KEY `fk_book_status` (`status_id`),
  ADD KEY `fk_book_author` (`author_id`);

--
-- テーブルのインデックス `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`genre_id`);

--
-- テーブルのインデックス `lend`
--
ALTER TABLE `lend`
  ADD PRIMARY KEY (`user_id`,`book_id`,`reservation_date`),
  ADD KEY `fk_lend_book` (`book_id`),
  ADD KEY `fk_lend_status` (`status_id`);

--
-- テーブルのインデックス `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- テーブルのインデックス `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_user_school` (`school_id`);

--
-- ダンプしたテーブルの制約
--

--
-- テーブルの制約 `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `fk_book_author` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`),
  ADD CONSTRAINT `fk_book_genre` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`genre_id`),
  ADD CONSTRAINT `fk_book_school` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`),
  ADD CONSTRAINT `fk_book_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`);

--
-- テーブルの制約 `lend`
--
ALTER TABLE `lend`
  ADD CONSTRAINT `fk_lend_book` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`),
  ADD CONSTRAINT `fk_lend_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`),
  ADD CONSTRAINT `fk_lend_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- テーブルの制約 `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_user_school` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
