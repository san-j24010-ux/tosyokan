<?php
ini_set('display_errors', 1);

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01');     

$user_name = $_SESSION['user_name'];
$user_id   = $_SESSION['user_id'];

// ===== DB接続 =====
$pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE =>
PDO::ERRMODE_EXCEPTION] ); 
// ===== ジャンル取得 ===== 
$genres = $pdo->query(
"SELECT genre_id, genre_name FROM genre ORDER BY genre_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 著者取得 ===== 
$authors = $pdo->query(
"SELECT author_id, author_name FROM author ORDER BY author_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 学校取得 ===== 
$schools = $pdo->query(
"SELECT school_id, school_name FROM school ORDER BY school_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 題名取得 =====
$titles = $pdo->query(
"SELECT book_name FROM book ORDER BY book_name"
)->fetchAll(PDO::FETCH_ASSOC); 

// ===== ユーザーが最も借りているジャンル =====
$topGenreSql = "
SELECT
  b.genre_id
FROM lend l
JOIN book b ON l.book_id = b.book_id
WHERE l.user_id = :user_id
GROUP BY b.genre_id
ORDER BY COUNT(*) DESC
LIMIT 1
";

$stmt = $pdo->prepare($topGenreSql);
$stmt->execute([':user_id' => $user_id]);
$topGenre = $stmt->fetchColumn();

$recommendBooks = [];

if ($topGenre) {
  $recommendSql = "
SELECT
  b.book_id,
  b.isbn,
  b.book_name,
  b.photograph,
  g.genre_name
FROM book b
JOIN genre g ON b.genre_id = g.genre_id
WHERE b.genre_id = :genre_id
ORDER BY b.book_name
LIMIT 5
";


  $stmt = $pdo->prepare($recommendSql);
  $stmt->execute([':genre_id' => $topGenre]);
  $recommendBooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// ===== いいねランキング（いいね1以上・上位5位）=====
$likeRankSql = "
SELECT
  b.book_id,
  b.book_name,
  b.photograph,
  b.isbn,
  COUNT(bl.like_id) AS like_count
FROM book_like bl
JOIN book b ON bl.book_id = b.book_id
GROUP BY b.book_id, b.book_name, b.photograph
HAVING COUNT(bl.like_id) >= 1
ORDER BY like_count DESC
LIMIT 5
";


$likeRanks = $pdo->query($likeRankSql)->fetchAll(PDO::FETCH_ASSOC);

?>

<!doctype html>
<html lang="ja">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>本検索（学生ホーム）</title>

    <style>
      /* ヘッダー */
      .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;

        background-color: #000; /* ← ヘッダー全体を黒 */
        color: #fff; /* ← 中の文字を白 */
        padding: 15px 20px; /* ← 上下左右の余白 */
      }

      .header h1 {
        font-size: 22px;
        color: #fff; /* ← 白に変更 */
        margin: 0;
      }

      .user-name {
        font-size: 14px;
        color: #ddd; /* ← 少し薄い白 */
      }

      /* 上段 */
      .top-section {
        display: flex;
        justify-content: space-between;
        gap: 30px;
        margin-bottom: 30px;
        padding: 15px;
      }

      /* 検索エリア */
      .search-area {
        background: #f7faff;
        border-radius: 12px;
        padding: 20px;
        flex: 1;
      }

      .search-title {
        font-weight: bold;
        margin-bottom: 15px;
        color: #1f3a5f;
      }

      .search-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
      }

      .search-grid input,
      .search-grid select {
        height: 38px;
        padding: 0 10px;
        border-radius: 6px;
        border: 1px solid #bfc7d1;
      }

      /* 件数 */
      .count-display {
        margin-top: 15px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 14px;
      }

      /* メニュー */
      .user-menu {
        width: 220px;
        background: #1f3a5f;
        color: #fff;
        border-radius: 12px;
        padding: 20px;
      }

      .user-menu h3 {
        font-size: 16px;
        margin-top: 0;
        margin-bottom: 15px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.3);
        padding-bottom: 8px;
      }

      .user-menu ul {
        list-style: none;
        padding: 0;
        margin: 0;
      }

      .user-menu li {
        margin-bottom: 10px;
        font-size: 14px;
      }

      .user-menu a {
        color: #fff;
        text-decoration: none;
      }

      .user-menu a:hover {
        text-decoration: underline;
      }

      /* テーブル */
      .table-area {
        margin-top: 20px;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      th {
        background: #e9eff7;
        padding: 10px;
        font-size: 14px;
      }

      td {
        border-bottom: 1px solid #ddd;
        padding: 10px;
        font-size: 14px;
      }

      /* フッターボタン */
      .footer-buttons {
        position: absolute;
        bottom: 25px;
        right: 40px;
        display: flex;
        gap: 15px;
      }

      button {
        height: 40px;
        padding: 0 25px;
        border-radius: 20px;
        border: none;
        font-size: 14px;
        cursor: pointer;
      }

      .btn-refresh {
        background: #d9e3f2;
      }

      .btn-logout {
        background: #1f3a5f;
        color: #fff;
      }

      .search-button-area {
        margin-top: 20px;
        text-align: right;
      }

      .btn-search {
        background: #1f3a5f;
        color: #fff;
        height: 38px;
        padding: 0 30px;
        border-radius: 20px;
        border: none;
        font-size: 14px;
        cursor: pointer;
      }

      .btn-search:hover {
        background: #162c49;
      }

      .btn-refresh:hover {
        background: #c7d6ec;
      }
      .btn-logout:hover {
        background: #162c49;
      }


/* ===== 本カード表示 ===== */
.book-card-list {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 15px;
}

.book-card {
  background: #fff;
  border-radius: 12px;
  padding: 10px;
  text-align: center;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
}

.book-card img {
  width: 100%;
  height: 140px;
  object-fit: contain;
  margin-bottom: 8px;
}

.book-info {
  font-size: 13px;
}

.book-title {
  font-weight: bold;
  color: #333;
  margin-bottom: 4px;
}

.book-genre {
  font-size: 12px;
  background: #6c8edc;
  color: #fff;
  padding: 2px 8px;
  border-radius: 10px;
}

.like-count {
  font-size: 12px;
  color: #e25555;
  font-weight: bold;
}

/* レスポンシブ */
@media (max-width: 1100px) {
  .book-card-list {
    grid-template-columns: repeat(3, 1fr);
  }
}
@media (max-width: 700px) {
  .book-card-list {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* ===== おすすめ・ランキング ===== */
.recommend-wrapper {
  display: flex;
  flex-direction: column;
  padding: 20px 22px;
  gap: 30px;
}


.recommend-box,
.ranking-box {
  background: #ffffff;
  border-radius: 14px;
  padding: 20px 22px;
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.08);
}

.recommend-box {
  border-left: 6px solid #f4b400;
}

.ranking-box {
  border-left: 6px solid #e25555;
}

.recommend-box h3,
.ranking-box h3 {
  margin-top: 0;
  margin-bottom: 15px;
  font-size: 16px;
  color: #1f3a5f;
}

/* リスト */
.recommend-box ul,
.ranking-box ol {
  margin: 0;
  padding-left: 20px;
}

.recommend-box li,
.ranking-box li {
  margin-bottom: 10px;
  font-size: 14px;
  line-height: 1.4;
}

/* 本タイトル */
.book-title {
  font-weight: bold;
  color: #333;
}

/* ジャンル */
.book-genre {
  margin-left: 8px;
  font-size: 12px;
  color: #fff;
  background: #6c8edc;
  padding: 2px 8px;
  border-radius: 10px;
}

/* いいね数 */
.like-count {
  margin-left: 8px;
  font-size: 12px;
  color: #e25555;
  font-weight: bold;
}

/* 空表示 */
.empty-msg {
  font-size: 13px;
  color: #888;
}

/* レスポンシブ */
@media (max-width: 900px) {
  .recommend-wrapper {
    grid-template-columns: 1fr;
  }
}


    </style>
  </head>

  <body>
    <div class="header">
      <h1>📚 図書検索システム</h1>
      <div class="user-name">
        ログイン中：<?php echo htmlspecialchars($user_name,ENT_QUOTES,'UTF-8');
        ?>
        <button class="btn-logout"
        onclick="if (confirm('ログアウトしますか？')) location.href='login.php';">
         ログアウト
        </button>
      </div>
    </div>

    <div class="top-section">
      <div class="search-area">
        <div class="search-title">検索条件</div>

        <form method="get" action="menu.php">
           <input type="hidden" name="page" value="search">


          <div class="search-grid">
            <?php $titleValue = $_GET['title'] ?? ''; ?>

            <input
              type="text"
              name="title"
              list="title_list"
              placeholder="題名"
              value="<?= htmlspecialchars($titleValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="title_list">
              <?php foreach ($titles as $title): ?>
              <option
                value="<?= htmlspecialchars($title['book_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>

            <?php $authorValue = $_GET['author'] ?? ''; ?>

            <input
              type="text"
              name="author"
              list="author_list"
              placeholder="著者名"
              value="<?= htmlspecialchars($authorValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="author_list">
              <?php foreach ($authors as $author): ?>
              <option
                value="<?= htmlspecialchars($author['author_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>

            <?php $genreValue = $_GET['genre'] ?? ''; ?>

            <input
              type="text"
              name="genre"
              list="genre_list"
              placeholder="ジャンル"
              value="<?= htmlspecialchars($genreValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="genre_list">
              <?php foreach ($genres as $genre): ?>
              <option
                value="<?= htmlspecialchars($genre['genre_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>
          </div>

          <!-- 🔍 検索ボタン -->
          <div class="search-button-area">
            <button type="submit" class="btn-search">検索</button>
          </div>
        </form>
        
      </div>
      

      <div class="user-menu">
        <h3>学生メニュー</h3>
        <ul>
          <li><a href="password_change.php">🔑 パスワード変更</a></li>
          <li><a href="book_history.php">📖 本の履歴</a></li>
          <li><a href="book_like_history.php">❤️ いいね履歴</a></li>
        </ul>
      </div>
    </div>


    <div class="recommend-wrapper">

  <!-- おすすめ -->
  <div class="recommend-box">
    <h3>⭐ あなたへのおすすめ</h3>

    <?php if (!empty($recommendBooks)): ?>
      <div class="book-card-list">
        <?php foreach ($recommendBooks as $book): ?>
          <a href="book_details.php?isbn=<?= urlencode($book['isbn']) ?>" class="book-link">
          <div class="book-card">
            <img
              src="<?= htmlspecialchars($book['photograph'], ENT_QUOTES, 'UTF-8') ?>"
              alt="表紙"
            />
            <div class="book-info">
              <div class="book-title">
                <?= htmlspecialchars($book['book_name'], ENT_QUOTES, 'UTF-8') ?>
              </div>
              <span class="book-genre">
                <?= htmlspecialchars($book['genre_name'], ENT_QUOTES, 'UTF-8') ?>
              </span>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="empty-msg">まだおすすめがありません</p>
    <?php endif; ?>
  </div>

  <!-- いいねランキング -->
  <div class="ranking-box">
    <h3>❤️ いいねランキング</h3>

    <?php if (!empty($likeRanks)): ?>
      <div class="book-card-list">
        <?php foreach ($likeRanks as $rank): ?>
          <a href="book_details.php?isbn=<?= urlencode($rank['isbn']) ?>" class="book-link">
          <div class="book-card">
            <img
              src="<?= htmlspecialchars($rank['photograph'], ENT_QUOTES, 'UTF-8') ?>"
              alt="表紙"
            />
            <div class="book-info">
              <div class="book-title">
                <?= htmlspecialchars($rank['book_name'], ENT_QUOTES, 'UTF-8') ?>
              </div>
              <div class="like-count">
                ❤️ <?= $rank['like_count'] ?>
              </div>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="empty-msg">いいねされた本はまだありません</p>
    <?php endif; ?>
  </div>

</div>
  </body>
</html>
