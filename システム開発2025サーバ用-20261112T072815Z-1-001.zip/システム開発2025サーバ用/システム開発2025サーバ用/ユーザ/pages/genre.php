<?php
/* ===== 前提 =====
   このファイルを include している親で
   session_start() はすでに実行されていること
*/

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01'); 

// ===== セッションからジャンルID取得 =====
$genre_id = $_SESSION['genre_id'] ?? '';

if ($genre_id === '') {
    echo 'ジャンルが選択されていません。';
    exit;
}

// ===== DB接続 =====
$pdo = new PDO(
    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

// ===== ジャンル名取得 =====
$sql_genre = "SELECT genre_name FROM genre WHERE genre_id = :genre_id";
$stmt = $pdo->prepare($sql_genre);
$stmt->bindParam(':genre_id', $genre_id, PDO::PARAM_INT);
$stmt->execute();

$genre = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$genre) {
    echo '該当するジャンルが存在しません。';
    exit;
}

$genre_name = $genre['genre_name'];

// ===== 本一覧取得 =====
$sql_books = "
SELECT
    b.book_name,
    b.photograph,
    b.isbn,
    a.author_name,
    g.genre_name,
    COUNT(b.book_id) AS total_count,
    COUNT(CASE WHEN l.status_id = 2 THEN 1 END) AS reservation_count
FROM book b
LEFT JOIN author a
    ON b.author_id = a.author_id
LEFT JOIN genre g
    ON b.genre_id = g.genre_id
LEFT JOIN lend l
    ON b.book_id = l.book_id
LEFT JOIN status s
    ON l.status_id = s.status_id
    AND s.status_name = '予約'
WHERE b.genre_id = :genre_id
GROUP BY
    b.isbn,
    b.book_name,
    b.photograph,
    a.author_name,
    g.genre_name;
";


$stmt = $pdo->prepare($sql_books);
$stmt->bindParam(':genre_id', $genre_id, PDO::PARAM_INT);
$stmt->execute();

$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
$has_books = !empty($books);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($genre_name, ENT_QUOTES, 'UTF-8') ?>｜蔵書一覧</title>

<style>

/* ヘッダー */
.header {
    display: flex;
    align-items: center;

    background-color: #000;
    color: #fff;

    padding: 15px 20px;   /* ← ヘッダー内の余白だけ */
    margin: 0;            /* ← 外側余白はゼロ */
}


.header h1 {
    font-size: 22px;
    color: #fff;   /* ← 白に変更 */
    margin: 0;
}

body {
    margin: 0;
    padding: 0;
}


/* ===== メイン ===== */
.top {
    padding: 30px;   /* ← ここに余白を集中させる */
}


/* ===== 見出し ===== */
.genre-title {
    font-size: 24px;
    margin-bottom: 25px;
    padding-bottom: 10px;
    border-bottom: 2px solid #2f4f4f;
    color: #2f4f4f;
}

/* ===== 本一覧 ===== */
.book-list {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 26px;
}

.book-link {
    text-decoration: none; /* 下線を消す */
    color: inherit;        /* 親の文字色を継承 */
    display: block;        /* カード全体をクリック可能に */
}

/* ===== 本カード ===== */
.book-card {
    background: #fdfdfb;
    border: 1px solid #cfcfcf;
    padding: 15px;

    display: flex;
    gap: 15px;
    align-items: flex-start;
}


/* 表紙 */
.book-card img {
    width: 110px;
    height: 160px;
    object-fit: cover;
    background: #eee;
    border: 1px solid #bbb;
}


/* タイトル */
.book-title {
    font-weight: bold;
    font-size: 15px;
    margin-bottom: 10px;
}

/* 情報 */
.book-info {
    font-size: 14px;
    line-height: 1.8;
}

/* 2列固定レイアウト */
.info-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 20px;
}


/* ===== 本がない場合 ===== */
.no-book {
    margin-top: 50px;
    padding: 40px;
    background: #fff;
    border: 1px dashed #999;
    text-align: center;
    font-size: 18px;
    color: #555;
}
</style>
</head>

<body>

<div class="header">
    <h1>📚 図書検索システム</h1>
</div>

<div class="top">
    <h2 class="genre-title">
        <?= htmlspecialchars($genre_name, ENT_QUOTES, 'UTF-8') ?> ジャンル
    </h2>

    <?php if (!$has_books): ?>
        <!-- 本が1冊もない場合 -->
        <div class="no-book">
            本が見つかりませんでした
        </div>
    <?php else: ?>
        <!-- 本がある場合 -->
        <div class="book-list">
            <?php foreach ($books as $book): ?>
            <a href="book_details.php?isbn=<?= urlencode($book['isbn']) ?>" class="book-link">
            <div class="book-card">

                <!-- 右：画像 -->
                <img src="<?= htmlspecialchars($book['photograph'], ENT_QUOTES, 'UTF-8') ?>" alt="表紙">


               <!-- 左：テキスト -->
                <div class="book-text">
                    <div class="book-title">
                        <?= htmlspecialchars($book['book_name'], ENT_QUOTES, 'UTF-8') ?>
                    </div>

                    <div class="book-info">
                        <div class="info-row">
                            <span>ジャンル：<?= htmlspecialchars($book['genre_name'], ENT_QUOTES, 'UTF-8') ?></span>
                            <span>予約数：<?= $book['reservation_count'] ?> 人</span>
                        </div>
                        <div class="info-row">
                            <span>著者：<?= htmlspecialchars($book['author_name'] ?? '不明', ENT_QUOTES, 'UTF-8') ?></span>
                            <span>所蔵数：<?= $book['total_count'] ?> 冊</span>
                        </div>
                    </div>


                </div>

                
            </div>
            </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>


</div>
</body>
</html>
