<?php
/* ===== 前提 =====
   このファイルを include している親で
   session_start() はすでに実行されていること
*/

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01');   

// ===== GETから取得 =====
$title  = $_GET['title']  ?? '';
$genre  = $_GET['genre']  ?? '';
$author = $_GET['author'] ?? '';

// ===== DB接続 =====
$pdo = new PDO(
    'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8',
    DB_USER,
    DB_PASS,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

// ===== ジャンル取得 ===== 
$genres = $pdo->query(
"SELECT genre_id, genre_name FROM genre ORDER BY genre_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 著者取得 ===== 
$authors = $pdo->query(
"SELECT author_id, author_name FROM author ORDER BY author_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 学校取得 ===== 
$schools = $pdo->query(
"SELECT school_id, school_name FROM school ORDER BY school_name"
)->fetchAll(PDO::FETCH_ASSOC); 
// ===== 題名取得 =====
$titles = $pdo->query(
"SELECT book_name FROM book ORDER BY book_name"
)->fetchAll(PDO::FETCH_ASSOC);

$sql = "
SELECT
    /* 代表のbook_id */
    MIN(b.book_id) AS book_id,          
    b.isbn,
    MIN(b.book_name) AS book_name,
    MIN(a.author_name) AS author_name,
    MIN(g.genre_name) AS genre_name,
    MIN(s.school_name) AS school_name,
    MIN(b.photograph) AS photograph,
    MIN(b.synopsis) AS synopsis,

    /* 所蔵数（同じISBNの冊数） */
    COUNT(DISTINCT b.book_id) AS total_count,

    /* 予約数（同じISBNの予約数） */
    COUNT(CASE WHEN l.status_id = 2 THEN 1 END) AS reservation_count

FROM book b

LEFT JOIN lend l
    ON b.book_id = l.book_id
    AND l.reservation_date IS NOT NULL

LEFT JOIN author a ON b.author_id = a.author_id
LEFT JOIN genre  g ON b.genre_id  = g.genre_id
LEFT JOIN school s ON b.school_id = s.school_id

WHERE 1=1

";


$params = [];

// 題名
if ($title !== '') {
    $sql .= " AND b.book_name LIKE :title";
    $params[':title'] = '%' . $title . '%';
}

// ジャンル
if ($genre !== '') {
    $sql .= " AND g.genre_name = :genre";
    $params[':genre'] = $genre;
}

// 著者
if ($author !== '') {
    $sql .= " AND a.author_name LIKE :author";
    $params[':author'] = '%' . $author . '%';
}


$sql .= "
GROUP BY
    b.isbn
ORDER BY
    book_name
";



$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
$has_books = !empty($books);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($genre_name, ENT_QUOTES, 'UTF-8') ?>｜蔵書一覧</title>

<style>

/* ヘッダー */
.header {
    display: flex;
    align-items: center;

    background-color: #000;
    color: #fff;

    padding: 15px 20px;   /* ← ヘッダー内の余白だけ */
    margin: 0;            /* ← 外側余白はゼロ */
}


.header h1 {
    font-size: 22px;
    color: #fff;   /* ← 白に変更 */
    margin: 0;
}

body {
    margin: 0;
    padding: 0;
}


/* ===== メイン ===== */
.top {
    padding: 30px;   /* ← ここに余白を集中させる */
}


/* ===== 見出し ===== */
.search-results {
    font-size: 24px;
    margin-bottom: 25px;
    padding-bottom: 10px;
    border-bottom: 2px solid #2f4f4f;
    color: #2f4f4f;
}

/* ===== 本一覧 ===== */
.book-list {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 26px;
}


/* ===== 本カード ===== */
.book-card {
    background: #fdfdfb;
    border: 1px solid #cfcfcf;
    padding: 15px;

    display: flex;
    gap: 15px;
    align-items: flex-start;
}


/* 表紙 */
.book-card img {
    width: 110px;
    height: 160px;
    object-fit: cover;
    background: #eee;
    border: 1px solid #bbb;
}


/* タイトル */
.book-title {
    font-weight: bold;
    font-size: 15px;
    margin-bottom: 10px;
}

/* 情報 */
.book-info {
    font-size: 14px;
    line-height: 1.8;
}

/* 2列固定レイアウト */
.info-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    column-gap: 20px;
}


/* ===== 本がない場合 ===== */
.no-book {
    margin-top: 50px;
    padding: 40px;
    background: #fff;
    border: 1px dashed #999;
    text-align: center;
    font-size: 18px;
    color: #555;
}

      .user-name {
        font-size: 14px;
        color: #ddd; /* ← 少し薄い白 */
      }

      /* 上段 */
      .top-section {

        justify-content: space-between;
        gap: 30px;
        margin-bottom: 30px;
        padding: 15px;
      }

      /* 検索エリア */
      .search-area {
        background: #f7faff;
        border-radius: 12px;
        padding: 20px;
        flex: 1;
        margin-bottom: 10px;
      }

      .search-title {
        font-weight: bold;
        margin-bottom: 15px;
        color: #1f3a5f;
      }

      .search-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
      }

      .search-grid input,
      .search-grid select {
        height: 38px;
        padding: 0 10px;
        border-radius: 6px;
        border: 1px solid #bfc7d1;
      }

      /* テーブル */
      .table-area {
        margin-top: 20px;
      }

      table {
        width: 100%;
        border-collapse: collapse;
      }

      th {
        background: #e9eff7;
        padding: 10px;
        font-size: 14px;
      }

      td {
        border-bottom: 1px solid #ddd;
        padding: 10px;
        font-size: 14px;
      }

      /* フッターボタン */
      .footer-buttons {
        position: absolute;
        bottom: 25px;
        right: 40px;
        display: flex;
        gap: 15px;
      }

      button {
        height: 40px;
        padding: 0 25px;
        border-radius: 20px;
        border: none;
        font-size: 14px;
        cursor: pointer;
      }

      .search-button-area {
        margin-top: 20px;
        text-align: right;
      }

      .btn-search {
        background: #1f3a5f;
        color: #fff;
        height: 38px;
        padding: 0 30px;
        border-radius: 20px;
        border: none;
        font-size: 14px;
        cursor: pointer;
      }

      .btn-search:hover {
        background: #162c49;
      }

      .book-link {
    text-decoration: none;
    color: inherit;
    display: block;
      }


</style>
</head>

<body>

<div class="header">
    <h1>📚 図書検索システム</h1>
</div>

<div class="top">


    <div class="top-section">
      <div class="search-area">
        <div class="search-title">検索条件</div>

        <form method="get" action="menu.php">
           <input type="hidden" name="page" value="search">


          <div class="search-grid">
            <?php $titleValue = $_GET['title'] ?? ''; ?>

            <input
              type="text"
              name="title"
              list="title_list"
              placeholder="題名"
              value="<?= htmlspecialchars($titleValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="title_list">
              <?php foreach ($titles as $title): ?>
              <option
                value="<?= htmlspecialchars($title['book_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>

            <?php $authorValue = $_GET['author'] ?? ''; ?>

            <input
              type="text"
              name="author"
              list="author_list"
              placeholder="著者名"
              value="<?= htmlspecialchars($authorValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="author_list">
              <?php foreach ($authors as $author): ?>
              <option
                value="<?= htmlspecialchars($author['author_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>

            <?php $genreValue = $_GET['genre'] ?? ''; ?>

            <input
              type="text"
              name="genre"
              list="genre_list"
              placeholder="ジャンル"
              value="<?= htmlspecialchars($genreValue, ENT_QUOTES, 'UTF-8') ?>"
            />

            <datalist id="genre_list">
              <?php foreach ($genres as $genre): ?>
              <option
                value="<?= htmlspecialchars($genre['genre_name'], ENT_QUOTES, 'UTF-8') ?>"
              >
                <?php endforeach; ?>
              </option>
            </datalist>
          </div>

          <!-- 🔍 検索ボタン -->
          <div class="search-button-area">
            <button type="submit" class="btn-search">検索</button>
          </div>
        </form>
    </div>

    <?php if (!$has_books): ?>
        <!-- 本が1冊もない場合 -->
        <div class="no-book">
            本が見つかりませんでした
        </div>
    <?php else: ?>
        <!-- 本がある場合 -->
         <h2 class="search-results">検索結果</h2>
        <div class="book-list">
            <?php foreach ($books as $book): ?>
            <a href="book_details.php?isbn=<?= urlencode($book['isbn']) ?>" class="book-link">
            <div class="book-card">

                <!-- 右：画像 -->
                <img src="<?= htmlspecialchars($book['photograph'], ENT_QUOTES, 'UTF-8') ?>" alt="表紙">


               <!-- 左：テキスト -->
                <div class="book-text">
                    <div class="book-title">
                        <?= htmlspecialchars($book['book_name'], ENT_QUOTES, 'UTF-8') ?>
                    </div>

                    <div class="book-info">
                        <div class="info-row">
                            <span>ジャンル：<?= htmlspecialchars($book['genre_name'], ENT_QUOTES, 'UTF-8') ?></span>
                            <span>予約数：<?= $book['reservation_count'] ?> 人</span>
                        </div>
                        <div class="info-row">
                            <span>著者：<?= htmlspecialchars($book['author_name'] ?? '不明', ENT_QUOTES, 'UTF-8') ?></span>
                            <span>所蔵数：<?= $book['total_count'] ?> 冊</span>
                        </div>
                    </div>


                </div>

                
            </div>
            </a>

            <?php endforeach; ?>
        </div>
    <?php endif; ?>


</div>
</body>
</html>
