<?php
session_start();
ini_set( 'display_errors', 1 );

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01');


$error_message = ''; // エラーメッセージ格納変数
$user_id = ''; // ログインIDの入力値を保持

// フォームが送信された場合
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id']; // 入力されたログインID
    $password = $_POST['password']; // 入力されたパスワード

    // バリデーション: 必須入力の確認
    if (empty($user_id) || empty($password)) {
        $error_message = 'ログインIDとパスワードは必須です。';
    } else {
        try {
            // データベース接続
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);


            // ユーザ情報を検索
            $sql = 'SELECT * FROM users WHERE user_id = :user_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_STR);//ログインIDをstr型でバインド
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // 認証処理
            if ($user && password_verify($password, $user['user_password'])) { // パスワードが一致した場合
                // 認証成功: セッションにユーザ情報を保存
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['user_name'] = $user['user_name'];

                // ログイン成功後、トップページにリダイレクト
                header("Location: menu.php");

                exit();
            } else {
                // 認証失敗
                $error_message = 'ログインIDまたはパスワードが正しくありません。';
                $password = ''; // パスワード入力欄をクリア
            }
        } catch (PDOException $e) {
             $error_message = 'DB接続エラーが発生しました。';
}
    }
}
?>

<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>学生用ログイン</title>

<style>
body {
    font-family: "Yu Gothic", "Hiragino Kaku Gothic ProN", sans-serif;
    background: #eef2f6;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

/* 全体枠 */
.login-container {
    width: 420px;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    padding: 40px 35px;
}

/* タイトル */
.login-title {
    text-align: center;
    font-size: 24px;
    color: #1f3a5f;
    margin-bottom: 10px;
}

.login-subtitle {
    text-align: center;
    font-size: 14px;
    color: #666;
    margin-bottom: 30px;
}

/* ラベル */
label {
    display: block;
    font-size: 15px;
    margin-bottom: 5px;
    color: #333;
}

/* 入力欄 */
input[type="text"],
input[type="password"] {
    width: 100%;
    height: 42px;
    font-size: 15px;
    padding: 0 10px;
    border: 1px solid #bfc7d1;
    border-radius: 4px;
    margin-bottom: 22px;
}

input:focus {
    outline: none;
    border-color: #1f3a5f;
}

/* エラー表示 */
.error {
    background: #fbeaea;
    color: #b00020;
    padding: 10px;
    font-size: 14px;
    border-radius: 4px;
    margin-bottom: 20px;
}

/* ボタン */
.buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
}

.btn {
    width: 48%;
    height: 42px;
    font-size: 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

/* 戻る */
.btn-back {
    background: #d1d5db;
    color: #333;
}

.btn-back:hover {
    background: #bfc5cc;
}

/* ログイン */
.btn-submit {
    background: #1f3a5f;
    color: #ffffff;
}

.btn-submit:hover {
    background: #162c49;
}

/* フッター */
.footer {
    text-align: center;
    font-size: 12px;
    color: #666;
    margin-top: 25px;
}
</style>
</head>

<body>

<div class="login-container">
    <div class="login-title">ログイン</div>
    <div class="login-subtitle">user Login</div>

    <form method="post">
        <label>学籍番号</label>
        <input type="text" name="user_id">

        <label>パスワード</label>
        <input type="password" name="password">

        <?php if (!empty($error_message)): ?>
            <div class="error">
                <?= htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <div class="buttons">
            <button type="button" class="btn btn-back" onclick="history.back()">戻る</button>
            <button type="submit" class="btn btn-submit">ログイン</button>
        </div>
    </form>

</div>

</body>
</html>
