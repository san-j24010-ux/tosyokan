<?php
session_start();
$page = $_GET['page'] ?? 'home';



?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>図書検索</title>

<style>
body {
    margin: 0;
    font-family: "Meiryo", sans-serif;
    background: #f3f3f3;
}

/* 全体を画面いっぱいに */
.wrapper {
    display: flex;
    width: 100%;
    min-height: 100vh;   /* 高さも画面いっぱい */
}

/* 左メニュー */
.sidebar {
    width: 240px;
    background: #ffffff;
    padding: 20px;
    box-sizing: border-box;
    border-right: 1px solid #ddd;
}

.sidebar a {
    display: block;
    padding: 10px;
    color: #000;
    text-decoration: none;
    border-radius: 4px;
}

.sidebar a:hover {
    background: #f0f0f0;
}

/* 右メイン */
.main {
    flex: 1;
    background: #fff;
    box-sizing: border-box;
}
</style>
</head>

<body>

<div class="wrapper">

    <!-- 左側：メニュー -->
    <div class="sidebar">
        <h3>ジャンル</h3>
        <a href="menu.php?page=home">ホーム</a>
        <a href="menu.php?page=battle">バトル</a>
        <a href="menu.php?page=love">恋愛</a>
        <a href="menu.php?page=sports">スポーツ</a>
        <a href="menu.php?page=literature">文学</a>
        <a href="menu.php?page=it">IT</a>
        <a href="menu.php?page=comic">コミック</a>
        <a href="menu.php?page=history">歴史</a>
        <a href="menu.php?page=picture book">童謡・絵本</a>
    </div>

    <!-- 右側：メイン表示 -->
    <div class="main">
        <?php
        switch ($page) {
            case 'battle':
                $_SESSION['genre_id'] = 1;
                include 'pages/genre.php';
                break;
            case 'love':
                $_SESSION['genre_id'] = 2;
                include 'pages/genre.php';
                break;
            case 'sports':
                $_SESSION['genre_id'] = 3;
                include 'pages/genre.php';
                break;
            case 'literature':
                $_SESSION['genre_id'] = 4;
                include 'pages/genre.php';
                break;
            case 'it':
                $_SESSION['genre_id'] = 5;
                include 'pages/genre.php';
                break;
            case 'comic':
                $_SESSION['genre_id'] = 6;
                include 'pages/genre.php';
                break;
            case 'history':
                $_SESSION['genre_id'] = 7;
                include 'pages/genre.php';
                break;
            case 'picture book':
                $_SESSION['genre_id'] = 8;
                include 'pages/genre.php';
                break;
            case 'search':
                include 'pages/search.php';
                break;
            case 'detail':
                include 'pages/book_details.php';
                break;
            default:
                include 'pages/home.php';
        }
        ?>
    </div>

</div>

</body>
</html>
