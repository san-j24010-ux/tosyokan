<?php
session_start();
ini_set('display_errors', 1);

// ログインチェック
if (!isset($_SESSION['user_id'])) {
    die('ログインが必要です。');
}

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01');     

$user_id = $_SESSION['user_id'];

try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8";
    $dbh = new PDO($dsn, DB_USER, DB_PASS);
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("接続失敗: " . $e->getMessage());
}

// ===== いいね解除処理 =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_like'])) {
    $book_id = $_POST['book_id'];
    $stmt = $dbh->prepare("DELETE FROM book_like WHERE user_id = ? AND book_id = ?");
    $stmt->execute([$user_id, $book_id]);
    // リロードして一覧を更新
    header("Location: book_like_history.php");
    exit;
}

// ===== いいねした本の一覧取得 =====
// 注意：book_likeテーブルに「created_at」などの日時カラムがある想定です。
// もしカラム名が違う、あるいは無い場合は適宜修正するか、日時の表示を削除してください。
$sql = "
    SELECT 
        b.book_id, 
        b.book_name, 
        b.isbn, 
        b.photograph, 
        a.author_name,
        g.genre_name
        /* , bl.created_at AS liked_at */ -- 日時カラムがある場合はここを有効にしてください
    FROM book_like bl
    JOIN book b ON bl.book_id = b.book_id
    LEFT JOIN author a ON b.author_id = a.author_id
    LEFT JOIN genre g ON b.genre_id = g.genre_id
    WHERE bl.user_id = ?
    ORDER BY b.book_id DESC
";
$stmt = $dbh->prepare($sql);
$stmt->execute([$user_id]);
$liked_books = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>いいねした本の一覧</title>
    <style>
        /* home.php / book_details.php のスタイルを継承 */
        body { font-family: "Segoe UI", "Meiryo", sans-serif; background: #f5f7fb; margin: 0; padding-bottom: 50px; }
        .header { background: #000; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 22px; margin: 0; }
        
        .main { padding: 30px; }
        .page-title { font-size: 20px; font-weight: bold; color: #1f3a5f; margin-bottom: 25px; border-bottom: 2px solid #1f3a5f; padding-bottom: 10px; }

        /* カード型レイアウト (home.php準拠) */
        .book-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }
        .book-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            display: flex;
            gap: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .book-card img {
            width: 100px;
            height: 140px;
            object-fit: contain;
            background: #eee;
            border-radius: 4px;
        }
        .book-info { flex: 1; font-size: 14px; }
        .book-info h3 { margin: 0 0 10px 0; font-size: 16px; }
        
        /* 題名リンク */
        .book-info h3 a {
            color: #1f3a5f;
            text-decoration: none;
            font-weight: bold;
        }
        .book-info h3 a:hover { text-decoration: underline; }

        .book-info p { margin: 5px 0; color: #555; }
        .liked-date { font-size: 12px; color: #888; margin-top: 10px; }

        /* 解除ボタン */
        .btn-remove {
            background: #ff5c8a;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 15px;
            cursor: pointer;
            font-size: 12px;
            margin-top: 10px;
        }
        .btn-remove:hover { background: #e04b76; }

        .btn-back {
            background: #1f3a5f;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .no-data { text-align: center; padding: 50px; color: #888; font-size: 18px; }
    </style>
</head>
<body>

<div class="header">
    <h1>❤️ いいねした本の一覧</h1>
    <div style="font-size: 14px;">ログイン中：<?= htmlspecialchars($_SESSION['user_name'] ?? 'ユーザー') ?></div>
</div>

<div class="main">
    <a href="menu.php" class="btn-back">← メニューへ戻る</a>
    
    <div class="page-title"></div>

    <?php if (empty($liked_books)): ?>
        <div class="no-data">「いいね」した本はまだありません。</div>
    <?php else: ?>
        <div class="book-grid">
            <?php foreach ($liked_books as $b): ?>
                <div class="book-card">
                    <?php
                    $photo = $b['photograph'];
                    $imgSrc = (preg_match('/^https?:\/\//', $photo)) ? $photo : 'jpg/' . basename($photo);
                    ?>
                    <img src="<?= htmlspecialchars($imgSrc) ?>" alt="表紙">

                    <div class="book-info">
                        <h3>
                            <a href="book_details.php?isbn=<?= urlencode($b['isbn']) ?>">
                                <?= htmlspecialchars($b['book_name']) ?>
                            </a>
                        </h3>
                        <p>著者：<?= htmlspecialchars($b['author_name'] ?? '不明') ?></p>
                        <p>ジャンル：<?= htmlspecialchars($b['genre_name'] ?? '未設定') ?></p>
                        
                        <!-- 日時表示（カラムがある場合のみ表示されます） -->
                        <?php if (isset($b['liked_at'])): ?>
                            <div class="liked-date">いいねした日時：<?= htmlspecialchars($b['liked_at']) ?></div>
                        <?php endif; ?>

                        <form method="post" onsubmit="return confirm('いいねを解除しますか？');">
                            <input type="hidden" name="book_id" value="<?= $b['book_id'] ?>">
                            <button type="submit" name="remove_like" class="btn-remove">💔 いいねを解除</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>