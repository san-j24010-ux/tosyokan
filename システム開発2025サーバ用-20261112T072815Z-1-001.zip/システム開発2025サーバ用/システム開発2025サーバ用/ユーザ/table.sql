CREATE TABLE school (
    school_id   VARCHAR(20) PRIMARY KEY,
    school_name VARCHAR(20) NOT NULL
);
CREATE TABLE users (
    user_id        VARCHAR(20) PRIMARY KEY,
    user_name      VARCHAR(20) NOT NULL,
    school_id      VARCHAR(20) NOT NULL,
    user_grade     INTEGER,
    user_password  VARCHAR(1000) NOT NULL,
    user_authority INTEGER,
    CONSTRAINT fk_user_school
        FOREIGN KEY (school_id)
        REFERENCES school (school_id)
);
CREATE TABLE genre (
    genre_id   INTEGER PRIMARY KEY,
    genre_name VARCHAR(20) NOT NULL
);
CREATE TABLE status (
    status_id   INTEGER PRIMARY KEY,
    status_name VARCHAR(20) NOT NULL
);
CREATE TABLE author (
    author_id VARCHAR(20) PRIMARY KEY,
    author_name VARCHAR(20) NOT NULL
);

CREATE TABLE book (
    book_id     INTEGER PRIMARY KEY,
    isbn        VARCHAR(40),
    school_id   VARCHAR(20) NOT NULL,
    book_name   VARCHAR(40) NOT NULL,
    author_id VARCHAR(20),
    genre_id    INTEGER NOT NULL,
    status_id   INTEGER NOT NULL,
    photograph VARCHAR(100),
    synopsis VARCHAR(200),
    CONSTRAINT fk_book_school
        FOREIGN KEY (school_id)
        REFERENCES school (school_id),
    CONSTRAINT fk_book_genre
        FOREIGN KEY (genre_id)
        REFERENCES genre (genre_id),
    CONSTRAINT fk_book_status
        FOREIGN KEY (status_id)
        REFERENCES status (status_id),
    CONSTRAINT fk_book_author
        FOREIGN KEY (author_id)
        REFERENCES author (author_id)
);
CREATE TABLE lend (
    user_id          VARCHAR(20),
    book_id          INTEGER,
    status_id        INTEGER NOT NULL,
    checkout_date    DATE,
    return_date      DATE,
    reservation_date DATE,
    PRIMARY KEY (user_id, book_id, reservation_date),
    CONSTRAINT fk_lend_user
        FOREIGN KEY (user_id)
        REFERENCES users (user_id),
    CONSTRAINT fk_lend_book
        FOREIGN KEY (book_id)
        REFERENCES book (book_id),
    CONSTRAINT fk_lend_status
        FOREIGN KEY (status_id)
        REFERENCES status (status_id)
);
