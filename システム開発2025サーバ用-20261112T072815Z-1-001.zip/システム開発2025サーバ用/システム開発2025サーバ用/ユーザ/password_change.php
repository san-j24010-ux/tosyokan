<?php
session_start();

ini_set( 'display_errors', 1 );

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01'); 

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $current = $_POST["current_password"];
    $new     = $_POST["new_password"];
    $confirm = $_POST["confirm_password"];

    if ($new !== $confirm) {
        $error = "新しいパスワードが一致しません";
    } else {

        // データベース接続
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

        // 現在のパスワード取得
        $sql = "SELECT user_password FROM users WHERE user_id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$_SESSION["user_id"]]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($current !== $data["user_password"]) {
            $error = "現在のパスワードが違います";
        } else {
            // パスワード更新
            $sql = "UPDATE users SET user_password = ? WHERE user_id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$new, $_SESSION["user_id"]]);

            $success = "パスワードを変更しました";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>パスワード変更</title>
    <style>
        body {
            font-family: "Meiryo", "Hiragino Kaku Gothic ProN", sans-serif;
            background-color: #fff;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            width: 600px;
            height: 400px;
            border: 2px solid #4472c4;
            border-radius: 40px;
            padding: 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        h1 {
            font-size: 20px;
            font-weight: bold;
            margin-top: 0;
            margin-bottom: 40px;
            text-align: center;
            width: 100%;
        }
        .form-area {
            width: 100%;
            display: flex;
            flex-direction: column;
            gap: 20px;
            padding-left: 50px;
        }
        .input-group {
            display: flex;
            align-items: center;
        }
        .input-group label {
            width: 220px;
            font-weight: bold;
            font-size: 16px;
        }
        .input-group input {
            padding: 5px;
            font-size: 16px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .button-area {
            margin-top: 50px;
            display: flex;
            gap: 60px;
            justify-content: center;
            width: 100%;
        }
        .text-btn {
            background: none;
            border: none;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            padding: 5px 10px;
        }
        .text-btn:hover {
            text-decoration: underline;
            background-color: #f0f8ff;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <h1>パスワード変更</h1>
<?php if (!empty($error)): ?>
    <p style="color: red; font-weight: bold;">
        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<?php if (!empty($success)): ?>
    <p style="color: green; font-weight: bold;">
        <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

    <form action="" method="post" style="width: 100%;">
        <div class="form-area">
            <div class="input-group">
                <label>現在のパスワード：</label>
                <input type="password" name="current_password">
            </div>
            <div class="input-group">
                <label>新しいパスワード：</label>
                <input type="password" name="new_password">
            </div>
            <div class="input-group">
                <label>新しいパスワード確認入力：</label>
                <input type="password" name="confirm_password">
            </div>
        </div>

        <div class="button-area">
            <button type="submit" class="text-btn">パスワード変更</button>
            
            <!-- キャンセルでindex.phpに戻る -->
            <a href="menu.php" style="text-decoration: none; color: black;">
                <button type="button" class="text-btn">キャンセル</button>
            </a>
        </div>
    </form>
</div>

</body>
</html>