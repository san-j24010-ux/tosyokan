<?php
session_start();
ini_set('display_errors', 1);

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01');    

$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8";
$dbh = new PDO($dsn, DB_USER, DB_PASS);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$student_id = $_SESSION['student_id'] ?? '';
$book_id = $_POST['book_id'] ?? '';

if (!$student_id || !$book_id) {
    header("Location: home.php");
    exit;
}

// 既にいいねしているか確認 - student_id を user_id に変更
$sql = "SELECT COUNT(*) FROM book_like WHERE book_id=? AND user_id=?";
$stmt = $dbh->prepare($sql);
$stmt->execute([$book_id, $student_id]);
$exists = $stmt->fetchColumn();

if ($exists) {
    // 取り消し - student_id を user_id に変更
    $del = $dbh->prepare("DELETE FROM book_like WHERE book_id=? AND user_id=?");
    $del->execute([$book_id, $student_id]);
} else {
    // 新規いいね - student_id を user_id に変更
    $ins = $dbh->prepare("INSERT INTO book_like(book_id, user_id) VALUES (?, ?)");
    $ins->execute([$book_id, $student_id]);
}

header("Location: book_details.php?book_id=" . $book_id);
exit;