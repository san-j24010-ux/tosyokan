<?php
session_start();
// ログインユーザーID（セッションがない場合はテスト用ID: j23008を設定）
$login_user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'j23008';

/* ===== DB接続 ===== */
$dsn = "mysql:dbname=Library;host=localhost;charset=utf8";
$user = "user01";
$password = "user01";

try {
    $pdo = new PDO($dsn, $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    exit("DB接続失敗：" . $e->getMessage());
}

/* ===== 予約キャンセル処理 (ステータス2のみ削除) ===== */
if (isset($_POST['cancel_reservation'])) {
    $book_id = $_POST['book_id'];
    $sql = "DELETE FROM lend WHERE user_id = :user_id AND book_id = :book_id AND status_id = 2";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':user_id' => $login_user_id, ':book_id' => $book_id]);
    
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

/* ===== 利用履歴取得 ===== */
$sql = "
SELECT 
    b.book_id, 
    b.book_name, 
    b.photograph, 
    sc.school_name,
    l.status_id, 
    s.status_name, 
    l.checkout_date,   
    l.reservation_date,
    l.return_date
FROM lend l
INNER JOIN book b 
    ON l.book_id = b.book_id
INNER JOIN status s 
    ON l.status_id = s.status_id
INNER JOIN school sc
    ON b.school_id = sc.school_id
WHERE l.user_id = :user_id
ORDER BY COALESCE(l.checkout_date, l.reservation_date) DESC;

";

$stmt = $pdo->prepare($sql);
$stmt->execute([':user_id' => $login_user_id]);
$history = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>マイ履歴・状況</title>
    <style>
        body { background: #f4f7f6; font-family: sans-serif; padding: 20px; }
        .back-button { margin-bottom: 20px; padding: 8px 16px; background: #fff; border: 1px solid #ccc; border-radius: 4px; cursor: pointer; }
        .book-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 20px; }
        .book-card { background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.08); padding: 15px; display: flex; flex-direction: column; }
        .image-container { width: 100%; height: 220px; background-color: #f9f9f9; display: flex; align-items: center; justify-content: center; border-radius: 6px; margin-bottom: 12px; }
        .book-image { max-width: 100%; max-height: 100%; object-fit: contain; }
        .status-badge { font-size: 11px; padding: 2px 8px; border-radius: 4px; color: #fff; align-self: flex-start; margin-bottom: 8px; font-weight: bold; }
        
        /* ステータス別の色設定 */
        .st-1 { background: #2ecc71; } /* 貸出中 */
        .st-2 { background: #f1c40f; color: #000; } /* 予約中 */
        .st-3 { background: #3498db; } /* 運搬中 */
        .st-6 { background: #9b59b6; } /* 到着 (紫) */
        .st-5 { background: #00ffb7; } /* 返却  */

        .book-title { font-size: 15px; font-weight: bold; margin-bottom: 10px; height: 2.8em; overflow: hidden; line-height: 1.4; }
        .date-section { font-size: 11px; color: #666; border-top: 1px solid #eee; padding-top: 8px; line-height: 1.7; }
        .date-label { color: #999; width: 60px; display: inline-block; }
        .alert-box { font-size: 12px; font-weight: bold; margin-top: 10px; padding: 10px; border-radius: 4px; text-align: center; }
        .cancel-btn { background: #e74c3c; color: white; border: none; padding: 10px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: bold; width: 100%; margin-top: 10px; }
    </style>
</head>
<body>

<button class="back-button" onclick="location.href='menu.php'">← メニューに戻る</button>
<h2>📚 利用状況・履歴</h2>

<div class="book-list">
    <?php foreach ($history as $item): ?>
        <div class="book-card">
            <span class="status-badge st-<?= $item['status_id'] ?>">
                <?= htmlspecialchars($item['status_name'], ENT_QUOTES, 'UTF-8') ?>
            </span>

            <div class="image-container">
                <?php $src = !empty($item['photograph']) ? $item['photograph'] : 'images/noimage.png'; ?>
                <img src="<?= htmlspecialchars($src, ENT_QUOTES, 'UTF-8') ?>" class="book-image">
            </div>

            <div class="book-title"><?= htmlspecialchars($item['book_name'], ENT_QUOTES, 'UTF-8') ?></div>
            
            <div class="date-section">
                <div><span class="date-label">所在学校:</span> <?= htmlspecialchars($item['school_name'] ?? '---', ENT_QUOTES, 'UTF-8') ?></div>
                <div><span class="date-label">予約日:</span> <?= htmlspecialchars($item['reservation_date'] ?? '---', ENT_QUOTES, 'UTF-8') ?></div>
                <div><span class="date-label">貸出日:</span> <?= htmlspecialchars($item['checkout_date'] ?? '---', ENT_QUOTES, 'UTF-8') ?></div>
                <div><span class="date-label">返却予定:</span> <?= htmlspecialchars($item['return_date'] ?? '---', ENT_QUOTES, 'UTF-8') ?></div>
            </div>

            <?php if ($item['status_id'] == 1 && !empty($item['return_date'])): ?>
                <?php
                    $today = new DateTime(date('Y-m-d'));
                    $return_day = new DateTime($item['return_date']);
                    $diff = $today->diff($return_day);
                    $days = (int)$diff->format('%r%a');
                ?>
                <div class="alert-box" style="
                    <?php if ($days <= 2): ?> background: #ffdada; color: #d63031; 
                    <?php else: ?> background: #f0f0f0; color: #636e72; 
                    <?php endif; ?>">
                    
                    <?php if ($days < 0): ?> ⚠️ 期限を過ぎています！
                    <?php elseif ($days === 0): ?> 📅 本日が返却日当日です。
                    <?php elseif ($days <= 2): ?> ⏳ 返却日まであとわずか<?= $days ?>日です。
                    <?php else: ?> 📖 返却まであと<?= $days ?>日です。
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if ($item['status_id'] == 6): ?>
                <div class="alert-box" style="background: #ebfbee; color: #2f9e44; border: 1px solid #b2f2bb;">
                    ✅ 本が到着しました！<br>受け取りをお願いします。
                </div>
            <?php endif; ?>

            <?php if ($item['status_id'] == 2): ?>
                <form method="POST">
                    <input type="hidden" name="book_id" value="<?= $item['book_id'] ?>">
                    <button type="submit" name="cancel_reservation" class="cancel-btn" onclick="return confirm('予約をキャンセルしますか？')">
                        予約キャンセル
                    </button>
                </form>
            <?php endif; ?>

        </div>
    <?php endforeach; ?>
</div>

</body>
</html>