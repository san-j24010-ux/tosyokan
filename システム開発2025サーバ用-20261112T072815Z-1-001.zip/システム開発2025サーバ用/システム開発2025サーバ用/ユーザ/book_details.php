<?php
session_start();
ini_set('display_errors', 1);

if (!isset($_GET['isbn'])) {
    die('ISBNが指定されていません');
}

// ===== DB接続情報 =====
define('DB_HOST', 'localhost');
define('DB_NAME', 'Library');
define('DB_USER', 'user01');
define('DB_PASS', 'user01'); 

$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8";
$dbh = new PDO($dsn, DB_USER, DB_PASS);
$dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$isbn = $_GET['isbn'] ?? '';
$user_id = $_SESSION['user_id'] ?? '';
$user_name = $_SESSION['user_name'] ?? 'ゲスト';

// ログインユーザーの学校IDを取得
$my_school_id = '';
if ($user_id) {
    $stmt = $dbh->prepare("SELECT school_id FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $my_school_id = $stmt->fetchColumn();
}

// ===== 予約・キャンセル処理 =====
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 予約実行
    if (isset($_POST['reserve_action'])) {
        if (!$user_id) {
            $message = "予約するにはログインが必要です。";
        } else {
            // 既に何か1冊予約しているかチェック
            $checkRes = $dbh->prepare("SELECT COUNT(*) FROM lend WHERE user_id = ? AND status_id != 5");
            $checkRes->execute([$user_id]);
            if ($checkRes->fetchColumn() > 0) {
                $message = "エラー：既に他の本を予約中または貸出中のため、新しく予約することはできません。";
            } else {
                // 優先順位ロジックでbook_idを選定
                // 2. 優先順位に基づいて予約する物理本(book_id)を1つ選定
                // 優先1: 自校 & 予約なし
                // 優先2: 他校 & 予約なし
                // 優先3: 自校 & 予約あり(重複予約)
                // 優先4: 他校 & 予約あり
                // LIMIT 1　➯　SELECT文で取得する検索結果の行数を「最初の1件のみ」に制限する命令
$pickSql = "
    SELECT b.book_id
    FROM book b
    LEFT JOIN (
        SELECT 
            book_id,
            ban,
            COUNT(*) AS c,
            checkout_date,
            return_date
        FROM lend
        WHERE status_id != 5
        GROUP BY book_id, ban, checkout_date, return_date
    ) l  
      ON b.book_id = l.book_id
    WHERE b.isbn = ?
      AND (
          l.ban IS NULL
          OR l.ban = ''
          OR (
              l.ban IS NOT NULL
              AND (
                  l.checkout_date >= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                  OR l.return_date < CURDATE()
              )
          )
      )
    ORDER BY 
        CASE 
            WHEN b.school_id = ? AND IFNULL(l.c, 0) = 0 THEN 1
            WHEN b.school_id != ? AND IFNULL(l.c, 0) = 0 THEN 2
            WHEN b.school_id = ? THEN 3
            ELSE 4 
        END,
        IFNULL(l.c, 0) ASC,
        RAND()
    LIMIT 1
";

                $stmt = $dbh->prepare($pickSql);
                $stmt->execute([$isbn, $my_school_id, $my_school_id, $my_school_id]);
                $target_book_id = $stmt->fetchColumn();

                if ($target_book_id) {
                    $ins = $dbh->prepare("INSERT INTO lend (user_id, book_id, status_id, reservation_date) VALUES (?, ?, 2, CURRENT_DATE)");
                    $ins->execute([$user_id, $target_book_id]);
                    $message = "予約が完了しました！";
                }else{
                    $message = "この本は貸出禁止されているため予約できません！";
                }
            }
        }
    }
    // 予約キャンセル
    elseif (isset($_POST['cancel_reserve_action'])) {
        // このISBNに紐づく、このユーザーの予約を削除
        $delSql = "
            DELETE l FROM lend l
            JOIN book b ON l.book_id = b.book_id
            WHERE l.user_id = ? AND b.isbn = ? AND l.status_id = 2
        ";
        $stmt = $dbh->prepare($delSql);
        $stmt->execute([$user_id, $isbn]);
        $message = "予約を取り消しました。";
    }
}

// ===== いいね処理 =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['like_toggle'])) {
    $book_id_for_like = $_POST['book_id'];
    $check = $dbh->prepare("SELECT COUNT(*) FROM book_like WHERE book_id=? AND user_id=?");
    $check->execute([$book_id_for_like, $user_id]);
    if ($check->fetchColumn() > 0) {
        $dbh->prepare("DELETE FROM book_like WHERE book_id=? AND user_id=?")->execute([$book_id_for_like, $user_id]);
    } else {
        $dbh->prepare("INSERT INTO book_like (book_id, user_id) VALUES (?, ?)")->execute([$book_id_for_like, $user_id]);
    }
    header("Location: book_details.php?isbn=" . urlencode($isbn));
    exit;
}

// ===== 書籍情報取得 =====
$sql = "
    SELECT b.book_id, b.book_name AS title, b.photograph, b.synopsis, a.author_name, g.genre_name AS category_name,
    (SELECT COUNT(*) FROM book_like bl WHERE bl.book_id = b.book_id) AS like_count
    FROM book b
    LEFT JOIN author a ON b.author_id=a.author_id
    LEFT JOIN genre g ON b.genre_id=g.genre_id
    WHERE b.isbn=? LIMIT 1
";
$stmt = $dbh->prepare($sql);
$stmt->execute([$isbn]);
$book = $stmt->fetch(PDO::FETCH_ASSOC);

// いいね済み・この本の予約済み確認
$liked = false;
$has_reserved_this = false;
if ($user_id && $book) {
    // いいね
    $l_stmt = $dbh->prepare("SELECT COUNT(*) FROM book_like WHERE book_id=? AND user_id=?");
    $l_stmt->execute([$book['book_id'], $user_id]);
    $liked = $l_stmt->fetchColumn() > 0;

    // この本の予約
    $r_stmt = $dbh->prepare("SELECT COUNT(*) FROM lend l JOIN book b ON l.book_id = b.book_id WHERE l.user_id=? AND b.isbn=? AND l.status_id=2");
    $r_stmt->execute([$user_id, $isbn]);
    $has_reserved_this = $r_stmt->fetchColumn() > 0;
}

// ===== 予約状況メッセージ判定 =====
$status_stmt = $dbh->prepare("SELECT b.school_id, (SELECT COUNT(*) FROM lend l WHERE l.book_id = b.book_id AND l.status_id = 2) as res_cnt FROM book b WHERE b.isbn = ?");
$status_stmt->execute([$isbn]);
$all_copies = $status_stmt->fetchAll(PDO::FETCH_ASSOC);

$total_res = 0; $has_free_in_my_school = false; $has_free_elsewhere = false; $any_reserved = false;
foreach ($all_copies as $copy) {
    $total_res += $copy['res_cnt'];
    if ($copy['res_cnt'] > 0) $any_reserved = true;
    if ($copy['res_cnt'] == 0) {
        if ($copy['school_id'] === $my_school_id) $has_free_in_my_school = true;
        else $has_free_elsewhere = true;
    }
}
$status_text = "📖 現在予約を受け付けています"; $status_color = "#333";
if (!$any_reserved) { $status_text = "✨ どの本も予約されていない（すぐに予約が回ってきます）"; $status_color = "green"; }
elseif (!$has_free_in_my_school && $has_free_elsewhere) { $status_text = "🚚 自分の学校の本は予約されていますが、他の学校なら予約に空きがあります"; $status_color = "orange"; }
elseif ($total_res >= count($all_copies)) { $status_text = "⚠ すべての本が予約されているため、待ち期間が長くなる恐れがあります"; $status_color = "red"; }

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>本の詳細</title>
    <style>
        body { font-family: "Segoe UI", "Meiryo", sans-serif; background: #f5f7fb; margin: 0; }
        .header { background: #000; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .user-info { font-size: 14px; color: #ddd; }
        .main { padding: 25px; max-width: 900px; margin: auto; }
        .top { display: flex; gap: 40px; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .top img { width: 220px; height: auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }
        .info { flex: 1; }
        .info p { margin: 8px 0; font-size: 16px; color: #444; }
        .status-msg { font-weight: bold; margin: 15px 0; padding: 10px; border-radius: 6px; background: #f9f9f9; border-left: 5px solid; }
        .synopsis { background: #eef3ff; padding: 20px; border-radius: 10px; margin-top: 25px; line-height: 1.6; }
        
        /* ボタンエリア */
        .action-area { display: flex; gap: 10px; align-items: center; margin-top: 15px; }
        .btn { padding: 10px 20px; border-radius: 25px; border: none; cursor: pointer; font-size: 14px; font-weight: bold; }
        .btn-reserve { background: #1f3a5f; color: white; min-width: 160px; }
        .btn-cancel { background: #dc3545; color: white; min-width: 160px; }
        .btn-like { background: #ff5c8a; color: white; }
        .btn-back { background: #888; color: white; padding: 10px 25px; border-radius: 25px; border: none; cursor: pointer; }
        .alert { background: #fff3cd; color: #856404; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #ffeeba; }
    </style>
</head>
<body>

<div class="header">
    <div>■ 本の詳細</div>
    <div class="user-info">ログイン中：👤<?= htmlspecialchars($user_name) ?>さん</div>
</div>

<div class="main">
    <?php if ($message): ?>
        <div class="alert"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <div class="top">
        <?php
        $photo = $book['photograph'];
        $imgSrc = (preg_match('/^https?:\/\//', $photo)) ? $photo : 'jpg/' . basename($photo);
        ?>
        <img src="<?= htmlspecialchars($imgSrc) ?>" alt="表紙">

        <div class="info">
            <!-- 題名と著者をこちらに配置 -->
            <p style="font-size: 1.2em; font-weight: bold; color: #000;">📘 題名：<?= htmlspecialchars($book['title']) ?></p>
            <p style="font-weight: bold;">✍ 著者：<?= htmlspecialchars($book['author_name']) ?></p>
            
            <p>❤️ いいねの数：<?= $book['like_count'] ?></p>
            <p>📚 総所蔵数：<?= count($all_copies) ?> 冊</p>
            <p>📂 ジャンル：<?= htmlspecialchars($book['category_name']) ?></p>
            
            <div class="status-msg" style="border-left-color: <?= $status_color ?>; color: <?= $status_color ?>;">
                <?= $status_text ?>
            </div>

            <div class="action-area">
                <?php if ($user_id): ?>
                    <!-- 予約・キャンセルボタン -->
                    <form method="post">
                        <?php if ($has_reserved_this): ?>
                            <button type="submit" name="cancel_reserve_action" class="btn btn-cancel">予約を取り消す</button>
                        <?php else: ?>
                            <button type="submit" name="reserve_action" class="btn btn-reserve">この本を予約する</button>
                        <?php endif; ?>
                    </form>

                    <!-- いいねボタンを右隣に配置 -->
                    <form method="post">
                        <input type="hidden" name="book_id" value="<?= $book['book_id'] ?>">
                        <button class="btn btn-like" name="like_toggle">
                            <?= $liked ? '💔 いいね解除' : '❤️ いいね' ?>
                        </button>
                    </form>
                <?php else: ?>
                    <p style="color: #888; font-size: 14px;">※ 予約・いいねにはログインが必要です。</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="synopsis">
        <b style="font-size: 18px; color: #1f3a5f;">あらすじ</b><br><br>
        <?= nl2br(htmlspecialchars($book['synopsis'])) ?>
    </div>

    <div style="margin-top: 30px; text-align: center;">
        <button class="btn-back" onclick="location.href='menu.php'">検索結果へ戻る</button>
    </div>
</div>

</body>
</html>