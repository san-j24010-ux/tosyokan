-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2026-02-05 10:51:46
-- サーバのバージョン： 10.4.32-MariaDB
-- PHP のバージョン: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `library`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `author`
--

CREATE TABLE `author` (
  `author_id` varchar(20) NOT NULL,
  `author_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `author`
--

INSERT INTO `author` (`author_id`, `author_name`) VALUES
('A001', '夏目漱石'),
('A002', '村上春樹'),
('A003', 'ユヴァル・ノア・ハラリ'),
('A004', 'ジャレド・ダイアモンド'),
('A005', '半藤一利'),
('A006', '磯田道史'),
('A007', '村上春樹'),
('A008', '片山恭一'),
('A009', '住野よる'),
('A010', '七月隆文'),
('A011', '江國香織'),
('A012', '有川浩'),
('A013', 'Dustin Boswell'),
('A014', 'David Thomas'),
('A015', 'Paul Graham'),
('A016', '山本陽平'),
('A017', '竹下隆史'),
('A018', 'Mike Gancarz'),
('A019', '夏目漱石'),
('A020', '太宰治'),
('A021', '宮沢賢治'),
('A022', '芥川龍之介'),
('A023', '小川洋子'),
('A024', '三浦しをん'),
('A025', '中川李枝子'),
('A026', 'エリック・カール'),
('A027', '新美南吉'),
('A028', '佐野洋子'),
('A029', '斎藤隆介'),
('A030', '松谷みよ子'),
('A031', '司馬遼太郎'),
('A032', '塩野七生'),
('AUT003', 'ながの'),
('AUT004', 'たける');

-- --------------------------------------------------------

--
-- テーブルの構造 `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `isbn` varchar(40) DEFAULT NULL,
  `school_id` varchar(20) NOT NULL,
  `book_name` varchar(40) NOT NULL,
  `author_id` varchar(20) DEFAULT NULL,
  `genre_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `photograph` varchar(100) DEFAULT NULL,
  `synopsis` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `book`
--

INSERT INTO `book` (`book_id`, `isbn`, `school_id`, `book_name`, `author_id`, `genre_id`, `status_id`, `photograph`, `synopsis`) VALUES
(1, '978-0000000001', 'S001', 'こころ', 'A001', 1, 4, 'https://m.media-amazon.com/images/I/51O80MSJZxL._SY445_SX342_PQ99_.jpg', '人間の心の葛藤を描いた名作'),
(2, '978-0000000002', 'S002', 'ノルウェイの森', 'A002', 2, 4, 'jpg/norwegian.jpg', '青春と喪失を描く物語'),
(3, '978-4309226712', 'S001', 'サピエンス全史', 'A003', 7, 4, 'https://m.media-amazon.com/images/I/81Rs5NLXipL._AC_UY327_FMwebp_QL65_.jpg', 'ホモ・サピエンスがどのようにして地球の支配者となったのかを解き明かす世界的ベストセラー。'),
(4, '978-4794218736', 'S001', '銃・病原菌・鉄', 'A004', 7, 4, 'https://m.media-amazon.com/images/I/514kHLUN+cL._SY445_SX342_PQ99_.jpg', 'なぜ西洋文明が世界を支配したのか。地理的条件や環境の違いから人類史を考察する。'),
(5, '978-4167483029', 'S001', '日本のいちばん長い日', 'A005', 7, 4, 'https://m.media-amazon.com/images/I/815YNMuP-0L._SY522_.jpg', '昭和20年8月15日の終戦に至るまでの24時間のドラマを克明に描いたノンフィクション。'),
(6, '978-4166603527', 'S001', '武士の家計簿', 'A006', 7, 4, 'https://www.shinchosha.co.jp/images_v2/book/cover/610005/610005_l.jpg', '金沢藩士の家計簿を分析し、幕末から明治を生き抜いた武士の暮らしをリアルに描く。'),
(7, '978-0000000002', 'S001', 'ノルウェイの森', 'A007', 2, 4, 'jpg/norwegian.jpg', '限りない喪失と再生を描く、村上春樹の代表的恋愛長編小説。'),
(8, '978-4094080261', 'S001', '世界の中心で、愛をさけぶ', 'A008', 2, 4, 'https://m.media-amazon.com/images/I/41H2VC1B5DL._SY445_SX342_PQ99_.jpg', '高校生の朔太郎とアキの切なくも美しい純愛を描いたベストセラー小説。'),
(9, '978-4575519124', 'S001', '君の膵臓をたべたい', 'A009', 2, 4, 'https://m.media-amazon.com/images/I/81EKy0A6SmL._SL1500_.jpg', 'クラスメイトの山内桜良が秘密の日記帳を綴っていることを知った「僕」の物語。'),
(10, '978-4796699144', 'S001', 'ぼくは明日、昨日のきみとデートする', 'A010', 2, 4, 'https://m.media-amazon.com/images/I/51MvIR9kVSL._SY445_SX342_PQ99_.jpg', '京都の美大に通う高寿は、電車で一目惚れした愛美に声をかけるが、彼女には秘密があった。'),
(11, '978-4041006509', 'S001', '冷静と情熱のあいだ', 'A011', 2, 4, 'https://m.media-amazon.com/images/I/71j07vTlXbL._SL1500_.jpg', '10年の時を経てフィレンツェで再会することを約束した恋人たちの物語。'),
(12, '978-4344419688', 'S001', '植物図鑑', 'A012', 2, 4, 'https://m.media-amazon.com/images/I/71ypavgMaAL._SY522_.jpg', '道端に倒れていた青年を拾ったことから始まる、美味しくて温かい同居生活と恋の物語。'),
(13, '978-4873115658', 'S001', 'リーダブルコード', 'A013', 5, 4, 'https://m.media-amazon.com/images/I/81+3DpjuMdL._SL1500_.jpg', 'より良いコードを書くためのシンプルで実践的なテクニックを解説した名著。'),
(14, '978-4274226298', 'S001', '達人プログラマー', 'A014', 5, 4, 'https://m.media-amazon.com/images/I/91oF79X2+rL._SL1500_.jpg', 'ソフトウェア開発のプロフェッショナルとして必要な心構えや技術を網羅したバイブル。'),
(15, '978-4274066016', 'S001', 'ハッカーと画家', 'A015', 5, 4, 'https://m.media-amazon.com/images/I/516WexUTDvL._SY445_SX342_PQ99_.jpg', 'Yコンビネータ創設者が語る、コンピュータ時代の創造性についての珠玉のエッセイ集。'),
(16, '978-4774143071', 'S001', 'Webを支える技術', 'A016', 5, 4, 'https://m.media-amazon.com/images/I/81S71R5s-jL._SL1500_.jpg', 'HTTP、URI、HTMLなど、Webの根幹をなす技術の歴史と設計思想を解説。'),
(17, '978-4797357523', 'S001', 'マスタリングTCP/IP 入門編', 'A017', 5, 4, 'https://m.media-amazon.com/images/I/71poCkUqeRL._SL1500_.jpg', 'ネットワーク技術の基礎となるTCP/IPプロトコルを体系的に学べるロングセラー。'),
(18, '978-4756136795', 'S001', 'UNIXという考え方', 'A018', 5, 4, 'https://m.media-amazon.com/images/I/21f9xhTIwUL.jpg', 'UNIXの設計哲学である「小さく、美しく」という思想を解説。OS設計の真髄に迫る。'),
(19, '978-4101010014', 'S001', 'こころ', 'A019', 4, 4, 'https://m.media-amazon.com/images/I/51O80MSJZxL._SY445_SX342_PQ99_.jpg', '親友を裏切って恋人を得た罪悪感に苦しむ「先生」の遺書を通して、人間のエゴイズムを描く。'),
(20, '978-4101006055', 'S001', '人間失格', 'A020', 4, 4, 'https://m.media-amazon.com/images/I/61szvCwMC0L._SL1200_.jpg', '「恥の多い生涯を送って来ました」。他者との関わりを恐れ、破滅へと向かう男の手記。'),
(21, '978-4101092052', 'S001', '銀河鉄道の夜', 'A021', 4, 4, 'https://m.media-amazon.com/images/I/71RBq9iBaRL._SY522_.jpg', 'ジョバンニとカムパネルラが銀河鉄道に乗って星々を旅する、美しくも哀しい童話的巨編。'),
(22, '978-4101025018', 'S001', '羅生門・鼻', 'A022', 4, 4, 'https://m.media-amazon.com/images/I/71I6xpSYM6L._SL1294_.jpg', '生きるための悪を肯定する人間のエゴイズムを鋭く描いた歴史小説の傑作。'),
(23, '978-4101215228', 'S001', '博士の愛した数式', 'A023', 4, 4, 'https://m.media-amazon.com/images/I/71Sw0F7-MAL._SL1500_.jpg', '80分しか記憶が持たない数学者と、家政婦とその息子の心の交流を描いた感動の物語。'),
(24, '978-4334768222', 'S001', '舟を編む', 'A024', 4, 4, 'https://m.media-amazon.com/images/I/81TyI38KZML._SL1500_.jpg', '辞書編集部を舞台に、新しい辞書「大渡海」の完成に情熱を注ぐ人々の物語。'),
(25, '978-4834000826', 'S001', 'ぐりとぐら', 'A025', 8, 4, 'https://m.media-amazon.com/images/I/615vysRQ0VL._SL1386_.jpg', '野ねずみのぐりとぐらが、森で大きな卵を見つけてカステラを作る人気絵本シリーズ。'),
(26, '978-4033280103', 'S001', 'はらぺこあおむし', 'A026', 8, 4, 'https://m.media-amazon.com/images/I/61BH-+i4pML._SL1000_.jpg', 'あおむしが色々なものを食べて成長し、美しい蝶になるまでを描いた仕掛け絵本。'),
(27, '978-4039611307', 'S001', 'ごんぎつね', 'A027', 8, 4, 'https://m.media-amazon.com/images/I/61Gv90G9K5L._SY522_.jpg', 'いたずら好きの小狐ごんと、兵十の悲しいすれ違いを描いた名作童話。'),
(28, '978-4061272748', 'S001', '100万回生きたねこ', 'A028', 8, 4, 'https://m.media-amazon.com/images/I/61dKXhTrRcL._SL1000_.jpg', '100万回死んで100万回生きた猫が、初めて自分以外の存在を愛することを知る物語。'),
(29, '978-4265909285', 'S001', 'もちもちの木', 'A029', 8, 4, 'https://m.media-amazon.com/images/I/71NbBupBrFL._SL1500_.jpg', '臆病な豆太が、病気の祖父のために勇気を振り絞って夜道を駆ける感動の物語。'),
(30, '978-4494001019', 'S002', 'いないいないばあ', 'A030', 8, 4, 'https://m.media-amazon.com/images/I/51Rpci3tbEL._SX342_SY445_PQ99_.jpg', '日本で一番売れている絵本。「いないいない、ばあ」の繰り返しが赤ちゃんを笑顔にする。'),
(31, '978-4167105761', 'S001', '坂の上の雲', 'A031', 7, 4, 'https://m.media-amazon.com/images/I/51Z0ZSWFX1L._SY445_SX342_PQ99_.jpg', '明治維新を成功させて近代国家として歩み出し、日露戦争勝利に至るまでの日本人を描く。'),
(32, '978-4101181011', 'S001', 'ローマ人の物語', 'A032', 7, 4, 'https://m.media-amazon.com/images/I/61Z88PRU+nL._SL1214_.jpg', '古代ローマ帝国の興亡を描いた歴史長編。ハンニバルとの戦いなど圧巻の描写。'),
(33, '222-222', 'S001', 'momonga', 'AUT003', 6, 1, '', NULL),
(34, '0000000000000000', 'S001', 'test', 'AUT004', 1, 1, '', NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `book_like`
--

CREATE TABLE `book_like` (
  `like_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `liked_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `genre`
--

CREATE TABLE `genre` (
  `genre_id` int(11) NOT NULL,
  `genre_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `genre`
--

INSERT INTO `genre` (`genre_id`, `genre_name`) VALUES
(1, 'バトル'),
(2, '恋愛'),
(3, 'スポーツ'),
(4, '文学'),
(5, 'IT'),
(6, 'コミック'),
(7, '歴史'),
(8, '童謡・絵本');

-- --------------------------------------------------------

--
-- テーブルの構造 `lend`
--

CREATE TABLE `lend` (
  `user_id` varchar(20) NOT NULL,
  `book_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `checkout_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `reservation_date` date NOT NULL,
  `ban` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `lend`
--

INSERT INTO `lend` (`user_id`, `book_id`, `status_id`, `checkout_date`, `return_date`, `reservation_date`, `ban`) VALUES
('j23007', 28, 5, '2026-02-03', '2026-02-10', '2026-02-03', ''),
('j23007', 30, 5, '2026-02-04', '2026-02-11', '2026-02-01', '1'),
('j23009', 1, 5, '2026-02-03', '2026-02-10', '2026-02-03', ''),
('j23009', 18, 5, '2026-02-03', '2026-02-10', '2026-02-03', ''),
('j23009', 25, 5, '2026-02-28', '2026-03-13', '2026-02-03', '1'),
('j23009', 28, 5, '2026-02-03', '2026-02-10', '2026-02-02', ''),
('j23009', 28, 5, '2026-02-03', '2026-02-10', '2026-02-03', '');

-- --------------------------------------------------------

--
-- テーブルの構造 `school`
--

CREATE TABLE `school` (
  `school_id` varchar(20) NOT NULL,
  `school_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `school`
--

INSERT INTO `school` (`school_id`, `school_name`) VALUES
('S001', '静岡産業技術専門学校'),
('S002', '帝京大学');

-- --------------------------------------------------------

--
-- テーブルの構造 `status`
--

CREATE TABLE `status` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `status`
--

INSERT INTO `status` (`status_id`, `status_name`) VALUES
(1, '貸出'),
(2, '予約'),
(3, '運搬'),
(4, '保管'),
(5, '返却');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `user_id` varchar(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `school_id` varchar(20) NOT NULL,
  `user_grade` int(11) DEFAULT NULL,
  `user_password` varchar(1000) NOT NULL,
  `user_authority` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `school_id`, `user_grade`, `user_password`, `user_authority`) VALUES
('j23001', '佐藤花子', 'S002', 3, 'pass456', 0),
('j23005', '一般', 'S001', 2, '$2y$10$cMSm9BA9dI9mT1qU6yuStujKGLabr3ACdNlY0YbWfTHwIGdpDoWXi', 0),
('j23007', 'osada', 'S002', 1, '$2y$10$K2QbQvlYbY3XgKRhtNOqs.yZAnRaMDvOvLhAlBW7H3Y0rbUG4OPJC', 1),
('j23008', '長田武龍', 'S001', 3, 'j23008', 1),
('j23009', 'ピカチュウ', 'S001', 1, '$2y$10$YL.2N93F7aNY30TZBEKm1uTunaVsNmQ9V7BOl8Q2jmYLAvQAUMsFa', 1);

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`author_id`);

--
-- テーブルのインデックス `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `fk_book_school` (`school_id`),
  ADD KEY `fk_book_genre` (`genre_id`),
  ADD KEY `fk_book_status` (`status_id`),
  ADD KEY `fk_book_author` (`author_id`);

--
-- テーブルのインデックス `book_like`
--
ALTER TABLE `book_like`
  ADD PRIMARY KEY (`like_id`),
  ADD UNIQUE KEY `uk_book_user` (`book_id`,`user_id`),
  ADD KEY `fk_like_user` (`user_id`);

--
-- テーブルのインデックス `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`genre_id`);

--
-- テーブルのインデックス `lend`
--
ALTER TABLE `lend`
  ADD PRIMARY KEY (`user_id`,`book_id`,`reservation_date`),
  ADD KEY `fk_lend_book` (`book_id`),
  ADD KEY `fk_lend_status` (`status_id`);

--
-- テーブルのインデックス `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`school_id`);

--
-- テーブルのインデックス `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_user_school` (`school_id`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- テーブルの AUTO_INCREMENT `book_like`
--
ALTER TABLE `book_like`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- ダンプしたテーブルの制約
--

--
-- テーブルの制約 `book`
--
ALTER TABLE `book`
  ADD CONSTRAINT `fk_book_author` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`),
  ADD CONSTRAINT `fk_book_genre` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`genre_id`),
  ADD CONSTRAINT `fk_book_school` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`),
  ADD CONSTRAINT `fk_book_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`);

--
-- テーブルの制約 `book_like`
--
ALTER TABLE `book_like`
  ADD CONSTRAINT `fk_like_book` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_like_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- テーブルの制約 `lend`
--
ALTER TABLE `lend`
  ADD CONSTRAINT `fk_lend_book` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`),
  ADD CONSTRAINT `fk_lend_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`),
  ADD CONSTRAINT `fk_lend_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- テーブルの制約 `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_user_school` FOREIGN KEY (`school_id`) REFERENCES `school` (`school_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
